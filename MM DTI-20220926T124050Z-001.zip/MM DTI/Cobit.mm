<map version="1.1.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1459338287084" ID="ID_1690947713" MODIFIED="1524404556500" TEXT="Cobit">
<node CREATED="1460457335281" FOLDED="true" ID="ID_107428208" MODIFIED="1574903980047" POSITION="right" TEXT="Evolu&#xe7;&#xe3;o do Cobit">
<node CREATED="1460457352244" MODIFIED="1460457352244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_2171963017953973019.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1574903713588" ID="ID_919083511" MODIFIED="1574903713588">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_8134581988535773199.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1460457357748" FOLDED="true" ID="ID_1533239534" MODIFIED="1585598614526" POSITION="right" TEXT="Benef&#xed;cios organizacionais ">
<node CREATED="1460457361795" FOLDED="true" ID="ID_1928146695" MODIFIED="1539656944802" TEXT="Informa&#xe7;&#xe3;o &#xe9; recurso chave para todas as organiza&#xe7;&#xf5;es">
<node CREATED="1460457403168" ID="ID_216931059" MODIFIED="1460457409789" TEXT="Informa&#xe7;&#xe3;o &#xe9; um elemento central para o modelo"/>
<node CREATED="1460457430879" ID="ID_957560060" MODIFIED="1460457449098" TEXT="o objetivo maior do Cobit &#xe9; entregar valor para o neg&#xf3;cio, tendo a informa&#xe7;&#xe3;o como um meio para tal"/>
</node>
<node CREATED="1460457365507" FOLDED="true" ID="ID_1542339029" MODIFIED="1549317403392" TEXT="Como consequ&#xea;ncia disso, as organiza&#xe7;&#xf5;es buscam:">
<node CREATED="1460457373040" ID="ID_1508525283" MODIFIED="1460457373040" TEXT="Informa&#xe7;&#xe3;o de qualidade para suporte &#xe0; decis&#xe3;o"/>
<node CREATED="1460457376235" ID="ID_119394500" MODIFIED="1460457376543" TEXT="Excel&#xea;ncia operacional a partir de aplica&#xe7;&#xf5;es de TI confi&#xe1;veis e eficientes"/>
<node CREATED="1460457379768" MODIFIED="1460457379768" TEXT="Manuten&#xe7;&#xe3;o de n&#xed;veis aceit&#xe1;veis de riscos de TI"/>
<node CREATED="1460457379769" ID="ID_141826590" MODIFIED="1460457399301" TEXT="Otimiza&#xe7;&#xe3;o dos custos de servi&#xe7;os e da TI"/>
<node CREATED="1460457384689" ID="ID_326872237" MODIFIED="1460457386934" TEXT="Conformidade com n&#xfa;mero crescente de leis, normas, regulamentos, requisitos contratuais e pol&#xed;ticas"/>
</node>
</node>
<node CREATED="1460457683161" FOLDED="true" ID="ID_446293218" MODIFIED="1574907143007" POSITION="right" TEXT="Por onde estudar? ">
<node CREATED="1460457689615" FOLDED="true" ID="ID_1763864933" MODIFIED="1585597357632" TEXT="Cobit 5 &#x2013; Framework">
<node CREATED="1460457689616" FOLDED="true" ID="ID_1651270091" MODIFIED="1585597357631" TEXT="Sum&#xe1;rio executivo e descri&#xe7;&#xe3;o dos componentes">
<node CREATED="1460457689616" ID="ID_488631588" MODIFIED="1460457756249" TEXT="Cinco princ&#xed;pios"/>
<node CREATED="1460457689616" ID="ID_1211952165" MODIFIED="1460457757577" TEXT="Sete facilitadores (enablers/habilitadores)"/>
</node>
<node CREATED="1460457689617" ID="ID_567310686" MODIFIED="1460457753482" TEXT="Introdu&#xe7;&#xe3;o ao modelo de implementa&#xe7;&#xe3;o"/>
<node CREATED="1460457689617" ID="ID_958294972" MODIFIED="1460457752089" TEXT="Introdu&#xe7;&#xe3;o ao modelo de avalia&#xe7;&#xe3;o e capacidade"/>
</node>
<node CREATED="1460457689617" FOLDED="true" ID="ID_671404303" MODIFIED="1585597357632" TEXT="Cobit 5: Enabling Processes">
<node CREATED="1460457689618" ID="ID_1238487323" MODIFIED="1460457750657" TEXT="Descri&#xe7;&#xe3;o textual e prop&#xf3;sito dos processos"/>
<node CREATED="1460457694737" ID="ID_1749216336" MODIFIED="1460457695006" TEXT="Substitui&#xe7;&#xe3;o dos controles gerais de processos por atributos de processo da ISO 15504"/>
</node>
<node CREATED="1460458043620" ID="ID_1222632462" MODIFIED="1460458067555" TEXT="Ler o Cobit 5 (por volta de 60 pgs)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#800000" CREATED="1460457633452" FOLDED="true" ID="ID_684559279" MODIFIED="1574906767130" POSITION="right" TEXT="Fam&#xed;lia de publica&#xe7;&#xf5;es ">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="full-1"/>
<node CREATED="1460457640197" ID="ID_1344941947" MODIFIED="1460457640197">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_4013413907753079333.jpeg"/>
  </body>
</html></richcontent>
</node>
<node COLOR="#cc6600" CREATED="1548968540885" ID="ID_1815126573" MODIFIED="1548968573153" TEXT="[cespe] A fam&#xed;lia de produtos do COBIT 5 que engloba os guias para implementa&#xe7;&#xe3;o, seguran&#xe7;a da informa&#xe7;&#xe3;o, garantia e risco denomina-se guias profissionais"/>
<node CREATED="1548968630368" FOLDED="true" ID="ID_1412074589" MODIFIED="1585597357632" TEXT="Guia de Habilitadores:">
<node CREATED="1548968630371" ID="ID_184078166" MODIFIED="1548968630371" TEXT="Processos;"/>
<node CREATED="1548968630373" ID="ID_1182155816" MODIFIED="1548968630373" TEXT="Informa&#xe7;&#xe3;o;"/>
<node CREATED="1548968642988" ID="ID_1917545575" MODIFIED="1548968648274" TEXT="Outros guias habilitadors"/>
</node>
<node CREATED="1548968630374" FOLDED="true" ID="ID_1878228166" MODIFIED="1585597357633" TEXT="Guia Profissionais:">
<node CREATED="1574904123944" ID="ID_1608959168" MODIFIED="1574904157587" TEXT="Descreve como os especialistas de determinada &#xe1;rea pode usar o Cobit 5 para coisas especificas"/>
<node CREATED="1548968630376" ID="ID_426435076" MODIFIED="1548968630376" TEXT="Implementa&#xe7;&#xe3;o;"/>
<node CREATED="1548968630378" ID="ID_1826313209" MODIFIED="1548968630378" TEXT="Seguran&#xe7;a da Informa&#xe7;&#xe3;o;"/>
<node CREATED="1548968630379" ID="ID_1090875890" MODIFIED="1548968630379" TEXT="Garantia;"/>
<node CREATED="1548968630381" ID="ID_926442121" MODIFIED="1548968630381" TEXT="Risco."/>
<node CREATED="1548968642988" ID="ID_576185123" MODIFIED="1548968648274" TEXT="Outros guias habilitadors"/>
</node>
</node>
<node CREATED="1460457573119" ID="ID_993385671" MODIFIED="1585598618740" POSITION="right" TEXT="O Cobit 5 ">
<icon BUILTIN="full-2"/>
<node CREATED="1460457577444" FOLDED="true" ID="ID_349373404" MODIFIED="1585597357633" TEXT="Ajuda as organiza&#xe7;&#xf5;es a otimizar o valor criado pela TI">
<node CREATED="1460457581486" ID="ID_1856451478" MODIFIED="1460457581659" TEXT="Equil&#xed;brio entre a obten&#xe7;&#xe3;o de benef&#xed;cios e a otimiza&#xe7;&#xe3;o de n&#xed;veis de risco e de uso de recursos"/>
</node>
<node CREATED="1460457586302" FOLDED="true" ID="ID_920732772" MODIFIED="1549315555167" TEXT="Permite que a TI seja governada e gerenciada de forma hol&#xed;stica para toda a organiza&#xe7;&#xe3;o (ponta a ponta)">
<node CREATED="1460457590675" ID="ID_606707059" MODIFIED="1460457590675" TEXT="Abrangendo &#xe1;reas de neg&#xf3;cio e tecnologia"/>
<node CREATED="1460457593804" ID="ID_634919661" MODIFIED="1460457593804" TEXT="Considerando interesses de stakeholders internos e externos"/>
</node>
<node CREATED="1460457597269" FOLDED="true" ID="ID_1539876298" MODIFIED="1585597357633" TEXT="Principios e facilitadores gen&#xe9;ricos">
<node CREATED="1460457600680" ID="ID_157165934" MODIFIED="1460457600680" TEXT="Organiza&#xe7;&#xf5;es de todos os tamanhos, p&#xfa;blicas e privadas"/>
</node>
<node CREATED="1460513063863" ID="ID_1903380634" MODIFIED="1460513065570" TEXT="Esse  modelo agrupa cinco princ&#xed;pios que permitem &#xe0;s corpora&#xe7;&#xf5;es constru&#xed;rem um framework efetivo de governan&#xe7;a e gest&#xe3;o, baseado em um conjunto de sete viabilizadores (enablers), que otimizam os investimentos em tecnologia e informa&#xe7;&#xe3;o, assim como seu uso em benef&#xed;cio das partes interessadas"/>
<node COLOR="#cc6600" CREATED="1549317454302" FOLDED="true" ID="ID_62704866" MODIFIED="1566339364562" TEXT="[cese] &#xc9; recomend&#xe1;vel que o COBIT seja utilizado em todos os n&#xed;veis organizacionais, pois ele se concentra em como atingir o conjunto de atividades previstas para a TI em vez de se preocupar com o que deve ser atingido. ">
<node CREATED="1549317478447" ID="ID_912610767" MODIFIED="1549317491212" TEXT="Cobit n&#xe3;o se concentra em COMO atingir, e sim o que deve ser atingido, o COMO &#xe9; definido pela organiza&#xe7;&#xe3;o."/>
</node>
<node COLOR="#cc6600" CREATED="1585598609428" ID="ID_28631816" MODIFIED="1585598621092" TEXT="[cespe] A ado&#xe7;&#xe3;o do COBIT auxilia as empresas a atingirem os objetivos estrat&#xe9;gicos atrav&#xe9;s da utiliza&#xe7;&#xe3;o eficaz e inovadora de TI e a manterem o cumprimento de leis, regulamentos, acordos contratuais e pol&#xed;ticas, entre outros benef&#xed;cios.  "/>
</node>
<node CREATED="1460457462605" FOLDED="true" ID="ID_653606284" MODIFIED="1578352130488" POSITION="right" TEXT="Valor para stakeholders ">
<icon BUILTIN="full-1"/>
<node CREATED="1460457492668" ID="ID_176103915" MODIFIED="1460457499793" TEXT="O objetivo maior &#xe9; entregar valor para os stakeholders"/>
<node CREATED="1574907037830" ID="ID_36170715" MODIFIED="1574907061802" TEXT="a gera&#xe7;&#xe3;o de valor &#xe9; responsabilidade de TODOS"/>
<node CREATED="1460457471817" FOLDED="true" ID="ID_1523007318" MODIFIED="1585597357634" TEXT="Depende de governan&#xe7;a e gest&#xe3;o dos ativos de TI">
<node CREATED="1460457536969" ID="ID_1790295730" MODIFIED="1460457544173" TEXT="governan&#xe7;a &#xe9; responsabilidade da alta administra&#xe7;&#xe3;o"/>
<node CREATED="1460457544856" ID="ID_1925533230" MODIFIED="1460457559524" TEXT="mas valor para stakeholder &#xe9; responsabilidade de todo mundo, da governan&#xe7;a e gest&#xe3;o"/>
</node>
<node CREATED="1460457474941" FOLDED="true" ID="ID_800615114" MODIFIED="1585597357634" TEXT="Responsabilidade de conselhos de administra&#xe7;&#xe3;o (boards), executivos e gestores">
<node CREATED="1460457477878" ID="ID_172807738" MODIFIED="1460457477878" TEXT="Todos devem tratar TI como parte significativa dos neg&#xf3;cios"/>
</node>
<node CREATED="1460457481836" FOLDED="true" ID="ID_1232487639" MODIFIED="1585597357635" TEXT=" Aumento dos requisitos externos de conformidade relacionados ao uso de informa&#xe7;&#xe3;o e de TI">
<node CREATED="1460457485443" ID="ID_1630140218" MODIFIED="1460457485443" TEXT="Viola&#xe7;&#xe3;o desses requisitos amea&#xe7;a o valor do neg&#xf3;cio"/>
</node>
<node COLOR="#cc6600" CREATED="1539656831617" ID="ID_1519551420" MODIFIED="1539656837385" TEXT="[cespe] A ado&#xe7;&#xe3;o do COBIT auxilia as empresas a atingirem os objetivos estrat&#xe9;gicos atrav&#xe9;s da utiliza&#xe7;&#xe3;o eficaz e inovadora de TI e a manterem o cumprimento de leis, regulamentos, acordos contratuais e pol&#xed;ticas, entre outros benef&#xed;cios.    "/>
</node>
<node CREATED="1460458028973" FOLDED="true" ID="ID_810697990" MODIFIED="1585598598639" POSITION="right" TEXT="Princ&#xed;pios">
<node CREATED="1460458034993" FOLDED="true" ID="ID_468971099" MODIFIED="1576633146057" TEXT="1. Atender &#xe0;s necessidades dos Stakeholders">
<node CREATED="1460458291095" ID="ID_1961872681" MODIFIED="1460458303618" TEXT="Tudo que &#xe9; feito no Cobit &#xe9; voltado para atender a necessidade dos stakeholders"/>
<node CREATED="1460458315390" FOLDED="true" ID="ID_362589913" MODIFIED="1566461857795" TEXT="Para que isso ocorra, &#xe9; necess&#xe1;rio satisfazer o trip&#xe9;">
<node CREATED="1460458330800" ID="ID_1909217945" MODIFIED="1460458330800">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_3702284640897661539.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1524179199236" ID="ID_1195785847" MODIFIED="1524179260238" TEXT="S&#xf3; consigo gerar valor para o stakeholder ao entregar os benef&#xed;cios que ele espera otimizando riscos e recursos"/>
<node CREATED="1460458283159" ID="ID_1115999449" MODIFIED="1460458283420" TEXT="Stakeholders diferentes podem ter entendimentos diferentes &#x2013; e &#xe0;s vezes conflitantes &#x2013; sobre &#x201c;valor&#x201d;"/>
<node CREATED="1460458289678" ID="ID_1875585523" MODIFIED="1460458289923" TEXT="Governan&#xe7;a implica negociar e decidir entre os interesses de todos os diferentes stakeholders"/>
<node CREATED="1460458310011" FOLDED="true" ID="ID_751933687" MODIFIED="1574932510266" TEXT="Para cada decis&#xe3;o, cabem as perguntas:">
<node CREATED="1460458310012" ID="ID_117582690" MODIFIED="1460458310012" TEXT="&#xf0a7; Quem receber&#xe1; os benef&#xed;cios?"/>
<node CREATED="1460458310013" ID="ID_1117957130" MODIFIED="1460458310013" TEXT="&#xf0a7; Quem assume os riscos?"/>
<node CREATED="1460458310014" ID="ID_1032437645" MODIFIED="1460458310014" TEXT="&#xf0a7; Quais recursos s&#xe3;o necess&#xe1;rios?"/>
</node>
<node CREATED="1524179304869" ID="ID_95062912" MODIFIED="1524179320567" TEXT="Tomada a Decisao, a governan&#xe7;a direciona a vis&#xe3;o, para tal, se usa o Cascateamento de Metas"/>
<node CREATED="1460458370386" FOLDED="true" ID="ID_1697526027" MODIFIED="1585597357636" TEXT="Cascateamento de metas ">
<node CREATED="1460458402256" ID="ID_365952509" MODIFIED="1524179356918" TEXT="A Governan&#xe7;a avalia as necessidades das partes interessadas, decide quais ser&#xe3;o atendidas e direciona a gest&#xe3;o com base nessa decis&#xe3;o. Esse direcionamento &#xe9; feito atrav&#xe9;s do cascateamento de metas."/>
<node CREATED="1460458371467" ID="ID_312707421" MODIFIED="1460458472033" TEXT="Ao entender as necessidades das partes interessadas, isso dever&#xe1; ser traduzido num conjunto de metas e objetivos corporativos, que ser&#xe3;o desdobrados em objetivos de TI e depois ser&#xe3;o desdobrados em facilitadores"/>
<node CREATED="1460458502116" FOLDED="true" ID="ID_876324783" MODIFIED="1574932604831" TEXT="Desdobramento">
<node CREATED="1460458511720" ID="ID_437400097" MODIFIED="1460458511720">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_843107188831122587.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1460458480788" FOLDED="true" ID="ID_725321802" MODIFIED="1549315555174" TEXT="Mecanismo que traduz os direcionadores (drivers) e as necessidades dos stakeholders em metas espec&#xed;ficas, pr&#xe1;ticas e customizadas">
<node CREATED="1460458484843" ID="ID_533499341" MODIFIED="1460458484976" TEXT="J&#xe1; existia no Cobit 4.1, mas tem mais destaque no Cobit 5"/>
<node CREATED="1460458488691" ID="ID_598017335" MODIFIED="1460458489144" TEXT="Em rela&#xe7;&#xe3;o ao Cobit 4.1, existe um n&#xed;vel a menos de metas no Cobit 5 (n&#xe3;o h&#xe1; mais metas de atividades)"/>
</node>
<node CREATED="1460458536440" FOLDED="true" ID="ID_641292579" MODIFIED="1575060546534" TEXT="Dado um conj de metas corporativas, se tem um conjunto de metas relacionadas a TI e a consequente vincula&#xe7;&#xe3;o entre elas, que s&#xe3;o os P (prim&#xe1;rios) e S (secund&#xe1;rios)">
<icon BUILTIN="full-2"/>
<node COLOR="#cc6600" CREATED="1534896042040" ID="ID_193464549" MODIFIED="1534896046716" TEXT="[cespe] Na defini&#xe7;&#xe3;o dos objetivos gen&#xe9;ricos do COBIT 5, est&#xe3;o inclu&#xed;das informa&#xe7;&#xf5;es acerca da dimens&#xe3;o BSC (balanced scorecard) sob a qual o objetivo corporativo se enquadra. "/>
<node CREATED="1460458745334" FOLDED="true" ID="ID_72417423" MODIFIED="1585597357635" TEXT="Matriz">
<node CREATED="1460458590565" ID="ID_447245712" MODIFIED="1460458590565">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_8195937266455861212.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1524179511133" ID="ID_1914357016" MODIFIED="1524179572106" TEXT="O COBIT traz 17 benef&#xed;cios de neg&#xf3;cio, 17 benef&#xed;cios de TI, os correlaciona e os prioriza"/>
<node CREATED="1460458598757" ID="ID_908557097" MODIFIED="1460458599778" TEXT="O ambiente da organiza&#xe7;&#xe3;o direciona as necessidades dos stakeholders"/>
<node CREATED="1460458641435" ID="ID_1105007875" MODIFIED="1460458641639" TEXT="17 metas corporativas gen&#xe9;ricas elaboradas com base no BSC"/>
<node CREATED="1460458644442" ID="ID_392296939" MODIFIED="1460458644655" TEXT="17 metas relacionadas &#xe0; TI organizadas como um BSC-TI"/>
<node CREATED="1460458647618" ID="ID_649148205" MODIFIED="1460458825972" TEXT="A partir da identifica&#xe7;&#xe3;o das metas corporativas aplic&#xe1;veis ou priorit&#xe1;rias, s&#xe3;o identificadas as metas de TI mais relevantes,  ou seja, as metas de TI que sustentam essas metas corporativas."/>
<node CREATED="1460458650730" ID="ID_394703613" MODIFIED="1460458650950" TEXT="A partir das metas de TI, &#xe9; poss&#xed;vel identificar os processos priorit&#xe1;rios para implementa&#xe7;&#xe3;o ou melhoria"/>
<node CREATED="1460458657090" ID="ID_171814087" MODIFIED="1460458729281" TEXT="Essa matriz &#xe9; estruturada com base no BSC, &#xe9; dividida em objetivos financeiro, interno, de cliente e de aprendizado e crescimento"/>
<node CREATED="1460513603398" ID="ID_1889995640" MODIFIED="1460513603851" TEXT="As  dimens&#xf5;es  do  balanced  scorecard  s&#xe3;o  empregadas  para  o  desenvolvimento  dos  objetivos  corporativos  (entreprise  goals)  e  dos  objetivos  relacionados  &#xe0;  TI  constantes da cascata de objetivos do COBIT"/>
<node COLOR="#800000" CREATED="1548968830468" FOLDED="true" ID="ID_1863595905" MODIFIED="1585597357636" TEXT="Objetivo Corporativo x Dimens&#xe3;o do BSC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#cc6600" CREATED="1548968847452" ID="ID_1088640626" MODIFIED="1548968876532" TEXT="[cespe] Um dos princ&#xed;pios do Cobit 5 &#xe9; atender &#xe0;s necessidades das partes interessadas considerando suas expectativas acerca da tecnologia da informa&#xe7;&#xe3;o na organiza&#xe7;&#xe3;o. &#xa;&#xa;Com base nesse princ&#xed;pio, assinale a op&#xe7;&#xe3;o que apresenta o objetivo corporativo que atende a dimens&#xe3;o BSC (balanced scorecard) do cliente. &#xa;&#xa;respostas r&#xe1;pidas para um ambiente de neg&#xf3;cios em mudan&#xe7;a"/>
<node CREATED="1548968883910" MODIFIED="1548968883910" TEXT="Investimento, partes interessadas =&gt;Financeiro"/>
<node CREATED="1548968883916" MODIFIED="1548968883916" TEXT="equipe qualificada e motivada=&gt; Aprendizado e crescimento"/>
<node CREATED="1548968883918" MODIFIED="1548968883918" TEXT="otimiza&#xe7;&#xe3;o do processo neg&#xf3;cio =&gt; Interno"/>
<node CREATED="1548968883920" MODIFIED="1548968883920" TEXT="resposta r&#xe1;pida a mudan&#xe7;a =&gt; Cliente"/>
<node CREATED="1548968932799" MODIFIED="1548968932799" TEXT="APRENDIZAGEM E CRESCIMENTO: Conhecimento e habilidade dos empregados s&#xe3;o fundamentais para inova&#xe7;&#xf5;es e melhorias"/>
<node CREATED="1548968932810" MODIFIED="1548968932810" TEXT="PROCESSOS INTERNOS: Empregados capacitados, treinados e motivados melhoram seus processos de trabalho."/>
<node CREATED="1548968932820" MODIFIED="1548968932820" TEXT="CLIENTES: Melhores processos de trabalho conduzem a clientes mais satisfeitos."/>
<node CREATED="1548968932823" MODIFIED="1548968932823" TEXT="FINANCEIRA: Maior satisfa&#xe7;&#xe3;o dos clientes leva a melhores resultados financeiros."/>
<node CREATED="1548969058650" MODIFIED="1548969058650">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_8302944550243049699.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1460458943841" FOLDED="true" ID="ID_1545595391" MODIFIED="1585597357636" TEXT="Benef&#xed;cios do cascateamento de metas ">
<icon BUILTIN="full-1"/>
<node CREATED="1460458949289" ID="ID_228933595" MODIFIED="1460458949470" TEXT=" Permite a defini&#xe7;&#xe3;o de prioridades para implementa&#xe7;&#xe3;o e auditoria da governan&#xe7;a corporativa de TI, com base em objetivos estrat&#xe9;gicos e riscos relacionados"/>
<node COLOR="#808000" CREATED="1534896180248" ID="ID_1378170025" MODIFIED="1534896188241" TEXT="Identifica e comunica claramente como (por vezes de forma muito operacional) os habilitadores s&#xe3;o importantes para o atingimento dos objetivos corporativos&quot;"/>
<node CREATED="1460458953057" FOLDED="true" ID="ID_396958171" MODIFIED="1585597357636" TEXT="Na pr&#xe1;tica, o cascateamento de metas:">
<node CREATED="1460458956524" ID="ID_763141999" MODIFIED="1460458956524" TEXT="Define metas tang&#xed;veis e relevantes em v&#xe1;rios n&#xed;veis"/>
<node CREATED="1460458960256" ID="ID_1519829912" MODIFIED="1460458960501" TEXT="Permite filtrar o conhecimento do Cobit com base nas metas corporativas relevantes para implementa&#xe7;&#xe3;o ou auditoria"/>
<node CREATED="1460458963824" ID="ID_1015695364" MODIFIED="1460458964077" TEXT=" Identifica e comunica claramente como os facilitadores do Cobit (&#xe0;s vezes muito operacionais) s&#xe3;o importantes para o alcance de metas corporativas"/>
</node>
</node>
<node COLOR="#cc6600" CREATED="1460514902531" ID="ID_189835540" MODIFIED="1574932994220" TEXT="[cespe] Segundo o COBIT, a finalidade da cascata de objetivos &#xe9; definir  prioridades,  com  base  em  objetivos  estrat&#xe9;gicos  e  riscos relacionados, para implementa&#xe7;&#xe3;o, aprimoramento e  garantia de governan&#xe7;a corporativa de TI"/>
</node>
</node>
<node CREATED="1460458034993" FOLDED="true" ID="ID_1774893991" MODIFIED="1585598446308" TEXT="2. Cobrir a organiza&#xe7;&#xe3;o de ponta a ponta">
<node CREATED="1575060580131" FOLDED="true" ID="ID_877114123" MODIFIED="1585597357637" TEXT="&#xf0a7; Integra a governan&#xe7;a corporativa de TI com a governan&#xe7;a corporativa (do neg&#xf3;cio)">
<node CREATED="1575060617501" ID="ID_1501873381" MODIFIED="1575060626459" TEXT="implantar um sistema de gov q abranja negocio e tecnologia"/>
<node CREATED="1575060658841" ID="ID_1103399723" MODIFIED="1575060670158" TEXT="gov corporativa de negocio ta preocupada em tomar as grandes decisoes de negocio"/>
<node CREATED="1575060673709" ID="ID_1759846969" MODIFIED="1575060717859" TEXT="a gov corporativa de TI entende as necessidades dos stakeholders e desdobra em objetivos de TI"/>
</node>
<node CREATED="1575060603318" FOLDED="true" ID="ID_1551416475" MODIFIED="1585597357637" TEXT="&#xf0a7; N&#xe3;o &#xe9; focado somente na fun&#xe7;&#xe3;o de TI ">
<node CREATED="1575060641871" ID="ID_227844043" MODIFIED="1575060642586" TEXT="Vis&#xe3;o hol&#xed;stica e sist&#xea;mica da governan&#xe7;a e da gest&#xe3;o de TI"/>
<node CREATED="1575060648833" ID="ID_1069433201" MODIFIED="1575060648833" TEXT="Cobre todas as fun&#xe7;&#xf5;es do neg&#xf3;cio"/>
<node CREATED="1575060653317" ID="ID_824471626" MODIFIED="1575060653682" TEXT="Informa&#xe7;&#xe3;o e TI como ativos que interessam a todos na organiza&#xe7;&#xe3;"/>
</node>
<node CREATED="1524180373751" FOLDED="true" ID="ID_1181473996" MODIFIED="1585597357637" TEXT="Para isso &#xe9; necess&#xe1;rio implantar o sistema de governan&#xe7;a">
<node CREATED="1524180383353" ID="ID_1630495189" MODIFIED="1524180394441" TEXT="qual sistema tenho q montar para atender os objetivos definidos no principio anterior?"/>
</node>
<node CREATED="1460459049640" FOLDED="true" ID="ID_1505275609" MODIFIED="1575060814719" TEXT="O Cobit 5">
<node CREATED="1460459055499" ID="ID_1227877741" MODIFIED="1460459055648" TEXT="Integra a governan&#xe7;a corporativa de TI com a governan&#xe7;a corporativa (do neg&#xf3;cio)"/>
<node CREATED="1460459087172" FOLDED="true" ID="ID_24870415" MODIFIED="1585597357637" TEXT="N&#xe3;o &#xe9; focado somente na fun&#xe7;&#xe3;o de TI">
<node CREATED="1460459087173" ID="ID_1736342358" MODIFIED="1460459087173" TEXT="&#xf0a7; Vis&#xe3;o hol&#xed;stica e sist&#xea;mica da governan&#xe7;a e da gest&#xe3;o de TI"/>
<node CREATED="1460459087173" ID="ID_1431934609" MODIFIED="1460459087173" TEXT="&#xf0a7; Cobre todas as fun&#xe7;&#xf5;es do neg&#xf3;cio"/>
<node CREATED="1460459087174" ID="ID_412054435" MODIFIED="1460459093445" TEXT="&#xf0a7; Informa&#xe7;&#xe3;o e TI como ativos que interessam a todos na organiza&#xe7;&#xe3;o"/>
</node>
</node>
<node CREATED="1460459110136" FOLDED="true" ID="ID_1868460202" MODIFIED="1585598445373" TEXT="Componentes do sistema de governan&#xe7;a ">
<node CREATED="1460459117008" ID="ID_162312585" MODIFIED="1524180487020">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_3103195436232796516.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1460459126432" FOLDED="true" ID="ID_1676132537" MODIFIED="1585597357638" TEXT="Objetivo">
<node CREATED="1460459134689" ID="ID_439371232" MODIFIED="1460459140374" TEXT="&#xe9; a Cria&#xe7;&#xe3;o de valor"/>
</node>
<node CREATED="1460459144435" FOLDED="true" ID="ID_1294579791" MODIFIED="1575060846065" TEXT="Facilitadores/habilitadores">
<node CREATED="1460459144437" ID="ID_1015400959" MODIFIED="1460459144437" TEXT="&#xf0a7; Descritos no princ&#xed;pio n&#xba; 4"/>
<node CREATED="1524180683603" ID="ID_959172016" MODIFIED="1524180689717" TEXT="atuam sobre determinado escopo da governan&#xe7;a"/>
<node CREATED="1575060821382" ID="ID_1721880180" MODIFIED="1575060830354" TEXT="s&#xe3;o eles que d&#xe3;o forma ao sistema de governan&#xe7;a"/>
</node>
<node CREATED="1460459148678" FOLDED="true" ID="ID_1654888957" MODIFIED="1575060836680" TEXT="Escopo">
<node CREATED="1460459155550" ID="ID_1037844792" MODIFIED="1460459170353" TEXT="O escopo padr&#xe3;o &#xe9; a organiza&#xe7;&#xe3;o como um todo, podendo aplicar at&#xe9; a um ativo espec&#xed;fico"/>
<node CREATED="1460459154414" ID="ID_488242098" MODIFIED="1460459154682" TEXT="A governan&#xe7;a pode ser aplicada &#xe0; organiza&#xe7;&#xe3;o inteira, a uma entidade, a um ativo, etc."/>
<node CREATED="1460459178924" ID="ID_1588814787" MODIFIED="1460459179216" TEXT="O escopo do Cobit 5 &#xe9; a organiza&#xe7;&#xe3;o, mas o Cobit 5 pode ser usado em qualquer uma das outras vis&#xf5;es"/>
</node>
<node CREATED="1460459187244" FOLDED="true" ID="ID_150693002" MODIFIED="1575061179962" TEXT="Fun&#xe7;&#xf5;es/pap&#xe9;is, atividades e relacionamentos">
<icon BUILTIN="full-1"/>
<node CREATED="1460459218518" ID="ID_30745927" MODIFIED="1460459218518">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_8356330933347250020.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1460459268471" ID="ID_202538281" MODIFIED="1460459387541" TEXT="As partes interessadas direcionam o processo com as suas necessidades que ser&#xe3;o coletadas pelo Conselho de Administra&#xe7;&#xe3;o "/>
<node CREATED="1460459388720" ID="ID_1455374955" MODIFIED="1460459560228" TEXT="o Conselho de administra&#xe7;&#xe3;o &#xe9; o board of directors, representa os interesses dos acionistas, dos donos da empresa, para tal se tem um conselho que toma as decis&#xf5;es e comunica essas decis&#xf5;es ao corpo diretivo (presidente e diretores da empresa)"/>
<node CREATED="1460459483467" FOLDED="true" ID="ID_197489602" MODIFIED="1534896285229" TEXT="O corpo diretivo faz gest&#xe3;o e n&#xe3;o governan&#xe7;a">
<node CREATED="1460459507666" ID="ID_639056399" MODIFIED="1460459571995" TEXT="o conselho de administra&#xe7;&#xe3;o representando as partes interessadas faz a governan&#xe7;a"/>
<node CREATED="1460459576350" ID="ID_1112279016" MODIFIED="1460459604609" TEXT="a gest&#xe3;o se faz pelo presidente e diretores que recebe o direcionamento da governan&#xe7;a e faz o planejamento, toma decis&#xf5;es, etc.."/>
</node>
<node CREATED="1460459643451" ID="ID_543855614" MODIFIED="1460459699995" TEXT="o Corpo diretivo interage com a opera&#xe7;&#xe3;o e execu&#xe7;&#xe3;o, a partir da&#xed; a opera&#xe7;&#xe3;o se reporta ao Corpo Diretivo (monitoramento faz parte da Gest&#xe3;o)"/>
<node CREATED="1460459669728" ID="ID_1463703950" MODIFIED="1460459790094" TEXT="o Conselho de Administra&#xe7;&#xe3;o monitora os resultados entregues pela gest&#xe3;o, a partir da&#xed; o Conselho de Administra&#xe7;&#xe3;o presta contas as partes interessadas"/>
<node CREATED="1575061086534" MODIFIED="1575061086534">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_5118267085292311200.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#cc6600" CREATED="1575061205949" FOLDED="true" ID="ID_1192453020" MODIFIED="1585597357638" TEXT="[cespe] A fim de gerar resultados positivos, &#xe9; necess&#xe1;rio que a governan&#xe7;a de TI seja implantada em toda a empresa, n&#xe3;o devendo estar focada apenas em um setor">
<node CREATED="1575061208589" ID="ID_100108251" MODIFIED="1575061218154" TEXT="para gerar positivos a gov de TI tem q estar implantada em toda empresa"/>
<node CREATED="1575061218365" ID="ID_915373765" MODIFIED="1575061229402" TEXT="mesmo podendo implantar em uma parte menor, deve-se implantar na empresa inteira"/>
</node>
<node COLOR="#cc6600" CREATED="1575061242349" FOLDED="true" ID="ID_173203393" MODIFIED="1585597357638" TEXT="[cespe] O sistema de governan&#xe7;a deve considerar todas as partes interessadas para encaminhar as tomadas de decis&#xe3;o relativas a benef&#xed;cios, riscos e avalia&#xe7;&#xe3;o de recursos">
<node CREATED="1575061261244" ID="ID_1750964360" MODIFIED="1575061267737" TEXT="na hroa de avaliar, considera todas as partes interessadas"/>
<node CREATED="1575061267965" ID="ID_548674429" MODIFIED="1575061273962" TEXT="mas n&#xe3;o quer dizer que tenha q atender a todos"/>
</node>
<node COLOR="#cc6600" CREATED="1585597365853" ID="ID_439821721" MODIFIED="1585597368957" TEXT="[cespe] O COBIT aborda a governan&#xe7;a e gest&#xe3;o da informa&#xe7;&#xe3;o correlata a partir da perspectiva de toda a organiza&#xe7;&#xe3;o, ou seja, o sistema de governan&#xe7;a corporativa de TI proposto pelo COBIT integra-se perfeitamente em qualquer sistema de governan&#xe7;a, de modo que o COBIT permite regular e controlar tecnologias afins onde quer que essas informa&#xe7;&#xf5;es possam ser processadas.  "/>
</node>
<node CREATED="1460458034994" FOLDED="true" ID="ID_147034956" MODIFIED="1576633155071" TEXT="3. Aplicar um modelo &#xfa;nico e integrado">
<node CREATED="1524180732255" ID="ID_997726818" MODIFIED="1524180751001" TEXT="surge como solu&#xe7;&#xe3;o ao modelo anterior, que tinha v&#xe1;rios modelos apartados"/>
<node CREATED="1460459818824" FOLDED="true" ID="ID_216392991" MODIFIED="1576632788708" TEXT="O Cobit 5 foi constru&#xed;do a partir da integra&#xe7;&#xe3;o de diversos modelos elaborados pela ISACA">
<node CREATED="1460459823588" MODIFIED="1460459823588" TEXT="Cobit, Val-IT (valor de neg&#xf3;cio), Risk IT (riscos), BMIS (seguran&#xe7;a)"/>
</node>
<node CREATED="1460459826896" FOLDED="true" ID="ID_1215798309" MODIFIED="1585597357639" TEXT="Al&#xe9;m disso, est&#xe1; alinhado com os principais frameworks de gest&#xe3;o corporativa e de TI">
<node CREATED="1460459835395" ID="ID_1493078878" MODIFIED="1460459835395" TEXT="Corporativos: COSO, COSO ERM, ISO/IEC 9000, ISO/IEC 31000"/>
<node CREATED="1460459835396" ID="ID_1097985841" MODIFIED="1460459837884" TEXT="TI: ISO 38500, ITIL 2011, ISO 2700x, TOGAF, PMBOK, CMMI"/>
<node CREATED="1460513369210" ID="ID_411717601" MODIFIED="1460513369585" TEXT="o COBIT integra, em  um framework &#xfa;nico, o BSC, o VAL IT e o COSO, devido  ao fato de o cen&#xe1;rio atual recomendar que a TI seja parte  estrat&#xe9;gica  das  organiza&#xe7;&#xf5;es  e  de  reconhecer  a  import&#xe2;ncia do alinhamento entre a TI e o neg&#xf3;cio"/>
</node>
<node CREATED="1460459844384" ID="ID_1681305642" MODIFIED="1460459844619" TEXT="COBIT 5 como um framework abrangente para integra&#xe7;&#xe3;o de pr&#xe1;ticas de governan&#xe7;a e gest&#xe3;o"/>
<node CREATED="1460459945426" ID="ID_1817891387" MODIFIED="1460459960573" TEXT="Modelo &#xfa;nico pq &#xe9; da ISACA e integrado pq &#xe9; alinhado aos outros frameworks do mercado"/>
<node COLOR="#cc6600" CREATED="1535914328391" ID="ID_906058276" MODIFIED="1535914336246" TEXT="[cespe] A NBR ISO/IEC 38500:2009 est&#xe1; alinhada &#xe0; &#xe1;rea chave de governan&#xe7;a do COBIT 5, pois preconiza a prepara&#xe7;&#xe3;o e a implementa&#xe7;&#xe3;o de planos e pol&#xed;ticas para assegurar que o uso da TI atenda &#xe0;s necessidades atuais e cont&#xed;nuas da estrat&#xe9;gia de neg&#xf3;cio da organiza&#xe7;&#xe3;o. "/>
<node COLOR="#cc6600" CREATED="1576632974802" FOLDED="true" ID="ID_1804662995" MODIFIED="1576633133987" TEXT="[cespe] O COBIT 5 descreve um modelo &#xfa;nico e integrado de princ&#xed;pios que permite governar e gerir a TI de forma hol&#xed;stica para toda a organiza&#xe7;&#xe3;o, o que abrange todas as &#xe1;reas respons&#xe1;veis pelas fun&#xe7;&#xf5;es de TI e considera tanto os interesses internos quanto os interesses externos relacionados &#xe0; TI.">
<node CREATED="1576632994754" ID="ID_98738354" MODIFIED="1576633015166" TEXT="ele n&#xe3;o diz que &#xe9; exclusivo das &#xe1;reas respons&#xe1;veis pelas fun&#xe7;&#xf5;es de TI"/>
</node>
</node>
<node CREATED="1460458034994" ID="ID_48660747" MODIFIED="1585598447754" TEXT="4. Permitir uma abordagem hol&#xed;stica">
<node CREATED="1524181213791" ID="ID_928248340" MODIFIED="1524181226746" TEXT="Permitir &#xe9; sin&#xf4;nimo de Habilitar"/>
<node CREATED="1524181274285" ID="ID_1752232179" MODIFIED="1524181323702" TEXT="&#xe9; o principio que descreve os 7 habilitadores do COBIT 5, diz como iremos fazer tudo isso funcionar"/>
<node CREATED="1460459930381" ID="ID_1343300763" MODIFIED="1585597745327" TEXT="Facilitadores (habilitadores) do Cobit 5:">
<node CREATED="1460459935705" ID="ID_1544720638" MODIFIED="1460459936598" TEXT="Fatores que, individual e coletivamente, influenciam o funcionamento da governan&#xe7;a e gest&#xe3;o de TI"/>
<node CREATED="1460459939849" ID="ID_1581167193" MODIFIED="1460459940086" TEXT="Dirigidos pelo cascateamento de metas &#x2013; as metas de TI definem o que os facilitadores devem alcan&#xe7;ar"/>
<node CREATED="1460459942906" FOLDED="true" ID="ID_1846284706" MODIFIED="1578352222535" TEXT="Descritos em sete categorias">
<node CREATED="1460459990092" ID="ID_734524657" MODIFIED="1460459990092">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_567501671360428200.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1460459995694" FOLDED="true" ID="ID_657018976" MODIFIED="1585598595893" TEXT="Categorias de Facilitadores ">
<node CREATED="1460459999642" ID="ID_554505424" MODIFIED="1585598462743" TEXT="Princ&#xed;pios, pol&#xed;ticas e frameworks">
<icon BUILTIN="full-3"/>
<node CREATED="1460460003374" ID="ID_1084424253" MODIFIED="1460460003562" TEXT="Traduzem o comportamento desejado em orienta&#xe7;&#xf5;es pr&#xe1;ticas para o gerenciamento do dia-a-dia"/>
<node CREATED="1576633496434" ID="ID_815206466" MODIFIED="1576633501790" TEXT="decidem as regras que v&#xe3;o direcionar o comportamento"/>
<node COLOR="#cc6600" CREATED="1534895137631" ID="ID_107276513" MODIFIED="1539656982064" TEXT="[cespe] Princ&#xed;pios, pol&#xed;ticas e modelos s&#xe3;o os ve&#xed;culos pelo qual as decis&#xf5;es de governan&#xe7;a s&#xe3;o institucionalizadas na organiza&#xe7;&#xe3;o, e por esse motivo constituem uma intera&#xe7;&#xe3;o entre as decis&#xf5;es de governan&#xe7;a (defini&#xe7;&#xe3;o da orienta&#xe7;&#xe3;o) e a gest&#xe3;o (execu&#xe7;&#xe3;o das decis&#xf5;es)"/>
<node COLOR="#cc6600" CREATED="1548967459815" ID="ID_1773470891" MODIFIED="1548967469438" TEXT="[cespe] De acordo com o COBIT 5, servi&#xe7;os, aplica&#xe7;&#xf5;es e infraestrutura s&#xe3;o os instrumentos pelos quais as decis&#xf5;es de governan&#xe7;a s&#xe3;o institucionalizadas dentro da empresa e promovem a intera&#xe7;&#xe3;o entre as decis&#xf5;es de governan&#xe7;a e o gerenciamento.  ">
<icon BUILTIN="button_cancel"/>
</node>
<node COLOR="#cc6600" CREATED="1585598466100" ID="ID_544913101" MODIFIED="1585598478021" TEXT="[cespe] De acordo com o COBIT 5, princ&#xed;pios, pol&#xed;ticas e estruturas s&#xe3;o instrumentos por meio dos quais as decis&#xf5;es de governan&#xe7;a s&#xe3;o institucionalizadas na organiza&#xe7;&#xe3;o e servem de referencial para o gerenciamento na execu&#xe7;&#xe3;o das decis&#xf5;es. "/>
<node CREATED="1460492463239" FOLDED="true" ID="ID_199713847" MODIFIED="1585597357639" TEXT="Princ&#xed;pios">
<node CREATED="1524181530559" ID="ID_1882156265" MODIFIED="1524181570061" TEXT="Materializa os valores da organiza&#xe7;&#xe3;o"/>
<node CREATED="1578352317222" ID="ID_473730307" MODIFIED="1578352322753" TEXT="s&#xe3;o os valores da organiza&#xe7;&#xe3;o"/>
<node CREATED="1460492467123" ID="ID_52827437" MODIFIED="1460492467123" TEXT="N&#xfa;mero limitado"/>
<node CREATED="1460492470392" ID="ID_619325924" MODIFIED="1460492470623" TEXT="Linguagem simples, expressando da forma mais clara poss&#xed;vel os  valores da organiza&#xe7;&#xe3;o"/>
<node CREATED="1460492508105" ID="ID_976873904" MODIFIED="1460492524271" TEXT="s&#xe3;o traduzidos em regras atrav&#xe9;s das pol&#xed;ticas"/>
</node>
<node CREATED="1460492475392" FOLDED="true" ID="ID_1575217797" MODIFIED="1585597357639" TEXT="Pol&#xed;ticas">
<node CREATED="1524181598246" ID="ID_875118661" MODIFIED="1524181616128" TEXT="Conjunto de regras criados para que a organiza&#xe7;&#xe3;o atenda aos Princ&#xed;pios"/>
<node CREATED="1460492487304" ID="ID_1235553801" MODIFIED="1460492487304" TEXT="Efetivas (alcan&#xe7;am o resultado esperado)"/>
<node CREATED="1460492487306" ID="ID_396179470" MODIFIED="1460492495690" TEXT="Eficientes (na implementa&#xe7;&#xe3;o dos princ&#xed;pios)"/>
<node CREATED="1460492493256" ID="ID_1865162058" MODIFIED="1460492493668" TEXT="N&#xe3;o intrusivas (parecem l&#xf3;gicas, n&#xe3;o geram resist&#xea;ncia  desnecess&#xe1;rias)"/>
</node>
<node CREATED="1460492504074" FOLDED="true" ID="ID_1516138407" MODIFIED="1585597357640" TEXT="Frameworks">
<node CREATED="1460492601791" ID="ID_995001557" MODIFIED="1460492622512" TEXT="s&#xe3;o os modelos utilizados para implementar os facilitadores, devem ser:"/>
<node CREATED="1460492536841" ID="ID_403758419" MODIFIED="1460492540092" TEXT="Abrangentes (cobrindo todas as &#xe1;reas necess&#xe1;rias)"/>
<node CREATED="1460492536843" ID="ID_253365150" MODIFIED="1460492541689" TEXT="Abertos e flex&#xed;veis (permitem adapta&#xe7;&#xf5;es &#xe0; situa&#xe7;&#xe3;o da empresa)"/>
<node CREATED="1460492536847" ID="ID_1715006319" MODIFIED="1460492542860" TEXT="Atuais (em rela&#xe7;&#xe3;o aos objetivos de governan&#xe7;a da empresa)"/>
</node>
</node>
<node CREATED="1460460021837" FOLDED="true" ID="ID_1534503815" MODIFIED="1578352581351" TEXT="Cultura, &#xe9;tica e comportamento">
<node CREATED="1578352389092" ID="ID_1084150729" MODIFIED="1578352401865" TEXT="s&#xe3;o influenciados pelos principios, politicas e frameworks"/>
<node CREATED="1524181426105" ID="ID_425025431" MODIFIED="1524181486291" TEXT="Para que os processos e tomadas de decis&#xe3;o funcionem, precisa-se de pessoas. Essas devem ser guiadas por cultura, &#xe9;tica e comportamento"/>
<node CREATED="1460460026332" ID="ID_61603734" MODIFIED="1460460026577" TEXT="De indiv&#xed;duos e da organiza&#xe7;&#xe3;o, muitas vezes subestimados como fatores de sucesso para governan&#xe7;a e gest&#xe3;o"/>
<node CREATED="1460492973250" FOLDED="true" ID="ID_1354287673" MODIFIED="1585597357641" TEXT="Metas">
<node CREATED="1460492977574" FOLDED="true" ID="ID_431121172" MODIFIED="1585597357640" TEXT="&#xc9;tica organizacional">
<node CREATED="1460492977576" ID="ID_1261287842" MODIFIED="1460493049935" TEXT="Determinada pelos valores adotados pela empresa"/>
</node>
<node CREATED="1460492977577" FOLDED="true" ID="ID_1690114553" MODIFIED="1585597357640" TEXT="&#xc9;tica individual">
<node CREATED="1460492977577" ID="ID_1945768976" MODIFIED="1460493047701" TEXT="Determinada pelos valores pessoais, e dependente de fatores externos"/>
<node CREATED="1578352446085" ID="ID_411911306" MODIFIED="1578352451617" TEXT="cada individuo tem sua propria &#xe9;tica"/>
</node>
<node CREATED="1460492977578" FOLDED="true" ID="ID_1041114079" MODIFIED="1585597357640" TEXT="Comportamento individual">
<node CREATED="1524181689551" ID="ID_1239547915" MODIFIED="1524181713958" TEXT="Resultado de um &#xe9;tica individual influenciada pela &#xe9;tica organizacional, que obedece a determinadas pol&#xed;ticas"/>
<node CREATED="1460492990737" ID="ID_1485690290" MODIFIED="1460492991003" TEXT="Influenciados pelos fatores acima, pelas rela&#xe7;&#xf5;es interpessoais e por  objetivos e ambi&#xe7;&#xf5;es pessoais"/>
<node CREATED="1460492995028" ID="ID_1922218662" MODIFIED="1460492995355" TEXT="O conjunto de comportamentos individuais determina a cultura da  organiza&#xe7;&#xe3;o"/>
<node CREATED="1578352552325" ID="ID_866391337" MODIFIED="1578352562913" TEXT="os comportamentos individuais definem a cultura organizacional"/>
</node>
<node CREATED="1460493031238" FOLDED="true" ID="ID_322014537" MODIFIED="1585597357641" TEXT="Comportamentos relevantes para a organiza&#xe7;&#xe3;o">
<node CREATED="1460493031240" ID="ID_1522568379" MODIFIED="1460493036927" TEXT="Em rela&#xe7;&#xe3;o &#xe0; aceita&#xe7;&#xe3;o ou busca de riscos"/>
<node CREATED="1460493031241" ID="ID_958626197" MODIFIED="1460493038308" TEXT="Em rela&#xe7;&#xe3;o &#xe0; obedi&#xea;ncia a pol&#xed;ticas"/>
<node CREATED="1460493031242" FOLDED="true" ID="ID_974484306" MODIFIED="1534894903195" TEXT="Em rela&#xe7;&#xe3;o a resultados negativos">
<node CREATED="1460493286162" ID="ID_1210226753" MODIFIED="1460493295597" TEXT="ex. qual o grau de tolerancia a falhas?"/>
</node>
</node>
<node CREATED="1460514681148" FOLDED="true" ID="ID_204695553" MODIFIED="1578352543626" TEXT="obs">
<node CREATED="1460514684670" ID="ID_9092787" MODIFIED="1460514695032" TEXT="Segundo Aragon, a  cultura  organizacional  e  a  individual  s&#xe3;o  viabilizadores  que t&#xea;m sido subestimados na implanta&#xe7;&#xe3;o da governan&#xe7;a  de TI"/>
<node CREATED="1460514713414" ID="ID_964292450" MODIFIED="1460514738108" TEXT="no Cobit n&#xe3;o existe a cultura organizacional, mas sim o comportamento individual"/>
<node CREATED="1460514740386" ID="ID_1686717626" MODIFIED="1460514756414" TEXT="por&#xe9;m consta no Aragon e foi considerado correto."/>
</node>
</node>
<node COLOR="#cc6600" CREATED="1576633670546" FOLDED="true" ID="ID_865488541" MODIFIED="1585597357641" TEXT="[cespe] A cultura organizacional e a individual s&#xe3;o viabilizadores que t&#xea;m sido subestimados na implanta&#xe7;&#xe3;o da governan&#xe7;a de TI.">
<node CREATED="1576633681163" ID="ID_1349507179" MODIFIED="1576633683998" TEXT="o Cobit faz esse alerta"/>
</node>
</node>
<node CREATED="1460460007949" FOLDED="true" ID="ID_694539373" MODIFIED="1578353188692" TEXT="Processos">
<node CREATED="1460460011717" ID="ID_783011462" MODIFIED="1576633509657" TEXT="Conjunto organizado de pr&#xe1;ticas e atividades para alcance de objetivos e gera&#xe7;&#xe3;o de produtos que suportam metas de TI"/>
<node CREATED="1524181379365" ID="ID_1553794999" MODIFIED="1524181389498" TEXT="Materializam as boas pr&#xe1;ticas"/>
<node CREATED="1460492636416" FOLDED="true" ID="ID_9511993" MODIFIED="1578352733178" TEXT="Metas">
<node CREATED="1460492644735" ID="ID_945942939" MODIFIED="1460492644952" TEXT="Definidas para cada processo, como parte do  cascateamento Neg&#xf3;cio &#xf0e0; TI &#xf0e0; Processo"/>
<node CREATED="1460492651850" FOLDED="true" ID="ID_379238045" MODIFIED="1585597357642" TEXT="Divididas em tr&#xea;s categorias">
<node CREATED="1460492660359" FOLDED="true" ID="ID_1939290181" MODIFIED="1548968278562" TEXT="Intr&#xed;nsecas">
<node CREATED="1460492674476" ID="ID_1324508643" MODIFIED="1460492674855" TEXT="processo preciso, alinhado com as boas pr&#xe1;ticas  e em conformidade com regras internas e externas"/>
</node>
<node CREATED="1460492663170" FOLDED="true" ID="ID_237521081" MODIFIED="1548968278564" TEXT="Contextuais">
<node CREATED="1460492681848" ID="ID_756660451" MODIFIED="1460492682155" TEXT="processo adaptado &#xe0; realidade da organiza&#xe7;&#xe3;o,  relevante, compreens&#xed;vel e de f&#xe1;cil aplica&#xe7;&#xe3;o"/>
</node>
<node CREATED="1460492668831" FOLDED="true" ID="ID_1384610637" MODIFIED="1542760222025" TEXT="Acesso e seguran&#xe7;a">
<node CREATED="1460492687360" ID="ID_828611652" MODIFIED="1460492687608" TEXT="processo fica confidencial, quando  requerido, mas &#xe9; conhecido e acess&#xed;vel por quem precisa"/>
</node>
</node>
</node>
<node CREATED="1460492706221" FOLDED="true" ID="ID_107220827" MODIFIED="1578352731029" TEXT="Pr&#xe1;ticas">
<node CREATED="1460492707482" ID="ID_1275067847" MODIFIED="1460492712313" TEXT="s&#xe3;o desdobradas em atividades"/>
<node CREATED="1460492741126" ID="ID_1466613882" MODIFIED="1481151142037" TEXT="as pr&#xe1;ticas s&#xe3;o descritas de forma gen&#xe9;rica e abrangente"/>
<node CREATED="1578352626388" ID="ID_1298643225" MODIFIED="1578352638553" TEXT="o cobit n&#xe3;o diz o COMO fazer, n&#xe3;o &#xe9; prescritivo, diz O QUE fazer"/>
<node CREATED="1460492715838" FOLDED="true" ID="ID_491150152" MODIFIED="1578352624018" TEXT="Para cada processo, o Cobit sugere pr&#xe1;ticas que s&#xe3;o">
<node CREATED="1460492725078" MODIFIED="1460492725078" TEXT="A&#xe7;&#xf5;es para entregar benef&#xed;cios, otimizar riscos e recursos"/>
<node CREATED="1460492725081" ID="ID_1788047777" MODIFIED="1460492727351" TEXT="Alinhadas com padr&#xf5;es e boas pr&#xe1;ticas geralmente aceitos"/>
<node CREATED="1460492725082" ID="ID_1578378255" MODIFIED="1460492728526" TEXT="Gen&#xe9;ricas, e necessitam ser adaptadas para cada empresa"/>
<node CREATED="1460492725083" ID="ID_1755841421" MODIFIED="1460492729696" TEXT="Abrangentes, cobrindo pap&#xe9;is de TI e neg&#xf3;cios no processo"/>
</node>
<node CREATED="1460492756141" FOLDED="true" ID="ID_1164958721" MODIFIED="1585597357642" TEXT="A estrutura de governan&#xe7;a e gest&#xe3;o da empresa deve">
<node CREATED="1460492760318" ID="ID_701058731" MODIFIED="1460492760318" TEXT="Selecionar as pr&#xe1;ticas aplic&#xe1;veis e decidir quais implementar"/>
<node CREATED="1460492760320" ID="ID_17619377" MODIFIED="1460492792348" TEXT="Adicionar ou adaptar pr&#xe1;ticas quando necess&#xe1;rio"/>
<node CREATED="1460492764667" ID="ID_1922095056" MODIFIED="1460492764930" TEXT="Definir e adicionar pr&#xe1;ticas n&#xe3;o relacionadas &#xe0; TI, para  integra&#xe7;&#xe3;o aos processos de neg&#xf3;cio"/>
<node CREATED="1460492768356" ID="ID_1008457830" MODIFIED="1460492768580" TEXT="Escolher como implementar as pr&#xe1;ticas (frequ&#xea;ncia,  automa&#xe7;&#xe3;o, etc.)"/>
<node CREATED="1460492771996" ID="ID_1426978918" MODIFIED="1460492772297" TEXT="Aceitar o risco de n&#xe3;o implementar pr&#xe1;ticas aplic&#xe1;veis"/>
</node>
</node>
<node CREATED="1460492870747" FOLDED="true" ID="ID_1886849328" MODIFIED="1578352732131" TEXT="Atividades">
<node CREATED="1460492879845" ID="ID_1837605273" MODIFIED="1460492880056" TEXT="Situadas um n&#xed;vel abaixo das pr&#xe1;ticas de governan&#xe7;a e  gest&#xe3;o, as atividades"/>
<node CREATED="1460492884801" ID="ID_107753523" MODIFIED="1460492885096" TEXT="Descrevem um conjunto de passos necess&#xe1;rios e suficientes  para alcan&#xe7;ar a pr&#xe1;tica"/>
<node CREATED="1460492890325" MODIFIED="1460492890325" TEXT="Consideram entradas e sa&#xed;das dos processos"/>
<node CREATED="1460492890326" ID="ID_768607703" MODIFIED="1460492892431" TEXT="S&#xe3;o baseadas em padr&#xf5;es e boas pr&#xe1;ticas geralmente aceitos"/>
<node CREATED="1460492896463" ID="ID_1579407702" MODIFIED="1460492896744" TEXT="Suportam o estabelecimento de pap&#xe9;is e responsabilidades  claras no processo"/>
<node CREATED="1460492900414" ID="ID_1842973035" MODIFIED="1460492900771" TEXT="N&#xe3;o s&#xe3;o prescritivas, e devem ser adaptadas e desenvolvidas  com procedimentos espec&#xed;ficos para a empresa"/>
</node>
<node CREATED="1460515462328" FOLDED="true" ID="ID_175373946" MODIFIED="1576633261377" TEXT="As  tabelas  RACI  (responsible,  accountable,  consult  e  inform) associam  as  atividades  do  processo aos  pap&#xe9;is  individuais  na  organiza&#xe7;&#xe3;o  e  podem  ter  rela&#xe7;&#xe3;o  com  o  habilitador estruturas organizacionais.">
<node COLOR="#cc6600" CREATED="1549317392990" ID="ID_1062117735" MODIFIED="1549317396239" TEXT="[cespe] As tabelas RACI (responsible, accountable, consult e inform) associam as atividades do processo aos pap&#xe9;is individuais na organiza&#xe7;&#xe3;o e podem ter rela&#xe7;&#xe3;o com o habilitador estruturas organizacionais. "/>
</node>
<node COLOR="#cc6600" CREATED="1534896412353" ID="ID_1006639902" MODIFIED="1534896417010" TEXT="[cespe] No ciclo de vida do processo, o gerente pode usar o habilitador para conceb&#xea;-lo, ou seja, definir responsabilidades e desmembr&#xe1;-lo em pr&#xe1;ticas e atividades, bem como definir os produtos do trabalho que nesse processo cabem (entradas e sa&#xed;das). "/>
<node COLOR="#cc6600" CREATED="1576633841275" ID="ID_1208969944" MODIFIED="1576633847305" TEXT="[cespe] o habilitador que se refere a pr&#xe1;ticas e atividades para atingir determinados objetivos e produzir um conjunto de sa&#xed;das para auxiliar na realiza&#xe7;&#xe3;o dos objetivos de TI."/>
</node>
<node CREATED="1460460031532" FOLDED="true" ID="ID_1029160719" MODIFIED="1578353189917" TEXT="Informa&#xe7;&#xe3;o (recursos)">
<node CREATED="1460460041380" ID="ID_1426338014" MODIFIED="1460460041616" TEXT="&#xc9; necess&#xe1;ria para manter a organiza&#xe7;&#xe3;o em funcionamento e bem governada"/>
<node CREATED="1460514024206" FOLDED="true" ID="ID_1379602418" MODIFIED="1542760663172" TEXT=" a  informa&#xe7;&#xe3;o  &#xe9;  considerada  um  ativo que deve ser tratado da mesma forma que qualquer  outro ativo na empresa">
<node CREATED="1460514025644" ID="ID_797279054" MODIFIED="1460514049711" TEXT="o Cespe deu isso como certo, por&#xe9;m no Cobit consta que a informa&#xe7;&#xe3;o &#xe9; um ativo por&#xe9;m n&#xe3;o &#xe9; tratado como qualquer outro"/>
</node>
<node CREATED="1460460068852" ID="ID_494059961" MODIFIED="1460460069119" TEXT="No n&#xed;vel operacional, com grande frequ&#xea;ncia &#xe9; o pr&#xf3;prio produto da organiza&#xe7;&#xe3;o"/>
<node CREATED="1460493324126" FOLDED="true" ID="ID_546456699" MODIFIED="1578353050053" TEXT="Ciclo da Informa&#xe7;&#xe3;o">
<node CREATED="1578352868726" ID="ID_432460845" MODIFIED="1578352868726">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_7927646241462540692.jpeg" />
  </body>
</html></richcontent>
</node>
<node CREATED="1460493364739" ID="ID_1106566904" MODIFIED="1524188524450" TEXT="Os processos geram dados brutos, os dados brutos s&#xe3;o transformados em informa&#xe7;&#xe3;o (ao interpretar os dados)"/>
<node CREATED="1460493387922" ID="ID_367564802" MODIFIED="1460493430046" TEXT="ao analizar a informa&#xe7;&#xe3;o e aplica-la a determinado contexto ela ser&#xe1; transformada em conhecimento"/>
<node CREATED="1460493401439" ID="ID_325014171" MODIFIED="1460493409224" TEXT="ao utilizar esse conhecimento se gera valor"/>
</node>
<node COLOR="#800000" CREATED="1460493348468" FOLDED="true" ID="ID_1582398083" MODIFIED="1585597357642" TEXT="Metas">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1460493352403" FOLDED="true" ID="ID_355170086" MODIFIED="1585597357642" TEXT="Qualidade intr&#xed;nseca &#x2013; valores reais ou verdadeiros">
<node CREATED="1460493352404" ID="ID_265603878" MODIFIED="1460493352404" TEXT="&#xf0a7; Precis&#xe3;o (correta e confi&#xe1;vel)"/>
<node CREATED="1460493352406" ID="ID_410712361" MODIFIED="1460493352406" TEXT="&#xf0a7; Objetividade (imparcial, sem vi&#xe9;s ou preconceito)"/>
<node CREATED="1460493352407" ID="ID_493872691" MODIFIED="1460493352407" TEXT="&#xf0a7; Credibilidade (considerada verdadeira por terceiros)"/>
<node CREATED="1460493352408" ID="ID_495362228" MODIFIED="1460493352408" TEXT="&#xf0a7; Reputa&#xe7;&#xe3;o (v&#xe1;lida em fun&#xe7;&#xe3;o da fonte ou conte&#xfa;do)"/>
</node>
<node CREATED="1460493445734" FOLDED="true" ID="ID_405839101" MODIFIED="1578353053493" TEXT="Qualidade contextual &#x2013; intelig&#xed;vel, clara e aplic&#xe1;vel">
<node CREATED="1460493450023" MODIFIED="1460493450023" TEXT="sempre considerando o contexto da tarefa atual"/>
<node CREATED="1460493458216" ID="ID_1915658765" MODIFIED="1460493467030" TEXT="&#xf0a7; Relev&#xe2;ncia (aplic&#xe1;vel e &#xfa;til)"/>
<node CREATED="1460493458217" ID="ID_946653905" MODIFIED="1460493458217" TEXT="&#xf0a7; Completeza (abrang&#xea;ncia e profundidade)"/>
<node CREATED="1460493458218" ID="ID_1016888551" MODIFIED="1460493458218" TEXT="&#xf0a7; Atualidade (atualizada o suficiente)"/>
<node CREATED="1460493458219" ID="ID_384031041" MODIFIED="1460493458219" TEXT="&#xf0a7; Quantidade apropriada (volume)"/>
<node CREATED="1460493458220" ID="ID_1165227697" MODIFIED="1460493458220" TEXT="&#xf0a7; Representa&#xe7;&#xe3;o concisa (compacta)"/>
<node CREATED="1460493458221" ID="ID_1730999873" MODIFIED="1460493458221" TEXT="&#xf0a7; Representa&#xe7;&#xe3;o consistente (formato)"/>
<node CREATED="1460493458222" ID="ID_376652813" MODIFIED="1460493458222" TEXT="&#xf0a7; Interpretabilidade (linguagens, s&#xed;mbolos e unidades)"/>
<node CREATED="1460493458224" ID="ID_1644462494" MODIFIED="1460493458224" TEXT="&#xf0a7; Compreensibilidade"/>
<node CREATED="1460493458225" ID="ID_1882973689" MODIFIED="1460493458225" TEXT="&#xf0a7; Facilidade de manipula&#xe7;&#xe3;o/uso (inclusive em outras tarefas)"/>
</node>
<node CREATED="1460493506204" FOLDED="true" ID="ID_1595898088" MODIFIED="1534894903200" TEXT="Acesso e seguran&#xe7;a &#x2013; informa&#xe7;&#xe3;o dispon&#xed;vel ou  poss&#xed;vel de se obter">
<node CREATED="1460493515640" ID="ID_99288817" MODIFIED="1460493521823" TEXT="Disponibilidade (dispon&#xed;vel quando requerida, ou recuper&#xe1;vel  de forma f&#xe1;cil e r&#xe1;pida)"/>
<node CREATED="1460493527467" ID="ID_1585972771" MODIFIED="1460493527702" TEXT="Acesso restrito (somente para as partes autorizadas)"/>
</node>
<node CREATED="1460493549388" FOLDED="true" ID="ID_1745943889" MODIFIED="1558574072104" TEXT="Metas x Crit&#xe9;rios">
<icon BUILTIN="full-1"/>
<node CREATED="1460493567031" ID="ID_469707340" MODIFIED="1460493567031">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_6708437749429493136.jpeg"/>
  </body>
</html></richcontent>
</node>
<node COLOR="#cc6600" CREATED="1549317693663" FOLDED="true" ID="ID_9614443" MODIFIED="1558574072103" TEXT="[cespe] A efici&#xea;ncia de uma informa&#xe7;&#xe3;o est&#xe1; relacionada ao atendimento das necessidades do consumidor. ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1549317775502" ID="ID_1902809513" MODIFIED="1549317780211" TEXT="trata-se de efic&#xe1;cia"/>
</node>
<node COLOR="#006699" CREATED="1549317748059" ID="ID_1856417050" MODIFIED="1549317754102" TEXT="Efici&#xea;ncia: informa&#xe7;&#xe3;o &#xe9; obtida e utilizada, estando alinhado ao conceito de &quot;information as a service&quot;. Se a informa&#xe7;&#xe3;o que &#xe9; utilizada pelo consumidor &#xe9; obtida de forma f&#xe1;cil e com a utiliza&#xe7;&#xe3;o de poucos recursos, ent&#xe3;o a utiliza&#xe7;&#xe3;o da informa&#xe7;&#xe3;o &#xe9; considerada eficiente."/>
<node COLOR="#006699" CREATED="1549317748072" ID="ID_400445989" MODIFIED="1549317754187" TEXT="Efic&#xe1;cia:  relacionada com o cumprimento das necessidades de informa&#xe7;&#xe3;o do consumidor que usa a informa&#xe7;&#xe3;o para uma tarefa espec&#xed;fica. Se o consumidor da informa&#xe7;&#xe3;o pode realizar a tarefa com aquela informa&#xe7;&#xe3;o, ent&#xe3;o a informa&#xe7;&#xe3;o &#xe9; eficaz. Isto corresponde &#xe0;s seguintes metas de qualidade da informa&#xe7;&#xe3;o: quantidade apropriada, relev&#xe2;ncia, entendimento, interpreta&#xe7;&#xe3;o e objetividade."/>
<node COLOR="#006699" CREATED="1549317748083" ID="ID_1397098418" MODIFIED="1549317754173" TEXT="Integridade: a informa&#xe7;&#xe3;o &#xed;ntegra &#xe9; aquela que &#xe9; livre de erros e completa. Este aspecto corresponde &#xe0;s seguintes metas de qualidade da informa&#xe7;&#xe3;o: completude e exatid&#xe3;o"/>
<node COLOR="#006699" CREATED="1549317748091" ID="ID_860175976" MODIFIED="1549317754155" TEXT="Confiabilidade: &#xe9; geralmente vista como um sin&#xf4;nimo de exatid&#xe3;o; entretanto, pode-se tamb&#xe9;m dizer que uma informa&#xe7;&#xe3;o &#xe9; de confian&#xe7;a se ela &#xe9; considerada verdadeira e acredit&#xe1;vel (credible). Comparativamente com o conceito de Integridade, Confian&#xe7;a &#xe9; mais subjetiva, dependente de percep&#xe7;&#xf5;es pessoais, e n&#xe3;o somente tang&#xed;vel."/>
<node COLOR="#006699" CREATED="1549317748099" ID="ID_62144360" MODIFIED="1549317754152" TEXT="Disponibilidade: meta da qualidade da info (acessibilidade e seguran&#xe7;a)"/>
<node COLOR="#006699" CREATED="1549317748101" ID="ID_1981583522" MODIFIED="1549317754150" TEXT="Confidencialidade: metas da qualidade da info. (restri&#xe7;&#xe3;o de acesso)"/>
<node COLOR="#006699" CREATED="1549317748102" ID="ID_1702028779" MODIFIED="1549317754148" TEXT="Conformidade: info. deve cumprir as especifica&#xe7;&#xf5;es, coberta por qualquer das metas de qualidade"/>
</node>
</node>
<node CREATED="1460493833151" FOLDED="true" ID="ID_1027910329" MODIFIED="1578353047982" TEXT="Camadas e Atributos (cai em certifica&#xe7;&#xe3;o)">
<node CREATED="1460493877222" ID="ID_1808455146" MODIFIED="1460493886787" TEXT="A informa&#xe7;&#xe3;o pode ser tratado em n&#xed;veis diferentes de abstra&#xe7;&#xe3;o"/>
<node CREATED="1460493839238" FOLDED="true" ID="ID_1343467267" MODIFIED="1585597357642" TEXT="Mundo f&#xed;sico">
<node CREATED="1460493853816" ID="ID_1306832001" MODIFIED="1460493854025" TEXT="onde ocorrem fen&#xf4;menos observ&#xe1;veis  empiricamente"/>
<node CREATED="1460493860268" ID="ID_816061457" MODIFIED="1460493869497" TEXT="Ex. Portador/M&#xed;dia: identifica o suporte f&#xed;sico da informa&#xe7;&#xe3;o"/>
</node>
<node CREATED="1460493842351" FOLDED="true" ID="ID_1247331218" MODIFIED="1585597357643" TEXT="Camada emp&#xed;rica">
<node CREATED="1460493875222" ID="ID_1417939049" MODIFIED="1460493875501" TEXT="observa&#xe7;&#xe3;o dos sinais utilizados para  codificar informa&#xe7;&#xf5;es"/>
<node CREATED="1460493899289" ID="ID_1624260791" MODIFIED="1460493917691" TEXT="Ex. Canal/Meio de acesso: identifica interfaces para acesso &#xe0; informa&#xe7;&#xe3;o"/>
</node>
<node CREATED="1460493845207" FOLDED="true" ID="ID_88889585" MODIFIED="1496652639906" TEXT="Camada sint&#xe1;tica">
<node CREATED="1460493909857" ID="ID_960069909" MODIFIED="1460493910086" TEXT="regras e princ&#xed;pios para constru&#xe7;&#xe3;o de frases"/>
<node CREATED="1460493930336" ID="ID_486256583" MODIFIED="1460493936671" TEXT="Ex. C&#xf3;digo/Linguagem: identifica a linguagem utilizada para codificar a  informa&#xe7;&#xe3;o, bem como as regras para combina&#xe7;&#xe3;o de s&#xed;mbolos"/>
</node>
<node CREATED="1460493848499" FOLDED="true" ID="ID_1686226119" MODIFIED="1496652639907" TEXT="Camada sem&#xe2;ntica">
<node CREATED="1460493943874" ID="ID_569906364" MODIFIED="1460493945509" TEXT="regras para extra&#xe7;&#xe3;o de significado a partir  de estruturas sint&#xe1;ticas"/>
<node CREATED="1460493952929" FOLDED="true" ID="ID_1215196732" MODIFIED="1496652639906" TEXT="Tipo:">
<node CREATED="1460493967905" MODIFIED="1460493967905" TEXT="financeira/n&#xe3;o-financeira, interna x externa, previsto x real"/>
</node>
<node CREATED="1460493955526" FOLDED="true" ID="ID_1042343781" MODIFIED="1496652639907" TEXT="Atualidade:">
<node CREATED="1460493972263" MODIFIED="1460493972263" TEXT="data do fato ou per&#xed;odo referenciado pela informa&#xe7;&#xe3;o"/>
</node>
<node CREATED="1460493958382" FOLDED="true" ID="ID_1120295873" MODIFIED="1496652639907" TEXT="N&#xed;vel:">
<node CREATED="1460493977191" MODIFIED="1460493977191" TEXT="identifica o n&#xed;vel de detalhamento/agrega&#xe7;&#xe3;o da informa&#xe7;&#xe3;o"/>
</node>
</node>
<node CREATED="1460494009260" FOLDED="true" ID="ID_245648395" MODIFIED="1549317369129" TEXT="Camada pragm&#xe1;tica">
<node CREATED="1460494016017" ID="ID_645638569" MODIFIED="1460494034321" TEXT="regras para constru&#xe7;&#xe3;o de estruturas  de comunica&#xe7;&#xe3;o e uso da informa&#xe7;&#xe3;o"/>
<node CREATED="1460494024485" MODIFIED="1460494024485" TEXT="Per&#xed;odo de reten&#xe7;&#xe3;o"/>
<node CREATED="1460494024487" FOLDED="true" ID="ID_506975891" MODIFIED="1549317369127" TEXT="Status da informa&#xe7;&#xe3;o">
<node CREATED="1460494041291" ID="ID_708784895" MODIFIED="1460494041554" TEXT="diferencia dados operacionais e dados  hist&#xf3;ricos"/>
</node>
<node CREATED="1460494029533" FOLDED="true" ID="ID_250667178" MODIFIED="1496652639907" TEXT="Novidade">
<node CREATED="1460494047179" ID="ID_1717258225" MODIFIED="1460494047446" TEXT="identifica se a informa&#xe7;&#xe3;o cria novos conhecimentos ou  apenas confirma os existentes"/>
</node>
<node CREATED="1460494031673" FOLDED="true" ID="ID_351677376" MODIFIED="1496652639908" TEXT="Conting&#xea;ncia">
<node CREATED="1460494054477" ID="ID_1793620613" MODIFIED="1460494054751" TEXT=" identifica a informa&#xe7;&#xe3;o que deve preceder a  informa&#xe7;&#xe3;o atual"/>
</node>
</node>
<node CREATED="1460494062639" FOLDED="true" ID="ID_1391098015" MODIFIED="1496652639908" TEXT="Mundo social">
<node CREATED="1460494067843" ID="ID_423215955" MODIFIED="1460494070375" TEXT="constru&#xed;do a partir do uso de estruturas de  linguagem"/>
<node CREATED="1460494073766" FOLDED="true" ID="ID_1192225074" MODIFIED="1496652639908" TEXT="Contexto">
<node CREATED="1460494079212" ID="ID_597105560" MODIFIED="1460494079456" TEXT=" identifica os contextos nos quais a informa&#xe7;&#xe3;o faz sentido  e gera valor"/>
</node>
</node>
</node>
<node COLOR="#cc6600" CREATED="1548969203134" ID="ID_1252026756" MODIFIED="1549317677433" TEXT="[cespe] No Cobit 5, o habilitador que permeia qualquer organiza&#xe7;&#xe3;o, incluindo todas as informa&#xe7;&#xf5;es produzidas e utilizadas pela organiza&#xe7;&#xe3;o, &#xe9; o habilitador Informa&#xe7;&#xe3;o"/>
<node COLOR="#cc6600" CREATED="1578353042260" FOLDED="true" ID="ID_1725071360" MODIFIED="1585597357643" TEXT="[cespe] A entrega de informa&#xe7;&#xe3;o apropriada para que um executivo de uma empresa tome uma decis&#xe3;o respons&#xe1;vel diz respeito ao requisito de conformidade da informa&#xe7;&#xe3;o.">
<icon BUILTIN="button_cancel"/>
<node CREATED="1578353056524" ID="ID_1367210138" MODIFIED="1578353059409" TEXT="isso &#xe9; confiabilidade"/>
<node CREATED="1578353071645" ID="ID_250633034" MODIFIED="1578353080928" TEXT="conformidade &#xe9; o respeito a normas e regulamentos"/>
</node>
<node COLOR="#cc6600" CREATED="1578353093420" FOLDED="true" ID="ID_829900095" MODIFIED="1585597357643" TEXT="[cespe] A efici&#xea;ncia de uma informa&#xe7;&#xe3;o est&#xe1; relacionada ao atendimento das necessidades do consumidor.">
<icon BUILTIN="button_cancel"/>
<node CREATED="1578353094623" ID="ID_50264217" MODIFIED="1578353100168" TEXT="eficiencia tem a ver com o consumo de recursos"/>
<node CREATED="1578353110028" ID="ID_280580888" MODIFIED="1578353118184" TEXT="atender as necessidades &#xe9; eficiacia e n&#xe3;o eficiencia"/>
</node>
<node COLOR="#cc6600" CREATED="1578353141364" FOLDED="true" ID="ID_374863397" MODIFIED="1585597357643" TEXT="[cespe] Devido ao fato de a informa&#xe7;&#xe3;o ser um ativo e um habilitador, ela &#xe9; tratada apenas no processo governan&#xe7;a.">
<icon BUILTIN="button_cancel"/>
<node CREATED="1578353153068" ID="ID_748604187" MODIFIED="1578353162272" TEXT="informa&#xe7;&#xe3;o &#xe9; tratada em todos os lados no cobit"/>
</node>
</node>
<node CREATED="1460460015261" FOLDED="true" ID="ID_129147362" MODIFIED="1585597357644" TEXT="Estruturas organizacionais">
<node CREATED="1460460018583" ID="ID_595311610" MODIFIED="1576633505265" TEXT="Inst&#xe2;ncias de tomada de decis&#xe3;o na organiza&#xe7;&#xe3;o, n&#xe3;o &#xe9; estrutura organizacional"/>
<node CREATED="1576633268170" ID="ID_788290693" MODIFIED="1576633284646" TEXT="p os processos funcionarem, deve haver estruturas organizacionais"/>
<node CREATED="1460460042563" ID="ID_1505855862" MODIFIED="1576633285850" TEXT="estrutura necess&#xe1;ria para que os processos possam funcionar"/>
<node CREATED="1460460075618" ID="ID_1677455176" MODIFIED="1460460088813" TEXT="S&#xe3;o estrutura organizacionais da governan&#xe7;a"/>
<node CREATED="1460492911832" FOLDED="true" ID="ID_1804158833" MODIFIED="1578433333195" TEXT="Pr&#xe1;ticas">
<node CREATED="1460492917264" FOLDED="true" ID="ID_453169077" MODIFIED="1534894903191" TEXT="Princ&#xed;pios operacionais">
<node CREATED="1460492938063" ID="ID_965168181" MODIFIED="1460492938339" TEXT="Defini&#xe7;&#xf5;es pr&#xe1;ticas sobre como a estrutura opera, tais como frequ&#xea;ncia de  reuni&#xf5;es e documenta&#xe7;&#xe3;o"/>
</node>
<node CREATED="1460492919479" FOLDED="true" ID="ID_276310650" MODIFIED="1496652639903" TEXT="Composi&#xe7;&#xe3;o">
<node CREATED="1460492943954" MODIFIED="1460492943954" TEXT="Membros da estrutura, sejam stakeholders internos ou externos"/>
</node>
<node CREATED="1460492922199" FOLDED="true" ID="ID_899954589" MODIFIED="1496652639903" TEXT="Amplitude de controle">
<node CREATED="1460492947748" MODIFIED="1460492947748" TEXT="Limites para decis&#xe3;o na estrutura organizacional"/>
</node>
<node CREATED="1460492924734" FOLDED="true" ID="ID_694025522" MODIFIED="1534895021654" TEXT="N&#xed;vel de autoridade/direitos de decis&#xe3;o">
<node CREATED="1460492951998" MODIFIED="1460492951998" TEXT="Decis&#xf5;es que a estrutura &#xe9; autorizada a tomar"/>
</node>
<node CREATED="1460492928470" FOLDED="true" ID="ID_1468462305" MODIFIED="1534895020454" TEXT="Delega&#xe7;&#xe3;o de autoridade">
<node CREATED="1460492957807" ID="ID_432316292" MODIFIED="1460492960134" TEXT="A estrutura pode delegar parte de seus direitos para outras estruturas abaixo"/>
</node>
<node CREATED="1460492932915" FOLDED="true" ID="ID_892354675" MODIFIED="1534895019560" TEXT="Procedimentos de escala&#xe7;&#xe3;o">
<node CREATED="1460492965350" MODIFIED="1460492965350" TEXT="Descreve as a&#xe7;&#xf5;es requeridas em caso de problemas na tomada de decis&#xe3;o"/>
</node>
</node>
<node COLOR="#cc6600" CREATED="1576633734202" FOLDED="true" ID="ID_652642981" MODIFIED="1585597357643" TEXT="[cespe] As tabelas RACI (responsible, accountable, consult e inform) associam as atividades do processo aos pap&#xe9;is individuais na organiza&#xe7;&#xe3;o e podem ter rela&#xe7;&#xe3;o com o habilitador estruturas organizacionais.">
<node CREATED="1576633741481" ID="ID_1804831182" MODIFIED="1576633755943" TEXT="p cada processo, ha uma matriz RACI dizendo as praticas e os papeis envolvidos"/>
<node CREATED="1576633759618" ID="ID_530632090" MODIFIED="1576633809574" TEXT="qdo se trata de resonsabilidade de tomada de decis&#xe3;o, a matriz raci &#xe9; aplicada nessas estruturas"/>
</node>
<node COLOR="#cc6600" CREATED="1578353131643" ID="ID_1971168778" MODIFIED="1578353134588" TEXT="[cespe] As estruturas predefinidas no COBIT 5 incluem o conselho de arquitetura, respons&#xe1;vel pela orienta&#xe7;&#xe3;o dos assuntos e das decis&#xf5;es sobre a arquitetura corporativa da organiza&#xe7;&#xe3;o."/>
</node>
<node CREATED="1460460073722" FOLDED="true" ID="ID_1891765324" MODIFIED="1578352939641" TEXT="Servi&#xe7;os, infraestrutura e aplicativos (recursos)">
<node CREATED="1460460098432" ID="ID_1484329130" MODIFIED="1460460098589" TEXT="Incluem a infraestrutura, a tecnologia e as aplica&#xe7;&#xf5;es que fornecem processamento e servi&#xe7;os de TI para a organiza&#xe7;&#xe3;o"/>
</node>
<node CREATED="1460460102952" FOLDED="true" ID="ID_716726464" MODIFIED="1578352940872" TEXT="Pessoas, habilidades e compet&#xea;ncias (recursos)">
<node CREATED="1460460106824" ID="ID_1667897917" MODIFIED="1460460107005" TEXT="Necess&#xe1;rias para a realiza&#xe7;&#xe3;o das atividades, para tomada de decis&#xf5;es corretas e implementa&#xe7;&#xe3;o de a&#xe7;&#xf5;es corretivas"/>
<node COLOR="#cc6600" CREATED="1549317856366" FOLDED="true" ID="ID_236848930" MODIFIED="1585597357644" TEXT="[cespe] As pessoas envolvidas nos processos de tecnologia da informa&#xe7;&#xe3;o (TI) de uma empresa s&#xe3;o consideradas recursos de TI caso sejam funcion&#xe1;rios internos da empresa. ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1576633589969" ID="ID_1475696422" MODIFIED="1576633612878" TEXT="n&#xe3;o existe essa restri&#xe7;&#xe3;o"/>
<node CREATED="1576633597762" ID="ID_404281191" MODIFIED="1576633661854" TEXT="pessoas s&#xe3;o TODAS aquelas envolvidas no processo"/>
<node COLOR="#006699" CREATED="1549317947526" ID="ID_541375846" MODIFIED="1549317960486" TEXT="&quot;Alguns dos habilitadores definidos acima tamb&#xe9;m s&#xe3;o recursos da organiza&#xe7;&#xe3;o que devem ser gerenciados e governados."/>
<node COLOR="#006699" CREATED="1549317947536" FOLDED="true" ID="ID_286415239" MODIFIED="1576633629518" TEXT="Isto se aplica:">
<node COLOR="#006699" CREATED="1549317947539" ID="ID_1180060098" MODIFIED="1549317973626" TEXT="- A Informa&#xe7;&#xe3;o, que deve ser gerenciada como um recurso. Algumas informa&#xe7;&#xf5;es, tais como relat&#xf3;rios de gest&#xe3;o e informa&#xe7;&#xf5;es de intelig&#xea;ncia organizacional s&#xe3;o importantes habilitadores para a governan&#xe7;a e gest&#xe3;o da organiza&#xe7;&#xe3;o."/>
<node COLOR="#006699" CREATED="1549317947551" ID="ID_665082512" MODIFIED="1549317959622" TEXT="- Servi&#xe7;os, infraestrutura e aplicativos."/>
<node COLOR="#006699" CREATED="1549317947554" ID="ID_1091869889" MODIFIED="1549317959619" TEXT="- Pessoas, habilidades e compet&#xea;ncias.&quot;"/>
</node>
<node CREATED="1549317976958" ID="ID_1711661855" MODIFIED="1576633640142" TEXT="pessoas tbm pode ser recurso da Organiza&#xe7;&#xe3;o (n&#xe3;o da TI)"/>
</node>
</node>
</node>
<node CREATED="1460460232217" FOLDED="true" ID="ID_518188872" MODIFIED="1585597769054" TEXT="Dimens&#xf5;es dos Facilitadores ">
<icon BUILTIN="full-3"/>
<node CREATED="1576633896674" ID="ID_1736726515" MODIFIED="1576633906126" TEXT="aqui se diz a estrutura padr&#xe3;o para descrever os habilitadores"/>
<node CREATED="1460460235785" FOLDED="true" ID="ID_1080646218" MODIFIED="1585597357645" TEXT="Dimens&#xf5;es comuns, compartilhadas por todos os facilitadores">
<node CREATED="1460460240888" ID="ID_1644387021" MODIFIED="1460460241045" TEXT="Oferecem uma forma simples e estruturada de lidar com os facilitadores"/>
<node CREATED="1460460244160" ID="ID_406517693" MODIFIED="1460460244461" TEXT="&#x201c;Permitem que uma entidade gerencie suas intera&#xe7;&#xf5;es complexas&#x201d;"/>
<node CREATED="1460460246720" ID="ID_466709882" MODIFIED="1460460247157" TEXT="Facilitam resultados de sucesso dos facilitadores"/>
</node>
<node CREATED="1460460252553" ID="ID_184944562" MODIFIED="1460460252796" TEXT="Algumas categorias de facilitadores acrescentam elementos adicionais &#xe0;s dimens&#xf5;es"/>
<node CREATED="1460460262255" ID="ID_720851613" MODIFIED="1585597764671" TEXT="Dimens&#xf5;es e Desempenho">
<node CREATED="1460460269364" ID="ID_472914277" MODIFIED="1460460269364">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_2097883952424591930.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1576634001633" ID="ID_1431703995" MODIFIED="1576634016062" TEXT="todos os 7 habilitadores s&#xe3;o descritos usando essa estrutura"/>
<node CREATED="1460460304573" ID="ID_1632775481" MODIFIED="1460460378669" TEXT="Para cada uma das dimens&#xf5;es se tem indicadores que ir&#xe3;o medir se as partes interessadas foram atendidas, se os objetivos foram alcan&#xe7;ados, se o ciclo de vida foi implementado e gerenciado de forma adequada e se executei as boas pr&#xe1;ticas da maneira prevista."/>
<node CREATED="1576634114361" ID="ID_1483864682" MODIFIED="1576634428492" TEXT="com base nas 4 dimens&#xf5;es &#xe9; possivel medir os habilitadores,avaliar o desempenho dos habilitadores"/>
<node CREATED="1524183406233" FOLDED="true" ID="ID_703711024" MODIFIED="1585597357646" TEXT="As 2 primeiras dimens&#xf5;es (partes interessadas e objetivos) s&#xe3;o para todos os habilitadores">
<node CREATED="1524183447672" ID="ID_746032164" MODIFIED="1524183454863" TEXT="diz qual o resultado q o habilitador tem q entregar e pra quem"/>
<node CREATED="1576634215338" ID="ID_742135411" MODIFIED="1576634227902" TEXT="se avalio se o objetivo foi ou n&#xe3;o cumprido, estou avaliando o resultado"/>
<node CREATED="1576634228130" ID="ID_1912155383" MODIFIED="1576634241341" TEXT="se avalio se as partes interessadas foram ou n&#xe3;o cumpridas, estou avaliando o resultado"/>
<node CREATED="1576634181881" FOLDED="true" ID="ID_897936232" MODIFIED="1585597357645" TEXT="s&#xe3;o os indicadores de alcance de meta">
<node CREATED="1460460658065" FOLDED="true" ID="ID_895305340" MODIFIED="1585597357645" TEXT="KGI (indicador chave de meta)">
<node CREATED="1460460660802" ID="ID_1907071983" MODIFIED="1460460671818" TEXT="executa a atividade, me&#xe7;o se a mesma foi executada a contento ou n&#xe3;o"/>
<node CREATED="1460460724829" ID="ID_1016105800" MODIFIED="1460460735705" TEXT="mede o resultado da atividade"/>
<node CREATED="1460491677219" ID="ID_1938678190" MODIFIED="1460491692399" TEXT="Partes Interessadas e Objetivos s&#xe3;o medidos pelo indicador de resultados - KGI"/>
</node>
</node>
</node>
<node CREATED="1524183484155" FOLDED="true" ID="ID_1024947245" MODIFIED="1585597357646" TEXT="Nos ultimos indicadores (ciclo de vida e boas pr&#xe1;ticas) ha avalia&#xe7;&#xe3;o da performance na execu&#xe7;&#xe3;o">
<node CREATED="1524183385608" ID="ID_1674890331" MODIFIED="1524183508713" TEXT="Diz qual Ciclo de Vida de implementa&#xe7;&#xe3;o e operaao do habilitador e quais as boas pr&#xe1;ticas devem acontecer para que o resultado seja entregue"/>
<node CREATED="1576634291002" ID="ID_1289312525" MODIFIED="1576634305782" TEXT="verfica se o habilitador est&#xe1; sendo implementado e gerenciado de foram adequada"/>
<node CREATED="1576634317041" FOLDED="true" ID="ID_223302431" MODIFIED="1585597357646" TEXT="essa avalia&#xe7;&#xe3;o &#xe9; analisada com base no chamado indicador de desempenho/performance">
<node CREATED="1460460672904" FOLDED="true" ID="ID_889819049" MODIFIED="1585597357646" TEXT="KPI (indicador chave de performance)">
<node CREATED="1460460674321" ID="ID_362268831" MODIFIED="1460460748752" TEXT="executa o processo, mede se o objetivo do processo foi alcan&#xe7;ado ou n&#xe3;o"/>
<node CREATED="1460460753939" ID="ID_1816563786" MODIFIED="1460464037101" TEXT="&#xe9; um indicador de desempenho, "/>
<node CREATED="1460460766363" ID="ID_1347170760" MODIFIED="1481142774038" TEXT="dado que eu fiz o processo, acho q alcan&#xe7;arei o objetivo de TI"/>
<node CREATED="1460491694582" ID="ID_1965131131" MODIFIED="1460491740674" TEXT="Ciclo de Vida e Boas Pr&#xe1;ticas mede o resultado do que e do como est&#xe1; sendo feito, mede os processos - KPI"/>
</node>
</node>
</node>
<node CREATED="1460491772661" ID="ID_187919649" MODIFIED="1576634439007" TEXT="Os indicadores medem ou resultado ou desempenho, nunca os 2 juntos"/>
<node CREATED="1460513826832" FOLDED="true" ID="ID_1143892549" MODIFIED="1585597357646" TEXT="O ciclo de vida dos viabilizadores constitui-se de">
<node CREATED="1460513838043" ID="ID_1982322074" MODIFIED="1460513842191" TEXT="Planejar"/>
<node CREATED="1460513842400" ID="ID_1230920788" MODIFIED="1460513844729" TEXT="Projetar"/>
<node CREATED="1460513845501" ID="ID_698620246" MODIFIED="1460513860415" TEXT="Desenvolver/Adquirir/Criar/Implementar"/>
<node CREATED="1460513861126" ID="ID_924668084" MODIFIED="1460513863876" TEXT="Usar/Operar"/>
<node CREATED="1460513864492" ID="ID_548100145" MODIFIED="1460513868455" TEXT="Avaliar/Monitorar"/>
<node CREATED="1460513868883" ID="ID_997498817" MODIFIED="1460513873338" TEXT="Atualizar/Descartar"/>
<node COLOR="#cc6600" CREATED="1576634633168" ID="ID_1867013510" MODIFIED="1576634635833" TEXT="[cespe] A dimens&#xe3;o do ciclo de vida dos viabilizadores (enablers) constitui-se, entre outras, das a&#xe7;&#xf5;es de planejar; construir, adquirir e implementar; monitorar e avaliar."/>
</node>
<node CREATED="1524183344638" ID="ID_1672158281" MODIFIED="1524183366662" TEXT="Para cada habilitador &#xe9; necess&#xe1;rio saber quem s&#xe3;o as partes interessadas e quais os meus objetivos/metas na estrutura de cascateamento"/>
<node COLOR="#cc6600" CREATED="1576634660985" FOLDED="true" ID="ID_1782112242" MODIFIED="1585597357647" TEXT="[cespe] No ciclo de vida do processo, o gerente pode usar o habilitador para conceb&#xea;-lo, ou seja, definir responsabilidades e desmembr&#xe1;-lo em pr&#xe1;ticas e atividades, bem como definir os produtos do trabalho que nesse processo cabem (entradas e sa&#xed;das).">
<node CREATED="1576634698066" ID="ID_1743430336" MODIFIED="1576634734653" TEXT="certo, pois o habilitador processo tem a descri&#xe7;&#xe3;o dos processos (suas praticas, seus responsaveis tec..)"/>
</node>
<node COLOR="#cc6600" CREATED="1576634812229" FOLDED="true" ID="ID_341663330" MODIFIED="1585597357647" TEXT="[fcc] Quando o gestor busca descobrir, na aplica&#xe7;&#xe3;o e no uso de habilitadores embasados no COBIT, se&#xa;as necessidades das partes interessadas foram consideradas, se as metas do habilitador foram&#xa;alcan&#xe7;adas e se as boas pr&#xe1;ticas foram aplicadas, ele">
<node CREATED="1576634819549" MODIFIED="1576634819549" TEXT="(A) gerencia o ciclo de vida do habilitador."/>
<node CREATED="1576634819550" MODIFIED="1576634819550" TEXT="(B) realiza a seguran&#xe7;a da informa&#xe7;&#xe3;o da organiza&#xe7;&#xe3;o."/>
<node CREATED="1576634819551" ID="ID_1379576628" MODIFIED="1576634821959" TEXT="(C) trabalha no controle de desempenho do habilitador.">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1576634819552" MODIFIED="1576634819552" TEXT="(D) gerencia partes interessadas internas e externas."/>
</node>
</node>
</node>
<node CREATED="1460460612371" FOLDED="true" ID="ID_1408115469" MODIFIED="1576634694546" TEXT="&#x201c;Metas Gen&#xe9;ricas&#x201d; dos facilitadores">
<node CREATED="1460491854347" ID="ID_920809737" MODIFIED="1460491867087" TEXT="A ideia &#xe9; que todos os indicadores tenham essas metas, independente da especificidade de cada um"/>
<node CREATED="1576634602472" ID="ID_132208660" MODIFIED="1576634615598" TEXT="todos os habilitadores tem metas desses 3 tipos:"/>
<node CREATED="1460491841243" FOLDED="true" ID="ID_1847686171" MODIFIED="1585597357647" TEXT="Qualidade Intr&#xed;nseca">
<node CREATED="1460491851792" ID="ID_678552636" MODIFIED="1460491852079" TEXT="Funcionar com precis&#xe3;o e objetividade para fornecer informa&#xe7;&#xf5;es  precisas, objetivas e resultados respeit&#xe1;veis "/>
</node>
<node CREATED="1460491844826" FOLDED="true" ID="ID_894972537" MODIFIED="1585597357647" TEXT="Qualidade Contextual">
<node CREATED="1460491885139" ID="ID_233102775" MODIFIED="1460491885368" TEXT="Facilitadores e seus resultados s&#xe3;o adequados &#xe0; finalidade, dado o  contexto em que operam"/>
<node CREATED="1460491889055" ID="ID_346061888" MODIFIED="1460491889321" TEXT="Resultados devem ser relevantes, completos, atuais, adequados,  coerentes, intelig&#xed;veis e f&#xe1;ceis de usar"/>
</node>
<node CREATED="1460491847698" FOLDED="true" ID="ID_514218058" MODIFIED="1585597357647" TEXT="Acesso e seguran&#xe7;a">
<node CREATED="1460491897171" ID="ID_1720560686" MODIFIED="1460491897171" TEXT="Facilitadores est&#xe3;o dispon&#xed;veis quando, e se, necess&#xe1;rio"/>
<node CREATED="1460491897178" ID="ID_159553250" MODIFIED="1460491899359" TEXT="O acesso aos resultados &#xe9; restrito a quem tem direito e necessita"/>
</node>
</node>
<node COLOR="#cc6600" CREATED="1549317595975" FOLDED="true" ID="ID_1635390017" MODIFIED="1566339364567" TEXT="[cespe] Partes interessadas, cultura, &#xe9;tica, comportamento das pessoas e comportamento da organiza&#xe7;&#xe3;o s&#xe3;o categorias de habilitadores no COBIT 5. ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1549317612581" ID="ID_929875832" MODIFIED="1549317612581" TEXT="Partes interessadas s&#xe3;o umas das 4 dimens&#xf5;es dos habilitadores (partes interessadas, objetivos, ciclo de vida e boas pr&#xe1;ticas)"/>
</node>
</node>
<node COLOR="#cc6600" CREATED="1535914840111" ID="ID_1189445368" MODIFIED="1535914843622" TEXT="[cespe] O COBIT 5 descreve um modelo &#xfa;nico e integrado de princ&#xed;pios que permite governar e gerir a TI de forma hol&#xed;stica para toda a organiza&#xe7;&#xe3;o, o que abrange todas as &#xe1;reas respons&#xe1;veis pelas fun&#xe7;&#xf5;es de TI e considera tanto os interesses internos quanto os interesses externos relacionados &#xe0; TI. "/>
</node>
<node CREATED="1460458034995" FOLDED="true" ID="ID_1083603995" MODIFIED="1585597782800" TEXT="5. Distinguir a governan&#xe7;a da gest&#xe3;o">
<icon BUILTIN="full-7"/>
<node CREATED="1460512563605" ID="ID_1172160995" MODIFIED="1585597587533" TEXT="Governan&#xe7;a">
<node CREATED="1460512570375" ID="ID_1325326111" MODIFIED="1460512570578" TEXT="Responsabilidade do conselho de administra&#xe7;&#xe3;o (board of directors), sob a lideran&#xe7;a do Presidente (chairperson)"/>
<node COLOR="#808000" CREATED="1534895736725" ID="ID_265164901" MODIFIED="1534895758554" TEXT="A governan&#xe7;a garante que as necessidades, condi&#xe7;&#xf5;es e op&#xe7;&#xf5;es das partes interessadas sejam avaliadas a fim de determinar objetivos corporativos acordados e equilibrados; definindo a dire&#xe7;&#xe3;o atrav&#xe9;s de prioriza&#xe7;&#xf5;es e tomadas de decis&#xe3;o; e monitorando o desempenho e a conformidade com a dire&#xe7;&#xe3;o e os objetivos estabelecidos."/>
</node>
<node CREATED="1460512573975" FOLDED="true" ID="ID_177480516" MODIFIED="1585597357648" TEXT="Gest&#xe3;o">
<node CREATED="1460512579082" ID="ID_1752101801" MODIFIED="1460512579270" TEXT="Responsabilidade da ger&#xea;ncia executiva, sob a lideran&#xe7;a do Diretor  Executivo (CEO)"/>
<node CREATED="1578351808413" ID="ID_402716069" MODIFIED="1578351821250" TEXT="assunto do corpo direitivo (presidente, vice-pres, diretoria)"/>
</node>
<node CREATED="1460512583667" FOLDED="true" ID="ID_1373414186" MODIFIED="1542761416483" TEXT="Al&#xe9;m do n&#xed;vel de responsabilidade, governan&#xe7;a e gest&#xe3;o...">
<node CREATED="1460512587868" ID="ID_993181174" MODIFIED="1460512590045" TEXT="Envolvem diferentes tipos de atividades"/>
<node CREATED="1460512587868" ID="ID_643067774" MODIFIED="1460512591286" TEXT="Requerem estruturas organizacionais diferentes"/>
<node CREATED="1460512587868" ID="ID_763336149" MODIFIED="1460512592763" TEXT="Servem a prop&#xf3;sitos diferentes"/>
</node>
<node CREATED="1460512683965" ID="ID_1478920025" MODIFIED="1585597593067" TEXT="Governan&#xe7;a x Gest&#xe3;o">
<node CREATED="1460512767752" ID="ID_1174854228" MODIFIED="1585597595027" TEXT="Governan&#xe7;a">
<node CREATED="1460512773572" ID="ID_537810165" MODIFIED="1524183966818" TEXT="GARANTE que os objetivos de neg&#xf3;cios sejam alcan&#xe7;ados."/>
<node CREATED="1460512818146" ID="ID_1113262968" MODIFIED="1460512824724" TEXT="Cobra para saber se est&#xe1; sendo feito corretamente"/>
<node CREATED="1578351860454" ID="ID_647112749" MODIFIED="1578351868842" TEXT="responsavel por garantir q a gestao alcance os objetivos"/>
<node CREATED="1460512790193" ID="ID_1018689596" MODIFIED="1585597603091" TEXT="Para isso:">
<node CREATED="1460512794123" ID="ID_1689110245" MODIFIED="1460512794123" TEXT="&#xf0a7; Avalia necessidades dos stakeholders e alternativas de a&#xe7;&#xe3;o"/>
<node CREATED="1460512794123" ID="ID_1259750400" MODIFIED="1460512794123" TEXT="&#xf0a7; Dirige as a&#xe7;&#xf5;es pela tomada de decis&#xf5;es e prioriza&#xe7;&#xe3;o"/>
<node CREATED="1460512794123" ID="ID_1310451837" MODIFIED="1460512794123" TEXT="&#xf0a7; Monitora desempenho, conformidade e progresso das a&#xe7;&#xf5;es"/>
</node>
</node>
<node CREATED="1460512802378" FOLDED="true" ID="ID_1180852389" MODIFIED="1585597357649" TEXT="Gest&#xe3;o">
<node CREATED="1524183981218" ID="ID_875625101" MODIFIED="1524183990979" TEXT="objetiva ALCAN&#xc7;AR (fazer) os objetivos"/>
<node CREATED="1460512805664" FOLDED="true" ID="ID_1263804988" MODIFIED="1548968278593" TEXT="Atividades para alcance dos objetivos">
<node CREATED="1460512809898" MODIFIED="1460512809898" TEXT="&#xf0a7; Planejamento (plan)"/>
<node CREATED="1460512809898" MODIFIED="1460512809898" TEXT="&#xf0a7; Constru&#xe7;&#xe3;o (build)"/>
<node CREATED="1460512809898" MODIFIED="1460512809898" TEXT="&#xf0a7; Execu&#xe7;&#xe3;o (run)"/>
<node CREATED="1460512809898" MODIFIED="1460512809898" TEXT="&#xf0a7; Monitoramento (monitor)"/>
</node>
</node>
<node CREATED="1460513500670" ID="ID_152710536" MODIFIED="1460513502049" TEXT="a  governan&#xe7;a  visa  conhecer  as necessidades  dos  envolvidos  (stakeholders)  e  direcionar esfor&#xe7;os  para  que  os  objetivos  organizacionais  sejam alcan&#xe7;ados; a gest&#xe3;o deve planejar, executar e monitorar  as atividades alinhadas &#xe0; governan&#xe7;a."/>
<node CREATED="1460515001658" ID="ID_813084698" MODIFIED="1524184052644" TEXT="Diferentemente  da  governan&#xe7;a,  a  gest&#xe3;o  corresponde  ao planejamento,  ao  desenvolvimento,  &#xe0; execu&#xe7;&#xe3;o  e  ao monitoramento  das  atividades  em  conson&#xe2;ncia  com  a dire&#xe7;&#xe3;o  definida,  a  fim  de atingir-se  os  objetivos  corporativos"/>
<node CREATED="1460512846689" FOLDED="true" ID="ID_1965325363" MODIFIED="1585597357649" TEXT="Estrutura">
<node CREATED="1460512848643" ID="ID_1538648081" MODIFIED="1460512848643">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_3715736161677259353.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1460513153487" ID="ID_1255079162" MODIFIED="1460513166119" TEXT=" o  dom&#xed;nio Avaliar, Direcionar e Monitorar (EDM &#x2013; Evaluate,  Direct  and  Monitor),  afeto  diretamente  &#xe0;  governan&#xe7;a  e  relacionado a ISO 38500"/>
</node>
<node CREATED="1460512981890" FOLDED="true" ID="ID_956340769" MODIFIED="1578351993274" TEXT="Processos">
<node CREATED="1460512983711" ID="ID_824044768" MODIFIED="1460512983711">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_3669886171315114254.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#cc6600" CREATED="1578351999906" ID="ID_1892600332" MODIFIED="1578352005509" TEXT="[cespe] O COBIT 5 possui cinco dom&#xed;nios, sendo um deles o dom&#xed;nio Avaliar, Direcionar e Monitorar (EDM &#x2013; Evaluate, Direct and Monitor), afeto diretamente &#xe0; governan&#xe7;a e relacionado a ISO 38500."/>
<node COLOR="#cc6600" CREATED="1578352020141" FOLDED="true" ID="ID_70305102" MODIFIED="1585597357649" TEXT="[cespe] Segundo o COBIT 5, a governan&#xe7;a visa conhecer as necessidades dos envolvidos (stakeholders) e direcionar esfor&#xe7;os para que os objetivos organizacionais sejam alcan&#xe7;ados; a gest&#xe3;o deve planejar, executar e monitorar as atividades alinhadas &#xe0; governan&#xe7;a.">
<node CREATED="1578352026126" ID="ID_1035996958" MODIFIED="1578352036858" TEXT="faltou monitorar, mesmo assim est&#xe1; correto (ele n&#xe3;o limitou)"/>
</node>
<node COLOR="#cc6600" CREATED="1578352044630" FOLDED="true" ID="ID_1822372853" MODIFIED="1585597357649" TEXT="[cespe] A integra&#xe7;&#xe3;o da governan&#xe7;a corporativa &#xe0; gest&#xe3;o de TI consiste em um dos princ&#xed;pios do COBIT.">
<icon BUILTIN="button_cancel"/>
<node CREATED="1578352056494" ID="ID_496649898" MODIFIED="1578352066137" TEXT="n&#xe3;o &#xe9; a integra&#xe7;&#xe3;o, &#xe9; a distin&#xe7;&#xe3;o entre gov e gest&#xe3;o"/>
</node>
<node COLOR="#cc6600" CREATED="1578352088143" ID="ID_532573516" MODIFIED="1578352091023" TEXT="[cespe] Diferentemente da governan&#xe7;a, a gest&#xe3;o corresponde ao planejamento, ao desenvolvimento, &#xe0; execu&#xe7;&#xe3;o e ao monitoramento das atividades em conson&#xe2;ncia com a dire&#xe7;&#xe3;o definida, a fim de atingir-se os objetivos corporativos."/>
<node COLOR="#cc6600" CREATED="1585597627893" ID="ID_1763246902" MODIFIED="1585597649497" TEXT="[cespe] Assinale a op&#xe7;&#xe3;o que apresenta a disciplina que, no COBIT 5, garante que as necessidades, condi&#xe7;&#xf5;es e op&#xe7;&#xf5;es das partes interessadas sejam avaliadas para determinar objetivos corporativos balanceados e acordados a serem atingidos, estabelecendo prioridades, tomando decis&#xf5;es e monitorando o desempenho e a conformidade em rela&#xe7;&#xe3;o &#xe0; dire&#xe7;&#xe3;o e aos objetivos acordados.  GOVERNAN&#xc7;A"/>
</node>
<node CREATED="1460458273184" FOLDED="true" ID="ID_1495392225" MODIFIED="1578352123023" TEXT="Resumo">
<node CREATED="1460458092697" ID="ID_1605489557" MODIFIED="1460458092697">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_885371223574092686.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1524180865387" ID="ID_231726164" MODIFIED="1524184280459" TEXT="Para &quot;Atender as necessidades dos stakeholders&quot; &#xe9; preciso entender as necessidades de cria&#xe7;&#xe3;o de valor, estabelecer/decidir sobre os beneficios, riscos e recursos a ser providos, traduzindo isso em objetivos corporativos, de TI e habilitadores. Para atender esses objetivos, coloca eles como parte do meu sistema de governan&#xe7;a e pendura embaixo  deles os habilitadores, definindo um escopo de atua&#xe7;&#xe3;o q ser&#xe1; operado por aqueles pap&#xe9;is. Usa um modelo unico integrado que vai definir/trazer pra mim 7 habilitadores. Estes habilitadores permitem uma abordagem hol&#xed;stica pq tem q pegar o sistema de governan&#xe7;a inteiro abrangendo toda organiza&#xe7;&#xe3;o. Para atender as necessidade dos stakeholders, gerando valor, temos a Governan&#xe7;a e a Gest&#xe3;o."/>
<node CREATED="1574907191589" ID="ID_578380750" MODIFIED="1574907637178" TEXT="para atender as necessidades dos stakeholders, preciso de um sistema de governan&#xe7;a e gest&#xe3;o que cobre a organiza&#xe7;&#xe3;o inteira (cobrir a organiza&#xe7;&#xe3;o de ponta a ponta). Para montar esse sistema, usa-se o cobit 5 como modelo unico e integrado que oferece todo o conhecimento p fazer o sistema funcionar. Isso est&#xe1; no Cobit organizado em 7 habilitadores que permitem a abordagem holistica (descrito no principio Permitir uma abordagem holistica). O ultimo principio apenas diferencia Gov de Gest&#xe3;o"/>
</node>
<node COLOR="#cc6600" CREATED="1574907744034" ID="ID_747996981" MODIFIED="1574907746954" TEXT="[cespe] Esse modelo agrupa cinco princ&#xed;pios que permitem &#xe0;s corpora&#xe7;&#xf5;es constru&#xed;rem um framework efetivo de governan&#xe7;a e gest&#xe3;o, baseado em um conjunto de sete viabilizadores (enablers), que otimizam os investimentos em tecnologia e informa&#xe7;&#xe3;o, assim como seu uso em benef&#xed;cio das partes interessadas"/>
</node>
<node CREATED="1524214582935" FOLDED="true" ID="ID_1382031987" MODIFIED="1585597772695" POSITION="right" TEXT="Modelo de Implementa&#xe7;&#xe3;o ">
<node CREATED="1524214604193" ID="ID_1527464154" MODIFIED="1524214604193">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_9108031925428456235.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1579118987165" ID="ID_554465260" MODIFIED="1579119030465" TEXT="visa servir de guia p as a&#xe7;&#xf5;es necessarias p direcionar um esfor&#xe7;o de implementa&#xe7;&#xe3;o e melhoria de processos de gest&#xe3;o usando o cobit"/>
<node CREATED="1579119007268" ID="ID_222773828" MODIFIED="1579119018897" TEXT="guia de como implementar o cobit numa organiza&#xe7;&#xe3;o"/>
<node CREATED="1579119066260" ID="ID_107411554" MODIFIED="1579119071073" TEXT="baseado no modelo de melhoria do ITIL"/>
<node CREATED="1524214709342" FOLDED="true" ID="ID_769415879" MODIFIED="1579119227946" TEXT="Ciclo externo">
<node CREATED="1524214747042" ID="ID_850557468" MODIFIED="1524214759528" TEXT="Se equivale ao modelo de melhora cont&#xed;nua do ITIL"/>
<node CREATED="1524214670865" ID="ID_594091128" MODIFIED="1524214772641" TEXT="1 - quais s&#xe3;o os elementos de negocio"/>
<node CREATED="1524214698364" ID="ID_584120161" MODIFIED="1524214778528" TEXT="2 - qual a situa&#xe7;&#xe3;o atual"/>
<node CREATED="1524214699974" ID="ID_1724521547" MODIFIED="1524214786721" TEXT="3 - qual situa&#xe7;&#xe3;o desajada"/>
<node CREATED="1524214701616" ID="ID_1450230732" MODIFIED="1524214806201" TEXT="4 - o que precisa ser feito p chegar l&#xe1;"/>
<node CREATED="1524214703338" ID="ID_962966363" MODIFIED="1524214838136" TEXT="5 - implementar o q foi planjeado"/>
<node CREATED="1524214704857" ID="ID_1778230606" MODIFIED="1524214842992" TEXT="6 -  medir o resultado"/>
<node CREATED="1524214843740" ID="ID_1014340609" MODIFIED="1524214852202" TEXT="7 - como manter a dinamica"/>
</node>
<node CREATED="1524214865431" FOLDED="true" ID="ID_1692047782" MODIFIED="1579119226969" TEXT="Pode-se olhar p para esse modelo em 3 niveis diferentes">
<node CREATED="1524214885410" ID="ID_497579913" MODIFIED="1524214891129" TEXT="Gestao do programa foca na organiza&#xe7;&#xe3;o"/>
<node CREATED="1524214891316" ID="ID_979113311" MODIFIED="1524214907181" TEXT="Capacita&#xe7;&#xe3;o da mudan&#xe7;a foca nas pessoas"/>
<node CREATED="1524214894166" ID="ID_1790518317" MODIFIED="1524214919831" TEXT="Ciclo de vida de melhoria continua foca nos processos"/>
</node>
<node CREATED="1524215158079" FOLDED="true" ID="ID_1505701599" MODIFIED="1579119317350" TEXT="Fase 1 &#x2013; Motiva&#xe7;&#xe3;o">
<node CREATED="1524215163911" ID="ID_308465528" MODIFIED="1524215164228" TEXT="Reconhecimento da necessidade de uma iniciativa de implementa&#xe7;&#xe3;o ou melhoria"/>
<node CREATED="1524215168655" ID="ID_1853953555" MODIFIED="1524215168940" TEXT="Identifica pontos de dor atuais e cria desejo de mudan&#xe7;a nos n&#xed;veis de gest&#xe3;o executiva"/>
</node>
<node CREATED="1524215173880" FOLDED="true" ID="ID_1839862612" MODIFIED="1534894903224" TEXT="Fase 2 &#x2013; Situa&#xe7;&#xe3;o atual">
<node CREATED="1524215181310" ID="ID_562546269" MODIFIED="1524215181666" TEXT="Define escopo da iniciativa de implementa&#xe7;&#xe3;o ou melhoria utilizando o cascateamento de metas"/>
<node CREATED="1524215186455" ID="ID_1462073325" MODIFIED="1524215186751" TEXT="Problemas ou defici&#xea;ncias s&#xe3;o identificados pela realiza&#xe7;&#xe3;o de uma avalia&#xe7;&#xe3;o de capacidade de processo"/>
</node>
<node CREATED="1524215191435" FOLDED="true" ID="ID_1733365294" MODIFIED="1534894903225" TEXT="Fase 3 &#x2013; Situa&#xe7;&#xe3;o desejada">
<node CREATED="1524215197356" ID="ID_1398505733" MODIFIED="1524215197732" TEXT="Uma meta de melhoria &#xe9; definida, seguida de an&#xe1;lise detalhada de lacunas e poss&#xed;veis solu&#xe7;&#xf5;es"/>
<node CREATED="1524215202640" ID="ID_100573756" MODIFIED="1524215202981" TEXT="Deve ser dada prioridade &#xe0;s iniciativas mais f&#xe1;ceis de realizar e com maiores benef&#xed;cios"/>
</node>
<node CREATED="1524215209531" FOLDED="true" ID="ID_1209629456" MODIFIED="1534894903225" TEXT="Fase 4 &#x2013; O que fazer">
<node CREATED="1524215214378" ID="ID_594541579" MODIFIED="1524215214603" TEXT="Planeja solu&#xe7;&#xf5;es pr&#xe1;ticas, com defini&#xe7;&#xe3;o de projetos apoiados por casos de neg&#xf3;cios justific&#xe1;veis"/>
<node CREATED="1524215219696" ID="ID_1954465423" MODIFIED="1524215219981" TEXT="Um caso de neg&#xf3;cio bem desenvolvido ajuda a garantir que os benef&#xed;cios do projeto s&#xe3;o identificados e monitorados"/>
</node>
<node CREATED="1524215224595" FOLDED="true" ID="ID_1617318732" MODIFIED="1534894903226" TEXT="Fase 5 &#x2013; Execu&#xe7;&#xe3;o">
<node CREATED="1524215229466" ID="ID_1622034238" MODIFIED="1524215229466" TEXT="As solu&#xe7;&#xf5;es propostas s&#xe3;o implementadas nas pr&#xe1;ticas do dia-a-dia"/>
<node CREATED="1524215234725" ID="ID_1715120320" MODIFIED="1524215235089" TEXT="Medidas podem ser definidas e monitoradas, utilizando metas e m&#xe9;tricas do COBIT para garantir que o alinhamento de neg&#xf3;cios seja alcan&#xe7;ado e mantido"/>
</node>
<node CREATED="1524215239986" FOLDED="true" ID="ID_477285549" MODIFIED="1534894903227" TEXT="Fase 6 &#x2013; Obten&#xe7;&#xe3;o de resultados">
<node CREATED="1524215246228" ID="ID_1027357752" MODIFIED="1524215246228" TEXT="Opera&#xe7;&#xe3;o sustent&#xe1;vel dos facilitadores novos ou melhorados"/>
<node CREATED="1524215246231" ID="ID_1698390950" MODIFIED="1524215248765" TEXT="Monitoramento da realiza&#xe7;&#xe3;o dos benef&#xed;cios esperados"/>
</node>
<node CREATED="1524215256061" FOLDED="true" ID="ID_1028398023" MODIFIED="1534894903227" TEXT="Fase 7 &#x2013; Manuten&#xe7;&#xe3;o do momento">
<node CREATED="1524215261761" ID="ID_1301403396" MODIFIED="1524215262226" TEXT="O sucesso global da iniciativa &#xe9; revisto, outras exig&#xea;ncias s&#xe3;o identificadas e a necessidade de melhoria cont&#xed;nua &#xe9; refor&#xe7;ada"/>
</node>
<node COLOR="#cc6600" CREATED="1579119324022" FOLDED="true" ID="ID_1227396609" MODIFIED="1585597357662" TEXT="Um gestor de TI pretende implantar os processos e as pr&#xe1;ticas do COBIT 5 no &#xf3;rg&#xe3;o em que trabalha e, para tal, adotar&#xe1; como refer&#xea;ncia o guia de implementa&#xe7;&#xe3;o do COBIT, composto de sete fases. Nessa situa&#xe7;&#xe3;o hipot&#xe9;tica,">
<node CREATED="1579119339276" FOLDED="true" ID="ID_1325360319" MODIFIED="1585597357650" STYLE="fork" TEXT="na terceira fase, em que a orienta&#xe7;&#xe3;o do COBIT &#xe9; definida, deve ser dada prioridade &#xe0;s iniciativas de alcance mais dif&#xed;cil, com vistas a transpor os principais obst&#xe1;culos e facilitar a implementa&#xe7;&#xe3;o.">
<node CREATED="1579119478325" ID="ID_1909992530" MODIFIED="1579119486494" TEXT="3 fase prioriza o desejado"/>
</node>
<node CREATED="1579119344373" ID="ID_1257030065" MODIFIED="1579119344697" TEXT="antes de se iniciar um novo ciclo, estritamente ao final da s&#xe9;tima fase, deve-se elaborar um estudo de caso que abranja os processos a serem implantados no pr&#xf3;ximo ciclo."/>
<node CREATED="1579119349734" FOLDED="true" ID="ID_1557775246" MODIFIED="1585597357654" TEXT="planejar o programa e executar o plano s&#xe3;o a&#xe7;&#xf5;es relacionadas diretamente e respectivamente &#xe0; primeira e &#xe0; segunda fase.">
<node CREATED="1579119505510" ID="ID_1579785315" MODIFIED="1579119510817" TEXT="fases 4 e 5"/>
</node>
<node CREATED="1579119354164" FOLDED="true" ID="ID_1209035648" MODIFIED="1585597357657" TEXT="a defini&#xe7;&#xe3;o do escopo da implementa&#xe7;&#xe3;o dever&#xe1; ocorrer antes da identifica&#xe7;&#xe3;o dos atuais pontos fracos e desencadeadores da aceita&#xe7;&#xe3;o da implanta&#xe7;&#xe3;o dos processos.">
<node CREATED="1579119526717" ID="ID_136173105" MODIFIED="1579119531202" TEXT="primeiro identifica os pontos fracos"/>
</node>
<node CREATED="1579119358366" ID="ID_1781753250" MODIFIED="1579119542805" TEXT="reconhecer pontos de dor e eventos desencadeadores no &#xf3;rg&#xe3;o, tais como perda de dados ou falha em projetos, &#xe9; um fator importante para as iniciativas de implementa&#xe7;&#xe3;o do COBIT.">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node COLOR="#800000" CREATED="1465737090822" FOLDED="true" ID="ID_1366112342" MODIFIED="1585598310021" POSITION="right" TEXT="Dom&#xed;nios e Processos ">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="full-1"/>
<node COLOR="#338800" CREATED="1524215755978" FOLDED="true" ID="ID_731166754" MODIFIED="1578779411642" TEXT="Prioridades para estudo">
<node COLOR="#338800" CREATED="1465737061708" ID="ID_627679450" MODIFIED="1524215785276" TEXT="1) Decorar todos os processos"/>
<node COLOR="#338800" CREATED="1524215746315" ID="ID_265788403" MODIFIED="1524215788108" TEXT="2) Entender o que cada processo faz"/>
<node COLOR="#338800" CREATED="1524215788475" ID="ID_1690051387" MODIFIED="1524215801910" TEXT="3) Olhar as praticas de cada processo"/>
<node COLOR="#338800" CREATED="1524216384070" FOLDED="true" ID="ID_457369207" MODIFIED="1574903606271" TEXT="4) Detalhamento dos processos">
<node COLOR="#338800" CREATED="1524216401510" ID="ID_691612035" MODIFIED="1524216422024" TEXT="&#xfa;ltimo n&#xed;vel de estudo, at&#xe9; ent&#xe3;o n&#xe3;o &#xe9; cobrado mas ajuda no entendimento geral dos processos"/>
<node CREATED="1524216118015" FOLDED="true" ID="ID_1404497204" MODIFIED="1524216193706" TEXT="Descri&#xe7;&#xe3;o e Detalhamento">
<node CREATED="1524216133050" MODIFIED="1524216133050">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_5700042347104478887.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1524216152798" FOLDED="true" ID="ID_1282175028" MODIFIED="1524216210770" TEXT="Metas e Indicadores">
<node CREATED="1524216169515" ID="ID_996924791" MODIFIED="1524216191079" TEXT="Quais metas de TI do processo e quais indicadores podem ser usados para medir se a meta esta ou n&#xe3;o sendo alcan&#xe7;ada"/>
<node CREATED="1524216167015" ID="ID_1633463691" MODIFIED="1524216167015">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_1180682147668586334.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1524216209730" MODIFIED="1524216209730">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_1300857843926127093.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1524216289566" FOLDED="true" ID="ID_1618070349" MODIFIED="1549317406531" TEXT="Matriz RACI">
<node CREATED="1524216295073" MODIFIED="1524216295073">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_4141580531265226219.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1524216367866" FOLDED="true" ID="ID_720666519" MODIFIED="1524216398246" TEXT="Pr&#xe1;ticas e Atividades">
<node CREATED="1524216379973" MODIFIED="1524216379973">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_2552129514382864541.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node CREATED="1524216530307" ID="ID_1620299590" MODIFIED="1524216535021" TEXT="Possui 5 dom&#xed;nios"/>
<node CREATED="1578779294671" FOLDED="true" ID="ID_598799343" MODIFIED="1585597444982" TEXT="Exemplo de detalhamento dos processos (n cai em prova, &#xe9; s&#xf3; p entendimento da estrutura)">
<node CREATED="1578779319479" FOLDED="true" ID="ID_207547828" MODIFIED="1578779324699" TEXT="vis&#xe3;o geral">
<node CREATED="1578779301407" ID="ID_1750559906" MODIFIED="1578779301407">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_36314910289963689.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1578779321031" FOLDED="true" ID="ID_694270111" MODIFIED="1585597357669" TEXT="metas">
<node CREATED="1578779343230" FOLDED="true" ID="ID_871568227" MODIFIED="1578779367735" TEXT="metas relacionadas a TI suportadas por esse processo">
<node CREATED="1578779322108" ID="ID_1061687672" MODIFIED="1578779322108">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_3207080238816378588.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1578779361975" FOLDED="true" ID="ID_1452820156" MODIFIED="1578779368119" TEXT="metas do processo em si">
<node CREATED="1578779365483" MODIFIED="1578779365483">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_3484139601602331341.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1578779435439" FOLDED="true" ID="ID_606216702" MODIFIED="1578779543432" TEXT="pr&#xe1;ticas chave do processo">
<node CREATED="1578779455522" MODIFIED="1578779455522">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_6380648926810551407.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node CREATED="1524216540390" ID="ID_1289951856" MODIFIED="1585597445458" TEXT="Processos de Governan&#xe7;a">
<node CREATED="1524216544603" FOLDED="true" ID="ID_1014066596" MODIFIED="1585597357669" TEXT="Avaliar, Dirigir e Monitorar (EDM)">
<node CREATED="1524216548542" ID="ID_469864549" MODIFIED="1524216548542" TEXT="5 processos de governan&#xe7;a"/>
<node CREATED="1524216554415" ID="ID_1415172164" MODIFIED="1524216554711" TEXT="Responsabilidades da alta dire&#xe7;&#xe3;o: avalia&#xe7;&#xe3;o, direcionamento e monitora&#xe7;&#xe3;o do uso de TI para cria&#xe7;&#xe3;o de valor"/>
<node CREATED="1524216613097" ID="ID_386431250" MODIFIED="1524216630746" TEXT="Todos os processos de governan&#xe7;a come&#xe7;am com o verbo &quot;Assegurar&quot;"/>
<node CREATED="1524216651061" ID="ID_1099527349" MODIFIED="1524216661936" TEXT="A Governan&#xe7;a n&#xe3;o faz, assegura que seja feito"/>
<node CREATED="1524216685540" FOLDED="true" ID="ID_1941097829" MODIFIED="1585597357669" TEXT="Os 5 processos possuem as pr&#xe1;ticas">
<node CREATED="1524216693598" ID="ID_100252175" MODIFIED="1578780087099" TEXT="Avaliar ..."/>
<node CREATED="1524216693603" ID="ID_1874013248" MODIFIED="1578780089867" TEXT="Dirigir ..."/>
<node CREATED="1524216693605" ID="ID_1947308720" MODIFIED="1578780092324" TEXT="Monitorar ..."/>
</node>
<node CREATED="1524216603688" FOLDED="true" ID="ID_1167342200" MODIFIED="1578947961877" TEXT="S&#xe3;o eles">
<node COLOR="#338800" CREATED="1578779976215" ID="ID_633110486" MODIFIED="1578779984091" TEXT="todos come&#xe7;am com Assegurar"/>
<node COLOR="#338800" CREATED="1578779966246" ID="ID_1134822414" MODIFIED="1578779984079" TEXT="as praticas sempre s&#xe3;o avaliar, dirigir e monitorar"/>
<node CREATED="1524216612011" FOLDED="true" ID="ID_1438099108" MODIFIED="1578947960549" TEXT="EDM01 - Assegurar Estabelecimento e Manuten&#xe7;&#xe3;o do Framework de Governan&#xe7;a">
<icon BUILTIN="full-1"/>
<node CREATED="1524216640386" ID="ID_1588664222" MODIFIED="1524216640747" TEXT="Analisa e articula os requisitos para a governan&#xe7;a corporativa de TI"/>
<node CREATED="1524216667486" ID="ID_37078539" MODIFIED="1524216667741" TEXT="Cria e mant&#xe9;m estruturas, princ&#xed;pios, processos e pr&#xe1;ticas, com clareza de responsabilidades e autoridade para alcan&#xe7;ar a miss&#xe3;o, as metas e os objetivos da organiza&#xe7;&#xe3;o"/>
<node CREATED="1524216676521" FOLDED="true" ID="ID_299567820" MODIFIED="1578780536726" TEXT=" Pr&#xe1;ticas">
<node CREATED="1524216682927" MODIFIED="1524216682927" TEXT="&#xf0a7; Avaliar o sistema de governan&#xe7;a"/>
<node CREATED="1524216682932" MODIFIED="1524216682932" TEXT="&#xf0a7; Dirigir o sistema de governan&#xe7;a"/>
<node CREATED="1524216682932" MODIFIED="1524216682932" TEXT="&#xf0a7; Monitorar o sistema de governan&#xe7;a"/>
</node>
<node COLOR="#cc6600" CREATED="1534895897164" FOLDED="true" ID="ID_1043180657" MODIFIED="1585597357669" TEXT="[cespe] O processo &#x201c;garantir a defini&#xe7;&#xe3;o e manuten&#xe7;&#xe3;o do modelo de governan&#xe7;a&quot; visa fornecer uma abordagem que garanta a realiza&#xe7;&#xe3;o das decis&#xf5;es de TI conforme as estrat&#xe9;gias e os objetivos da empresa. ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1578947841776" ID="ID_642007407" MODIFIED="1578947852543" TEXT="o objetivo do sistema de governan&#xe7;a &#xe9; garantir a satisfa&#xe7;&#xe3;o das partes interessadas"/>
<node CREATED="1578947900223" ID="ID_811784338" MODIFIED="1578947912439" TEXT="a estrategia e os objetivos da empresa vem depois da necessidade das partes interessadas"/>
</node>
</node>
<node CREATED="1524216718955" FOLDED="true" ID="ID_164979604" MODIFIED="1578780095216" TEXT=" EDM02 - Assegurar a Entrega de Benef&#xed;cios">
<node CREATED="1524216727794" ID="ID_276492066" MODIFIED="1524216728133" TEXT="Otimiza a contribui&#xe7;&#xe3;o de valor para o neg&#xf3;cio a partir de processos de neg&#xf3;cios, servi&#xe7;os e ativos de TI resultantes de investimentos realizados pela TI a custos aceit&#xe1;veis"/>
<node CREATED="1524216733571" FOLDED="true" ID="ID_1388543832" MODIFIED="1578780536727" TEXT="Pr&#xe1;ticas">
<node CREATED="1524216733576" ID="ID_1693479019" MODIFIED="1524216733576" TEXT="&#xf0a7; Avaliar a otimiza&#xe7;&#xe3;o de valor"/>
<node CREATED="1524216733576" ID="ID_640764373" MODIFIED="1524216733576" TEXT="&#xf0a7; Dirigir a otimiza&#xe7;&#xe3;o de valor"/>
<node CREATED="1524216733581" ID="ID_557040312" MODIFIED="1524216733581" TEXT="&#xf0a7; Monitorar a otimiza&#xe7;&#xe3;o de valor"/>
</node>
</node>
<node CREATED="1524216752575" FOLDED="true" ID="ID_992613315" MODIFIED="1578780191489" TEXT="EDM03 - Assegurar a Otimiza&#xe7;&#xe3;o de Riscos">
<node CREATED="1524216758800" ID="ID_965073933" MODIFIED="1524216759229" TEXT="Assegura que o apetite e toler&#xe2;ncia a riscos da organiza&#xe7;&#xe3;o s&#xe3;o compreendidos, articulados e comunicados"/>
<node CREATED="1524216767865" ID="ID_1290697241" MODIFIED="1524216768196" TEXT="Assegura que o risco para o neg&#xf3;cio relacionado ao uso de TI &#xe9; identificado e controlado"/>
<node CREATED="1524216773958" FOLDED="true" ID="ID_114204391" MODIFIED="1578780536727" TEXT="Pr&#xe1;ticas">
<node CREATED="1524216773958" ID="ID_232250566" MODIFIED="1524216773958" TEXT="&#xf0a7; Avaliar o gerenciamento de riscos"/>
<node CREATED="1524216773963" ID="ID_51719784" MODIFIED="1524216773963" TEXT="&#xf0a7; Dirigir o gerenciamento de riscos"/>
<node CREATED="1524216773963" ID="ID_1864693494" MODIFIED="1524216773963" TEXT="&#xf0a7; Monitorar o gerenciamento de riscos"/>
</node>
<node COLOR="#ff0000" CREATED="1524216883055" FOLDED="true" ID="ID_857806803" MODIFIED="1578780536728" TEXT="Aten&#xe7;&#xe3;o!">
<node CREATED="1524216956765" ID="ID_23734268" MODIFIED="1524216956765" TEXT="no dom&#xed;nio APO tem um processo chamado Gerenciar os Riscos"/>
<node CREATED="1524216936966" ID="ID_1040314731" MODIFIED="1524216949476" TEXT="H&#xe1; processos de Risco na Governan&#xe7;a e Gest&#xe3;o"/>
</node>
</node>
<node CREATED="1524216881255" FOLDED="true" ID="ID_338109017" MODIFIED="1578780536729" TEXT="EDM04 - Assegurar a Otimiza&#xe7;&#xe3;o de Recursos">
<node CREATED="1524216925726" ID="ID_1070101071" MODIFIED="1524216925944" TEXT="Assegura capacidades adequadas e suficientes relacionadas &#xe0; TI (pessoas, processos e tecnologia), dispon&#xed;veis para apoiar os objetivos da organiza&#xe7;&#xe3;o de forma eficaz a um custo &#xf3;timo"/>
<node CREATED="1524216932778" FOLDED="true" ID="ID_728539235" MODIFIED="1578780536729" TEXT="Pr&#xe1;ticas">
<node CREATED="1524216932778" ID="ID_930286234" MODIFIED="1524216932778" TEXT="&#xf0a7; Avaliar o gerenciamento de recursos"/>
<node CREATED="1524216932783" ID="ID_21719032" MODIFIED="1524216932783" TEXT="&#xf0a7; Dirigir o gerenciamento de recursos"/>
<node CREATED="1524216932783" ID="ID_1411474611" MODIFIED="1524216932783" TEXT="&#xf0a7; Monitorar o gerenciamento de recursos"/>
</node>
</node>
<node CREATED="1524217059703" FOLDED="true" ID="ID_285402784" MODIFIED="1578780536731" TEXT="EDM05 - Assegurar Transpar&#xea;ncia para as Partes Interessadas">
<icon BUILTIN="full-1"/>
<node CREATED="1524217066976" ID="ID_578963930" MODIFIED="1524217067231" TEXT="Assegura medi&#xe7;&#xe3;o e relat&#xf3;rios de desempenho e conformidade da TI corporativa que sejam transparentes para stakeholders aprovarem metas, m&#xe9;tricas e a&#xe7;&#xf5;es corretivas necess&#xe1;rias"/>
<node CREATED="1524217072131" FOLDED="true" ID="ID_17332374" MODIFIED="1578780536730" TEXT="Pr&#xe1;ticas">
<node CREATED="1524217072131" ID="ID_1648683801" MODIFIED="1524217072131" TEXT="&#xf0a7; Avaliar os requisitos de relat&#xf3;rios das partes interessadas"/>
<node CREATED="1524217072131" ID="ID_1073845864" MODIFIED="1524217072131" TEXT="&#xf0a7; Dirigir a comunica&#xe7;&#xe3;o e relat&#xf3;rios para as partes interessadas"/>
<node CREATED="1524217072136" ID="ID_1415556626" MODIFIED="1524217072136" TEXT="&#xf0a7; Monitorar a comunica&#xe7;&#xe3;o com as partes interessadas"/>
</node>
<node CREATED="1524217143501" ID="ID_1237783620" MODIFIED="1524217173325" TEXT="aqui se presta contas dando transparencia as partes interessadas, por isso Avalia, Dirige e Monitora a comunica&#xe7;&#xe3;o de relat&#xf3;rios das partes interessadas"/>
<node COLOR="#cc6600" CREATED="1534895430722" ID="ID_257580046" MODIFIED="1534895448292" TEXT="[cespe] &#x201c;garantir a transpar&#xea;ncia para as partes interessadas&#x201d; do dom&#xed;nio governan&#xe7;a do COBIT 5, trata, entre outros aspectos, da medi&#xe7;&#xe3;o e dos relat&#xf3;rios de desempenho da TI corporativa para os stakeholders aprovarem metas e a&#xe7;&#xf5;es corretivas necess&#xe1;rias.  "/>
<node COLOR="#cc6600" CREATED="1548968345085" ID="ID_781823428" MODIFIED="1548968403781" TEXT="[cespe] III Embora o planejamento estrat&#xe9;gico da organiza&#xe7;&#xe3;o disponha que se deve garantir a transpar&#xea;ncia para as partes interessadas, foi identificada a necessidade de implantar a&#xe7;&#xf5;es que visem atingir esse objetivo.&#xa;&#xa;As a&#xe7;&#xf5;es citadas no item III podem ser realizadas com base no processo chamado &#x201c;garantir a transpar&#xea;ncia para as partes interessadas&#x201d; do dom&#xed;nio governan&#xe7;a do COBIT 5, que trata, entre outros aspectos, da medi&#xe7;&#xe3;o e dos relat&#xf3;rios de desempenho da TI corporativa para os stakeholders aprovarem metas e a&#xe7;&#xf5;es corretivas necess&#xe1;rias.&#xa;&#xa;"/>
</node>
<node CREATED="1578780288846" FOLDED="true" ID="ID_1832371521" MODIFIED="1578780532697" TEXT="resumindo EDM">
<node CREATED="1578780296262" FOLDED="true" ID="ID_1991871254" MODIFIED="1578780536732" TEXT="1 - estabelece o sistema de governan&#xe7;a">
<node CREATED="1578780312862" FOLDED="true" ID="ID_1339821025" MODIFIED="1578780536731" TEXT="esse trata primeiro do caminho de ida">
<node CREATED="1578780321548" FOLDED="true" ID="ID_1410772548" MODIFIED="1578780536731" TEXT="avaliar,dirigir e monitorar">
<node CREATED="1578780328882" ID="ID_1258923835" MODIFIED="1578780330227" TEXT="beneficios"/>
<node CREATED="1578780330455" ID="ID_1850848997" MODIFIED="1578780332066" TEXT="riscos"/>
<node CREATED="1578780332278" ID="ID_200906779" MODIFIED="1578780334179" TEXT="recursos"/>
<node CREATED="1578780401527" ID="ID_1295879712" MODIFIED="1578780404738" TEXT="presta&#xe7;&#xe3;o de contas"/>
</node>
<node CREATED="1578780357991" ID="ID_1483645681" MODIFIED="1578780390339" TEXT="avalia-se as necessidades vindas das partes interessadas"/>
<node CREATED="1578780374703" ID="ID_1623570162" MODIFIED="1578780381075" TEXT="direciono a gest&#xe3;o"/>
<node CREATED="1578780381335" ID="ID_567777841" MODIFIED="1578780384826" TEXT="monitora os resultados"/>
<node CREATED="1578780405806" ID="ID_1376902255" MODIFIED="1578780446179" TEXT="por fim presta contas &#xe0;s partes interessadas garantindo a transparencia"/>
</node>
</node>
<node CREATED="1578780434053" MODIFIED="1578780434053">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_8094755987375044215.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1524404561447" FOLDED="true" ID="ID_373805918" MODIFIED="1585598157461" TEXT="Processos de Gest&#xe3;o">
<node COLOR="#cc6600" CREATED="1548967844749" FOLDED="true" ID="ID_1580976114" MODIFIED="1548968286584" TEXT="[cespe] No COBIT 5, &#xe9; prefer&#xed;vel o dom&#xed;nio construir, adquirir e implementar ao dom&#xed;nio alinhar, planejar e organizar para o gerenciamento dos processos relacionados &#xe0; ger&#xea;ncia de programas e projetos e &#xe0; ger&#xea;ncia de defini&#xe7;&#xe3;o de requisitos, pois naquele primeiro dom&#xed;nio t&#xea;m prioridade os processos afetos ao planejamento e ao entendimento dos objetivos do neg&#xf3;cio.  ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1548967901005" ID="ID_196192372" MODIFIED="1548967959051" TEXT="de fato o BAI possui o processo Gerenciar Programas e Projetos e Gerenciar a Defini&#xe7;&#xe3;o de Requisitos"/>
<node CREATED="1548968005149" ID="ID_1310446318" MODIFIED="1548968027795" TEXT="por&#xe9;m &#xe9; o dominio APO que tem processos afetos ao planejamento e ao entendimento dos objetivos do neg&#xf3;cio"/>
</node>
<node CREATED="1524404662800" FOLDED="true" ID="ID_138360803" MODIFIED="1585597861608" TEXT="Alinhar, Planejar e Organizar (APO)">
<icon BUILTIN="full-4"/>
<node CREATED="1524404675350" ID="ID_36481586" MODIFIED="1524404675575" TEXT="Identifica&#xe7;&#xe3;o de como a TI pode contribuir melhor com os objetivos de neg&#xf3;cio"/>
<node CREATED="1524404568534" ID="ID_439558389" MODIFIED="1524404644873" TEXT="n&#xed;vel estrat&#xe9;gicos da TI: como alcan&#xe7;ar os objetivos definidos pela governan&#xe7;a"/>
<node CREATED="1524404591371" ID="ID_1080036441" MODIFIED="1524404653167" TEXT="n&#xed;vel t&#xe1;tico: define padr&#xf5;es de gest&#xe3;o"/>
<node CREATED="1524404715253" FOLDED="true" ID="ID_1747104119" MODIFIED="1578948699213" TEXT="13 processos">
<node COLOR="#338800" CREATED="1524405086135" ID="ID_932259075" MODIFIED="1578948315991" TEXT="APO 01 a 06 - processos de vis&#xe3;o estrategica. Mais alinhados ao Alinhar e Planejar"/>
<node COLOR="#338800" CREATED="1524405095256" FOLDED="true" ID="ID_1090810420" MODIFIED="1578948355800" TEXT="APO 07 ao 13 - processos de vis&#xe3;o t&#xe1;tica. Cuidam da organiza&#xe7;&#xe3;o, dizendo detalhes de como a gest&#xe3;o vai funcionar">
<node CREATED="1524405832323" ID="ID_1827760141" MODIFIED="1524405887692" TEXT="tudo relacionado ao gerenciamento de pessoas, gerenciar equipes, capacitar, relacionamento com equipes terceirizadas, fornecedores etc."/>
</node>
<node CREATED="1524405132592" FOLDED="true" ID="ID_405825115" MODIFIED="1578948021450" TEXT="APO01 Gerenciar o Framework de Gest&#xe3;o de TI">
<node CREATED="1524405138612" FOLDED="true" ID="ID_1048158518" MODIFIED="1534894903236" TEXT="ESCLARECE e MANT&#xc9;M a miss&#xe3;o e vis&#xe3;o da governan&#xe7;a de TI da organiza&#xe7;&#xe3;o">
<node CREATED="1524405154141" ID="ID_922409312" MODIFIED="1524405158391" TEXT="n&#xe3;o define a miss&#xe3;o"/>
</node>
<node CREATED="1524405142952" ID="ID_1260123260" MODIFIED="1524405143342" TEXT="Implementa e mant&#xe9;m mecanismos e autoridades para gerenciar a informa&#xe7;&#xe3;o e o uso da TI na organiza&#xe7;&#xe3;o"/>
<node CREATED="1524405202026" ID="ID_1986503434" MODIFIED="1524405216938" TEXT="organiza e estrutura a &#xe1;rea de TI para atender o q foi definido pela governan&#xe7;a"/>
<node CREATED="1578947993035" ID="ID_1632321616" MODIFIED="1578948006215" TEXT="diz como a TI vai se organizar na gestao p cumprir o que foi definido na governan&#xe7;a"/>
<node CREATED="1524405217148" FOLDED="true" ID="ID_117688432" MODIFIED="1585597357670" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405224862" ID="ID_1457134784" MODIFIED="1524405244351" TEXT="&#xf0a7; Definir a estrutura organizacional"/>
<node CREATED="1524405224867" ID="ID_1593522992" MODIFIED="1524405239301" TEXT="&#xf0a7; Estabelecer pap&#xe9;is e responsabilidades"/>
<node CREATED="1524405224872" ID="ID_551289421" MODIFIED="1524405224872" TEXT="&#xf0a7; Manter os facilitadores do sistema de gest&#xe3;o"/>
<node CREATED="1524405224872" MODIFIED="1524405224872" TEXT="&#xf0a7; Comunicar objetivos e direcionamento da gest&#xe3;o"/>
<node CREATED="1524405224877" MODIFIED="1524405224877" TEXT="&#xf0a7; Otimizar a coloca&#xe7;&#xe3;o da fun&#xe7;&#xe3;o de TI"/>
<node CREATED="1524405224877" MODIFIED="1524405224877" TEXT="&#xf0a7; Definir a propriedade de informa&#xe7;&#xf5;es (dados) e sistemas"/>
<node CREATED="1524405224877" MODIFIED="1524405224877" TEXT="&#xf0a7; Gerenciar a melhoria cont&#xed;nua de processos"/>
<node CREATED="1524405224882" MODIFIED="1524405224882" TEXT="&#xf0a7; Manter conformidade com pol&#xed;ticas e procedimentos"/>
</node>
</node>
<node CREATED="1524405284518" FOLDED="true" ID="ID_622853586" MODIFIED="1578948073951" TEXT="APO02 Gerenciar a Estrat&#xe9;gia">
<icon BUILTIN="full-2"/>
<node CREATED="1524405294212" ID="ID_881718409" MODIFIED="1524405294487" TEXT="Fornece uma vis&#xe3;o hol&#xed;stica do ambiente de neg&#xf3;cio e TI atual, da dire&#xe7;&#xe3;o futura, e das iniciativas necess&#xe1;rias para migrar para o ambiente futuro desejado"/>
<node CREATED="1524405298513" ID="ID_1579827464" MODIFIED="1524405298889" TEXT="Alavanca componentes da arquitetura corporativa, incluindo servi&#xe7;os externos, para facilitar respostas r&#xe1;pidas, confi&#xe1;veis e eficientes aos objetivos estrat&#xe9;gicos"/>
<node CREATED="1578947939700" ID="ID_892286207" MODIFIED="1578947953768" TEXT="cria estrat&#xe9;gia e objetivos da empresa p atender as partes interessadas"/>
<node CREATED="1524405338323" FOLDED="true" ID="ID_1705928210" MODIFIED="1578948073598" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405338328" FOLDED="true" ID="ID_1603244546" MODIFIED="1585597357671" TEXT="&#xf0a7; Compreender o direcionamento corporativo">
<node CREATED="1578948032445" ID="ID_525210919" MODIFIED="1578948038144" TEXT="esse direcionamento vem da governan&#xe7;a"/>
</node>
<node CREATED="1524405338328" ID="ID_286744379" MODIFIED="1524405338328" TEXT="&#xf0a7; Avaliar ambiente, capacidade e desempenho atuais"/>
<node CREATED="1524405338333" ID="ID_1332315433" MODIFIED="1524405338333" TEXT="&#xf0a7; Definir as capacidades-alvo de TI"/>
<node CREATED="1524405338333" ID="ID_243767466" MODIFIED="1524405338333" TEXT="&#xf0a7; Conduzir uma an&#xe1;lise de gaps"/>
<node CREATED="1524405338333" FOLDED="true" ID="ID_1597554205" MODIFIED="1578948073216" TEXT="&#xf0a7; Definir o plano estrat&#xe9;gico e o road map">
<node CREATED="1578948065613" ID="ID_343734134" MODIFIED="1578948072463" TEXT="elabora&#xe7;&#xe3;o do plano estrat&#xe9;gico est&#xe1; aqui, na gest&#xe3;o"/>
</node>
<node CREATED="1524405338338" ID="ID_1639389162" MODIFIED="1524405338338" TEXT="&#xf0a7; Comunicar a estrat&#xe9;gia e o direcionamento de TI"/>
</node>
<node COLOR="#cc6600" CREATED="1549316112296" FOLDED="true" ID="ID_1671152005" MODIFIED="1549317331337" TEXT="[cespe] Gerenciar a estrat&#xe9;gia &#xe9; um processo de governan&#xe7;a que tem como objetivo principal levar a empresa a obter as tend&#xea;ncias dos servi&#xe7;os relacionados, identificar as oportunidades de inova&#xe7;&#xe3;o e planejar como se beneficiar de inova&#xe7;&#xe3;o em rela&#xe7;&#xe3;o &#xe0;s necessidades do neg&#xf3;cio. ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1549316128576" ID="ID_474640759" MODIFIED="1549316134684" TEXT="&#xe9; um processo de gest&#xe3;o"/>
</node>
<node COLOR="#cc6600" CREATED="1549317044519" ID="ID_134369188" MODIFIED="1549317056781" TEXT="[cespe] O processo de governan&#xe7;a denominado gerenciar a estrutura de gest&#xe3;o da TI visa fornecer uma vis&#xe3;o hol&#xed;stica do ambiente de neg&#xf3;cio da TI, bem como as iniciativas necess&#xe1;rias para se migrar para o ambiente futuro desejado. ">
<icon BUILTIN="button_cancel"/>
</node>
</node>
<node CREATED="1524405402458" FOLDED="true" ID="ID_655177363" MODIFIED="1578948180430" TEXT="APO03 Gerenciar a Arquitetura Corporativa">
<node CREATED="1524405408453" ID="ID_414481888" MODIFIED="1524405408648" TEXT="Estabelece uma arquitetura comum com camadas de processos de neg&#xf3;cios, informa&#xe7;&#xf5;es, dados, aplica&#xe7;&#xe3;o e tecnologia para realizar de forma eficaz e eficiente as estrat&#xe9;gias de neg&#xf3;cio e de TI"/>
<node CREATED="1578948132468" ID="ID_191587600" MODIFIED="1578948159727" TEXT="define um padr&#xe3;o para q tudo q a TI for fazer encaixe nesse padr&#xe3;o definido"/>
<node CREATED="1524405416174" FOLDED="true" ID="ID_1639597488" MODIFIED="1585597357671" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405416174" ID="ID_60382967" MODIFIED="1524405416174" TEXT="&#xf0a7; Desenvolver a vis&#xe3;o da arquitetura corporativa"/>
<node CREATED="1524405416174" ID="ID_1450308171" MODIFIED="1524405416174" TEXT="&#xf0a7; Definir a arquitetura de refer&#xea;ncia"/>
<node CREATED="1524405416179" ID="ID_1667860000" MODIFIED="1524405416179" TEXT="&#xf0a7; Selecionar oportunidades e solu&#xe7;&#xf5;es"/>
<node CREATED="1524405416179" ID="ID_207689618" MODIFIED="1524405416179" TEXT="&#xf0a7; Definir a implementa&#xe7;&#xe3;o da arquitetura"/>
<node CREATED="1524405416184" ID="ID_1687325820" MODIFIED="1524405416184" TEXT="&#xf0a7; Prover servi&#xe7;os da arquitetura corporativa"/>
</node>
</node>
<node CREATED="1524405429475" FOLDED="true" ID="ID_860982942" MODIFIED="1578948201160" TEXT="APO04 Gerenciar a Inova&#xe7;&#xe3;o">
<node CREATED="1524405436291" ID="ID_34940194" MODIFIED="1524405436521" TEXT="Mant&#xe9;m consci&#xea;ncia de tend&#xea;ncias de TI e servi&#xe7;os relacionados, identifica oportunidades de inova&#xe7;&#xe3;o e planeja como se beneficiar da inova&#xe7;&#xe3;o em rela&#xe7;&#xe3;o &#xe0;s necessidades do neg&#xf3;cio"/>
<node CREATED="1524405441028" FOLDED="true" ID="ID_1152102320" MODIFIED="1534894903239" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405441033" ID="ID_1859288595" MODIFIED="1524405441033" TEXT="&#xf0a7; Criar um ambiente prop&#xed;cio &#xe0; inova&#xe7;&#xe3;o"/>
<node CREATED="1524405441033" ID="ID_187420244" MODIFIED="1524405441033" TEXT="&#xf0a7; Manter compreens&#xe3;o do ambiente corporativo"/>
<node CREATED="1524405441038" ID="ID_1577643893" MODIFIED="1524405441038" TEXT="&#xf0a7; Monitorar e examinar o ambiente tecnol&#xf3;gico"/>
<node CREATED="1524405441038" ID="ID_1943045611" MODIFIED="1524405441038" TEXT="&#xf0a7; Avaliar o potencial de tecnologias emergentes e ideias de inova&#xe7;&#xe3;o"/>
<node CREATED="1524405441043" ID="ID_187797275" MODIFIED="1524405441043" TEXT="&#xf0a7; Recomendar iniciativas adicionais apropriadas"/>
<node CREATED="1524405441043" ID="ID_613240767" MODIFIED="1524405441043" TEXT="&#xf0a7; Monitorar a implementa&#xe7;&#xe3;o e o uso de inova&#xe7;&#xf5;es"/>
</node>
</node>
<node CREATED="1524405455522" FOLDED="true" ID="ID_722324538" MODIFIED="1578948339033" TEXT="APO05 Gerenciar o Portf&#xf3;lio">
<icon BUILTIN="full-1"/>
<node CREATED="1524405462586" ID="ID_1965121875" MODIFIED="1524405462826" TEXT="Executa orienta&#xe7;&#xf5;es estrat&#xe9;gicas para os investimentos, alinhadas com a vis&#xe3;o de arquitetura corporativa, as caracter&#xed;sticas desejadas do investimento e as restri&#xe7;&#xf5;es de recursos e or&#xe7;amento"/>
<node CREATED="1524405472017" ID="ID_160975242" MODIFIED="1524405472427" TEXT="Avalia e prioriza programas e servi&#xe7;os, gerenciando a demanda dentro das restri&#xe7;&#xf5;es de recursos e de or&#xe7;amento, com base no seu alinhamento com objetivos estrat&#xe9;gicos, valor corporativo e riscos"/>
<node CREATED="1524405506765" ID="ID_1540470501" MODIFIED="1524405507135" TEXT="Monitora o desempenho do portf&#xf3;lio de servi&#xe7;os e programas, propondo os ajustes necess&#xe1;rios em resposta ao desempenho ou a mudan&#xe7;a de prioridades da organiza&#xe7;&#xe3;o"/>
<node CREATED="1524405559329" FOLDED="true" ID="ID_1722975164" MODIFIED="1534894903239" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405559334" ID="ID_1978935372" MODIFIED="1524405559334" TEXT="&#xf0a7; Estabelecer o mix de investimentos desejado"/>
<node CREATED="1524405559334" ID="ID_1104345324" MODIFIED="1524405559334" TEXT="&#xf0a7; Determinar disponibilidade e fontes de recursos"/>
<node CREATED="1524405559334" ID="ID_54926195" MODIFIED="1524405559334" TEXT="&#xf0a7; Avaliar e selecionar programas a serem custeados"/>
<node CREATED="1524405559339" ID="ID_1869419772" MODIFIED="1524405559339" TEXT="&#xf0a7; Monitorar, otimizar e relatar o desempenho dos investimentos no portf&#xf3;lio"/>
<node CREATED="1524405559339" ID="ID_1359784102" MODIFIED="1524405559339" TEXT="&#xf0a7; Manter portf&#xf3;lios"/>
<node CREATED="1524405559339" ID="ID_1803430961" MODIFIED="1524405559339" TEXT="&#xf0a7; Gerenciar o alcance de benef&#xed;cios"/>
</node>
<node COLOR="#cc6600" CREATED="1549316014425" FOLDED="true" ID="ID_1432537124" MODIFIED="1549317331339" TEXT="[cespe] O processo de gest&#xe3;o designado gerenciar or&#xe7;amento e custos visa executar a dire&#xe7;&#xe3;o estrat&#xe9;gica definida para os investimentos em linha com a vis&#xe3;o de arquitetura corporativa e as caracter&#xed;sticas desejadas do investimento com os relacionados &#xe0;s carteiras de servi&#xe7;os e &#xe0;s restri&#xe7;&#xf5;es de financiamento.  ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1549316033192" ID="ID_131354559" MODIFIED="1549316038296" TEXT="papel da gerencia de portif&#xf3;lio"/>
</node>
<node CREATED="1578948216186" ID="ID_1197144346" MODIFIED="1578948230079" TEXT="&#xe9; comum ser cobrado junto com o processo Gerenciar Or&#xe7;amento e Custos"/>
<node CREATED="1578948259612" ID="ID_1883281219" MODIFIED="1578948267207" TEXT="or&#xe7;amento &#xe9; entrada para a Gerencia de Portifolio"/>
<node CREATED="1578948331518" ID="ID_1281552816" MODIFIED="1578948337856" TEXT="daqui sai as decis&#xf5;es a serem implementadas"/>
</node>
<node CREATED="1524405567504" FOLDED="true" ID="ID_1939059327" MODIFIED="1578948301781" TEXT="APO06 Gerenciar Or&#xe7;amento e Custos">
<node CREATED="1524405573546" ID="ID_1450005518" MODIFIED="1524405573846" TEXT="Administra atividades financeiras relacionadas a TI, abrangendo or&#xe7;amento, gest&#xe3;o de custos e benef&#xed;cios e prioriza&#xe7;&#xe3;o dos gastos com o uso de pr&#xe1;ticas formais de or&#xe7;amento e de um sistema justo e equitativo de aloca&#xe7;&#xe3;o de custos"/>
<node CREATED="1578948273819" ID="ID_1116029986" MODIFIED="1578948280688" TEXT="cira e mantem o or&#xe7;amento, prioriza a aloca&#xe7;&#xe3;o do dinheiro"/>
<node CREATED="1524405578967" FOLDED="true" ID="ID_316066161" MODIFIED="1534894903240" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405578967" ID="ID_508192836" MODIFIED="1524405578967" TEXT="&#xf0a7; Gerenciar finan&#xe7;as e contabilidade"/>
<node CREATED="1524405578972" ID="ID_738095054" MODIFIED="1524405578972" TEXT="&#xf0a7; Priorizar aloca&#xe7;&#xe3;o de recursos"/>
<node CREATED="1524405578972" ID="ID_803289016" MODIFIED="1524405578972" TEXT="&#xf0a7; Criar e manter or&#xe7;amentos"/>
<node CREATED="1524405578972" ID="ID_191566809" MODIFIED="1524405578972" TEXT="&#xf0a7; Modelar e alocar custos"/>
<node CREATED="1524405578977" ID="ID_123439070" MODIFIED="1524405578977" TEXT="&#xf0a7; Gerenciar custos"/>
</node>
</node>
<node CREATED="1524405818883" FOLDED="true" ID="ID_1191560402" MODIFIED="1578948385439" TEXT="APO07 Gerenciar Recursos Humanos">
<node CREATED="1524405871938" ID="ID_977679417" MODIFIED="1524405872238" TEXT="Fornece uma abordagem estruturada para garantir a melhor estrutura&#xe7;&#xe3;o, coloca&#xe7;&#xe3;o e habilidades dos recursos humanos"/>
<node CREATED="1524405895123" ID="ID_28946725" MODIFIED="1524405895438" TEXT="Inclui a comunica&#xe7;&#xe3;o de pap&#xe9;is e responsabilidades, planos de aprendizagem e de crescimento, e expectativas de desempenho"/>
<node CREATED="1578948360196" ID="ID_434889898" MODIFIED="1578948372063" TEXT="como selecionar pessoas, capacitar, monitorar desempenho"/>
<node CREATED="1578948373956" ID="ID_1568441945" MODIFIED="1578948379680" TEXT="essas pessoas independem de ser equipe interna ou externa"/>
<node CREATED="1524405902075" FOLDED="true" ID="ID_1800025399" MODIFIED="1534894903241" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405902075" ID="ID_1001659240" MODIFIED="1524405902075" TEXT="&#xf0a7; Manter equipe adequada e apropriada"/>
<node CREATED="1524405902075" ID="ID_1360646955" MODIFIED="1524405902075" TEXT="&#xf0a7; Identificar pessoal chave de TI"/>
<node CREATED="1524405902080" ID="ID_30260206" MODIFIED="1524405902080" TEXT="&#xf0a7; Manter as habilidades e compet&#xea;ncias do pessoal"/>
<node CREATED="1524405902080" ID="ID_1778295943" MODIFIED="1524405902080" TEXT="&#xf0a7; Avaliar o desempenho dos funcion&#xe1;rios"/>
<node CREATED="1524405902085" ID="ID_1317275268" MODIFIED="1524405902085" TEXT="&#xf0a7; Planejar e rastrear o uso de recursos humanos de TI e neg&#xf3;cio"/>
<node CREATED="1524405902085" ID="ID_229066329" MODIFIED="1524405902085" TEXT="&#xf0a7; Gerenciar equipes terceirizadas"/>
</node>
</node>
<node CREATED="1524405910502" FOLDED="true" ID="ID_1525704159" MODIFIED="1578948417009" TEXT="APO08 Gerenciar os Relacionamentos">
<icon BUILTIN="full-1"/>
<node CREATED="1524405916292" ID="ID_1078954353" MODIFIED="1524405916527" TEXT="Gerencia o relacionamento entre o neg&#xf3;cio e TI de uma maneira formal e transparente, que garanta foco na realiza&#xe7;&#xe3;o de um objetivo comum"/>
<node CREATED="1578948389779" ID="ID_270512463" MODIFIED="1578948409767" TEXT="como a area de TI conversa com a area de negocios? Quais os papeis incluidos na comunica&#xe7;&#xe3;o entre essas duas partes?"/>
<node CREATED="1524405921526" FOLDED="true" ID="ID_1527625708" MODIFIED="1548966782194" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405921531" ID="ID_620581174" MODIFIED="1524405921531" TEXT="&#xf0a7; Compreender as expectativas de neg&#xf3;cio"/>
<node CREATED="1524405921531" ID="ID_1427681213" MODIFIED="1524405925038" TEXT="&#xf0a7; Identificar oportunidades, riscos e restri&#xe7;&#xf5;es para TI aprimorar o neg&#xf3;cio"/>
<node CREATED="1524405921536" ID="ID_1483267654" MODIFIED="1524405921536" TEXT="&#xf0a7; Gerenciar o relacionamento com o neg&#xf3;cio"/>
<node CREATED="1524405921536" ID="ID_1402568732" MODIFIED="1524405921536" TEXT="&#xf0a7; Coordenar e comunicar"/>
<node CREATED="1524405921541" ID="ID_817175996" MODIFIED="1524405921541" TEXT="&#xf0a7; Prover insumos para a melhoria cont&#xed;nua de servi&#xe7;os"/>
</node>
<node COLOR="#cc6600" CREATED="1548966757687" FOLDED="true" ID="ID_609388350" MODIFIED="1548967358186" TEXT="[cespe] Para melhorar a rela&#xe7;&#xe3;o entre o usu&#xe1;rio e a TI, &#xe9; correto implantar o processo gerenciar relacionamentos do COBIT 5, que visa centralizar os atendimentos &#xe0;s &#xe1;reas clientes.   ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1548966823116" ID="ID_1090354775" MODIFIED="1548966845757" TEXT="esse processo t&#xe1; focado no relacionamento entre cliente e TI, n&#xe3;o usu&#xe1;rio e TI"/>
<node CREATED="1548966857400" ID="ID_358546243" MODIFIED="1548966857829" TEXT="O processo de gest&#xe3;o de relacionamento com o neg&#xf3;cio tem o objetivo de manter o relacionamento entre o provedor de servi&#xe7;os e o cliente nos n&#xed;veis estrat&#xe9;gicos e t&#xe1;ticos. O prop&#xf3;sito &#xe9; assegurar que o provedor de servi&#xe7;os entenda continuamente as (novas) necessidades e requisitos do neg&#xf3;cio, de maneira que o provedor de servi&#xe7;os entregue o que o neg&#xf3;cio precisa."/>
</node>
</node>
<node CREATED="1524405936869" FOLDED="true" ID="ID_1478812181" MODIFIED="1578948472952" TEXT="APO09 Gerenciar os Acordos de Servi&#xe7;o">
<node CREATED="1524405942140" ID="ID_1878919462" MODIFIED="1524405942510" TEXT="Alinha servi&#xe7;os de TI e n&#xed;veis de servi&#xe7;o com as necessidades e expectativas da organiza&#xe7;&#xe3;o"/>
<node CREATED="1524405947906" FOLDED="true" ID="ID_1855361599" MODIFIED="1585597357671" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405947911" ID="ID_1011880710" MODIFIED="1524405947911" TEXT="&#xf0a7; Identificar servi&#xe7;os de TI"/>
<node CREATED="1524405947911" FOLDED="true" ID="ID_1764809517" MODIFIED="1534894903242" TEXT="&#xf0a7; Catalogar servi&#xe7;os habilitados por TI">
<node CREATED="1524405964499" ID="ID_963339590" MODIFIED="1524405970396" TEXT="Cat&#xe1;logo de Servi&#xe7;os esta aqui"/>
</node>
<node CREATED="1524405947911" ID="ID_236692347" MODIFIED="1524405947911" TEXT="&#xf0a7; Definir e preparar acordos de servi&#xe7;o"/>
<node CREATED="1524405947916" ID="ID_616718162" MODIFIED="1524405947916" TEXT="&#xf0a7; Monitorar e reportar n&#xed;veis de servi&#xe7;o"/>
<node CREATED="1524405947916" ID="ID_1016599132" MODIFIED="1524405947916" TEXT="&#xf0a7; Revisar acordos de servi&#xe7;o e contratos"/>
</node>
<node CREATED="1578948455331" ID="ID_1947097585" MODIFIED="1578948471279" TEXT="cuida de estabelecer os acordos e manter o catologo (no ITIL isso &#xe9; separada, cada processo faz algo)"/>
</node>
<node CREATED="1524405975041" FOLDED="true" ID="ID_1239535217" MODIFIED="1578948547269" TEXT="APO10 Gerenciar os Fornecedores">
<icon BUILTIN="full-1"/>
<node CREATED="1524405982462" ID="ID_1161692232" MODIFIED="1524405982727" TEXT="Gerencia servi&#xe7;os relacionados a TI prestados por fornecedores para atender &#xe0;s necessidades organizacionais"/>
<node COLOR="#cc6600" CREATED="1539656897737" ID="ID_1964443826" MODIFIED="1539656903513" TEXT="[cespe] Na gest&#xe3;o de recursos de TI do COBIT 5, a sele&#xe7;&#xe3;o de fornecedores deve ser realizada de acordo com os pareceres legais e contratuais, devendo-se assegurar a melhor op&#xe7;&#xe3;o para atender aos objetivos do neg&#xf3;cio. "/>
<node CREATED="1524405990633" FOLDED="true" ID="ID_186398327" MODIFIED="1585597357671" TEXT="Pr&#xe1;ticas">
<node CREATED="1524405990638" ID="ID_1965760724" MODIFIED="1524405996819" TEXT="&#xf0a7; Identificar e avaliar relacionamentos e contratos com fornecedores"/>
<node CREATED="1524405990638" ID="ID_151200223" MODIFIED="1524405990638" TEXT="&#xf0a7; Selecionar fornecedores"/>
<node CREATED="1524405990643" ID="ID_681337310" MODIFIED="1524405990643" TEXT="&#xf0a7; Gerenciar relacionamentos e contratos com fornecedores"/>
<node CREATED="1524405990643" ID="ID_1554733945" MODIFIED="1524405990643" TEXT="&#xf0a7; Gerenciar os riscos de fornecedores"/>
<node CREATED="1524405990648" ID="ID_581724557" MODIFIED="1524405990648" TEXT="&#xf0a7; Monitorar desempenho e conformidade de fornecedores"/>
</node>
<node CREATED="1578948519979" ID="ID_941412584" MODIFIED="1578948529351" TEXT="lida com o relacionamento contratual com o fornecedor"/>
<node CREATED="1578948532499" ID="ID_1872596277" MODIFIED="1578948539895" TEXT="n&#xe3;o lida com o produto desse contrato, seja de pessoas ou de servi&#xe7;os"/>
<node CREATED="1578948540235" ID="ID_540854404" MODIFIED="1578948546600" TEXT="lida apenas com a parte contratual"/>
</node>
<node CREATED="1524406008056" FOLDED="true" ID="ID_991384568" MODIFIED="1578948578093" TEXT="APO11 Gerenciar a Qualidade">
<node CREATED="1524406012130" ID="ID_721848991" MODIFIED="1524406012310" TEXT="Define e comunica requisitos de qualidade em processos, procedimentos e resultados das organiza&#xe7;&#xf5;es"/>
<node CREATED="1524406017278" FOLDED="true" ID="ID_960466319" MODIFIED="1578948577720" TEXT="Pr&#xe1;ticas">
<node CREATED="1524406017278" ID="ID_1924042444" MODIFIED="1524406017278" TEXT="&#xf0a7; Estabelecer um sistema de gest&#xe3;o de qualidade"/>
<node CREATED="1524406017283" ID="ID_1021340919" MODIFIED="1524406017283" TEXT="&#xf0a7; Definir e gerenciar padr&#xf5;es, pr&#xe1;ticas e procedimentos de qualidade"/>
<node CREATED="1524406017283" ID="ID_1076586413" MODIFIED="1524406017283" TEXT="&#xf0a7; Focar o gerenciamento da qualidade nos clientes"/>
<node CREATED="1524406017283" ID="ID_332257291" MODIFIED="1524406017283" TEXT="&#xf0a7; Realizar monitoramento, controle e revis&#xf5;es de qualidade"/>
<node CREATED="1524406017288" ID="ID_139264619" MODIFIED="1524406020528" TEXT="&#xf0a7; Integrar o gerenciamento da qualidade em solu&#xe7;&#xf5;es para desenvolvimento e entrega de servi&#xe7;os"/>
<node CREATED="1524406017293" ID="ID_1077875236" MODIFIED="1524406017293" TEXT="&#xf0a7; Manter melhoria cont&#xed;nua"/>
</node>
</node>
<node CREATED="1524406031740" FOLDED="true" ID="ID_1247269819" MODIFIED="1578948636594" TEXT="APO12 Gerenciar os Riscos">
<icon BUILTIN="full-1"/>
<node CREATED="1524406036421" ID="ID_1778915355" MODIFIED="1524406036716" TEXT="Identifica continuamente, avalia e reduz os riscos relacionados a TI dentro dos n&#xed;veis de toler&#xe2;ncia estabelecidos pela diretoria executiva"/>
<node CREATED="1524406314895" ID="ID_331210517" MODIFIED="1524406407360" TEXT="aqui &#xe9; mais operacional: executa o gerenciamento de riscos, coleta dados, analisa, trata e implementa respostas aos riscos"/>
<node CREATED="1524406048156" ID="ID_936404268" MODIFIED="1524406055083" TEXT="obs: risco no viez do COBIT &#xe9; negativo"/>
<node CREATED="1524406043549" FOLDED="true" ID="ID_3542426" MODIFIED="1585597357672" TEXT="Pr&#xe1;ticas">
<node CREATED="1524406043554" ID="ID_907117505" MODIFIED="1524406043554" TEXT="&#xf0a7; Coletar dados"/>
<node CREATED="1524406043554" ID="ID_678008015" MODIFIED="1524406043554" TEXT="&#xf0a7; Analisar riscos"/>
<node CREATED="1524406043554" ID="ID_1269134309" MODIFIED="1524406043554" TEXT="&#xf0a7; Manter um perfil de riscos"/>
<node CREATED="1524406043554" ID="ID_935739678" MODIFIED="1524406043554" TEXT="&#xf0a7; Articular os riscos"/>
<node CREATED="1524406043559" ID="ID_1345226768" MODIFIED="1524406043559" TEXT="&#xf0a7; Definir um portf&#xf3;lio de a&#xe7;&#xf5;es de gerenciamento de riscos"/>
<node CREATED="1524406043559" ID="ID_1800333205" MODIFIED="1524406043559" TEXT="&#xf0a7; Responder aos riscos"/>
</node>
<node COLOR="#cc6600" CREATED="1548967149255" ID="ID_245911501" MODIFIED="1548967162900" TEXT="[cespe]  &#xe9; correto afirmar que o gerenciamento da seguran&#xe7;a da informa&#xe7;&#xe3;o &#xe9; tratado em ambos: no est&#xe1;gio desenho de servi&#xe7;o do ITIL v3; e no dom&#xed;nio alinhar, planejar e organizar (APO) do COBIT 5."/>
</node>
<node CREATED="1524406060257" FOLDED="true" ID="ID_857405962" MODIFIED="1578948693533" TEXT="APO13 Gerenciar a Seguran&#xe7;a">
<node CREATED="1524406064313" ID="ID_1340197230" MODIFIED="1524406064578" TEXT="Define, opera e monitora um sistema para gest&#xe3;o de seguran&#xe7;a da informa&#xe7;&#xe3;o"/>
<node CREATED="1578948653891" ID="ID_1135561673" MODIFIED="1578948659240" TEXT="aqui estabelece o sistema de gest&#xe3;o de seguran&#xe7;a"/>
<node CREATED="1524406065594" ID="ID_140226379" MODIFIED="1524406081047" TEXT="obs: DSS 05 gerencia servi&#xe7;os de seguran&#xe7;a"/>
<node CREATED="1524406085949" FOLDED="true" ID="ID_2972933" MODIFIED="1534894903246" TEXT="Pr&#xe1;ticas">
<node CREATED="1524406097907" ID="ID_357143880" MODIFIED="1524406098157" TEXT="Estabelecer e manter um sistema de gest&#xe3;o de seguran&#xe7;a da informa&#xe7;&#xe3;o (SGSI)"/>
<node CREATED="1524406102272" ID="ID_8637544" MODIFIED="1524406102567" TEXT="Definir e gerenciar um plano de tratamento de riscos de seguran&#xe7;a da informa&#xe7;&#xe3;o"/>
<node CREATED="1524406107015" ID="ID_1715030111" MODIFIED="1524406107375" TEXT="Monitorar e revisar o SGSI"/>
</node>
</node>
</node>
<node COLOR="#cc6600" CREATED="1578948708763" FOLDED="true" ID="ID_1782291375" MODIFIED="1585597357672" TEXT="[cespe] O processo de governan&#xe7;a denominado gerenciar a estrutura de gest&#xe3;o da TI visa fornecer uma vis&#xe3;o hol&#xed;stica do ambiente de neg&#xf3;cio da TI, bem como as iniciativas necess&#xe1;rias para se migrar para o ambiente futuro desejado.">
<icon BUILTIN="button_cancel"/>
<node CREATED="1578948780069" ID="ID_1412347846" MODIFIED="1578948786463" TEXT="processo Gerenciar a Estrat&#xe9;gia"/>
</node>
<node COLOR="#cc6600" CREATED="1578948715548" FOLDED="true" ID="ID_280046222" MODIFIED="1585597357672" TEXT="[cespe] Gerenciar a estrat&#xe9;gia &#xe9; um processo de governan&#xe7;a que tem como objetivo principal levar a empresa a obter as tend&#xea;ncias dos servi&#xe7;os relacionados, identificar as oportunidades de inova&#xe7;&#xe3;o e planejar como se beneficiar de inova&#xe7;&#xe3;o em rela&#xe7;&#xe3;o &#xe0;s necessidades do neg&#xf3;cio.">
<icon BUILTIN="button_cancel"/>
<node CREATED="1578948838357" ID="ID_29731039" MODIFIED="1578948840360" TEXT="gerencia de inova&#xe7;&#xe3;o"/>
</node>
<node COLOR="#cc6600" CREATED="1578948721779" FOLDED="true" ID="ID_1563920495" MODIFIED="1585597357673" TEXT="[cespe] O processo de gest&#xe3;o designado gerenciar or&#xe7;amento e custos visa executar a dire&#xe7;&#xe3;o estrat&#xe9;gica definida para os investimentos em linha com a vis&#xe3;o de arquitetura corporativa e as caracter&#xed;sticas desejadas do investimento com os relacionados &#xe0;s carteiras de servi&#xe7;os e &#xe0;s restri&#xe7;&#xf5;es de financiamento.">
<icon BUILTIN="button_cancel"/>
<node CREATED="1578948923803" ID="ID_1512304239" MODIFIED="1578948928104" TEXT="Or&#xe7;amento define qto tem de dinheiro"/>
<node CREATED="1578948928299" ID="ID_1813835209" MODIFIED="1578948935120" TEXT="Portfolio decide onde aloca o dinheiro"/>
<node CREATED="1578948935316" ID="ID_56790506" MODIFIED="1578948941288" TEXT="Logo, trata do portifolio"/>
</node>
<node COLOR="#cc6600" CREATED="1585597454220" ID="ID_950381155" MODIFIED="1585597482773" TEXT="[cespe] O COBIT 5 sugere um modelo de refer&#xea;ncia que define e descreve processos, agrupando-os em dom&#xed;nios. Assinale a op&#xe7;&#xe3;o que apresenta o dom&#xed;nio de abrang&#xea;ncia estrat&#xe9;gica e t&#xe1;tica que identifica as formas pelas quais a TI pode contribuir melhor para o atendimento dos objetivos de neg&#xf3;cio, envolvendo comunica&#xe7;&#xe3;o e gerenciamento em diversas perspectivas.  Alinhar, Planejar e Organizar"/>
<node CREATED="1578948999931" FOLDED="true" ID="ID_311363870" MODIFIED="1578967159535" TEXT="resumo">
<node CREATED="1578949003368" ID="ID_763722266" MODIFIED="1578949011375" TEXT="saimos do dominio de Governan&#xe7;a com um direcionamento dado p Gest&#xe3;o"/>
<node CREATED="1578949016477" ID="ID_352781192" MODIFIED="1578949038792" TEXT="no primeiro dominio de APO diz q precisa de um sistema do modelo de gest&#xe3;o, q abrange tudo"/>
<node CREATED="1578949045308" ID="ID_980049601" MODIFIED="1578949180440" TEXT="esse direcionamento q vem da governan&#xe7;a, da origem a Estrategia. Este processo gerenciar a estrategia &#xe9; responsavel por receber o direcionamento vindo da Governa&#xe7;a e a partir dai monta o plano estrategico "/>
<node CREATED="1578949154675" FOLDED="true" ID="ID_1102748327" MODIFIED="1585597357673" TEXT="esse plano estrat&#xe9;gico se reflete em ">
<node CREATED="1578949169703" ID="ID_1842174079" MODIFIED="1578949206492" TEXT="arquitetura corporativa q est&#xe1; associada a um projeto de inova&#xe7;&#xe3;o"/>
</node>
<node CREATED="1578949207421" ID="ID_1375815293" MODIFIED="1578949235887" TEXT="a estrategia junto da Arquitetura Corporativa e Inova&#xe7;&#xe3;o direciona o Or&#xe7;amento, q direciona o Portfolio"/>
<node CREATED="1578949264980" ID="ID_396302478" MODIFIED="1578949286776" TEXT="esse Portfolio  define o que &#xe9; q tem q ser construido (BAI)"/>
<node CREATED="1578949313685" FOLDED="true" ID="ID_1987037526" MODIFIED="1585597357674" TEXT="dentro do dominio APO tem 2 partes">
<node CREATED="1578949321245" ID="ID_610021693" MODIFIED="1578949324764" TEXT="Alinhar e Planejar"/>
<node CREATED="1578949324978" FOLDED="true" ID="ID_733232798" MODIFIED="1585597357673" TEXT="Organizar">
<node CREATED="1578949331024" FOLDED="true" ID="ID_1040096289" MODIFIED="1585597357673" TEXT="aqui diz o q deve organizar e padronizar na minha gest&#xe3;o">
<node COLOR="#338800" CREATED="1578949407204" ID="ID_1312050633" MODIFIED="1578949448744" TEXT="todos estes processos influencia a gest&#xe3;o como um todo, influencia a forma como a TI vai se comportar"/>
<node CREATED="1578949340332" ID="ID_966124498" MODIFIED="1578949345295" TEXT="Gestao de pessoas"/>
<node CREATED="1578949345523" ID="ID_1529853351" MODIFIED="1578949348752" TEXT="Gestao de relacionamentos"/>
<node CREATED="1578949349740" ID="ID_369336381" MODIFIED="1578949359449" TEXT="Gestao de Acordos de servi&#xe7;o"/>
<node CREATED="1578949359644" ID="ID_93426283" MODIFIED="1578949362519" TEXT="Gestao de Fornecedores"/>
<node CREATED="1578949362715" ID="ID_78834434" MODIFIED="1578949381613" TEXT="Gestao de Qualidade">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1578949371940" ID="ID_364932835" MODIFIED="1578949375136" TEXT="Gestao de Riscos"/>
<node CREATED="1578949375347" ID="ID_749617398" MODIFIED="1578949380671" TEXT="Gestao de Seguran&#xe7;a"/>
</node>
</node>
</node>
<node CREATED="1578949430136" MODIFIED="1578949430136">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_4441455333890630086.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1524404679621" FOLDED="true" ID="ID_344807521" MODIFIED="1585597972397" TEXT="Construir, Adquirir e Implementar (BAI)">
<node CREATED="1524404684321" ID="ID_1233590106" MODIFIED="1524404684507" TEXT="Materializa a estrat&#xe9;gia de TI, identificando requisitos e gerenciando a realiza&#xe7;&#xe3;o de investimentos em TI"/>
<node CREATED="1578947687174" ID="ID_1326024141" MODIFIED="1578947698408" TEXT="constroi as coisas planejadas no dominio APO"/>
<node COLOR="#006699" CREATED="1548968061670" ID="ID_1379851205" MODIFIED="1548968160354" TEXT="[estrat&#xe9;gia] O dom&#xed;nio BAI torna a estrat&#xe9;gia de TI concreta, identificando os requisitos para a TI e  gerenciando o programa de investimentos em TI e projetos associados. Este dom&#xed;nio  tamb&#xe9;m endere&#xe7;a o gerenciamento da disponibilidade e capacidade; mudan&#xe7;a  organizacional; gerenciamento de mudan&#xe7;as (TI); aceite e transi&#xe7;&#xe3;o; e gerenciamento  de ativos, configura&#xe7;&#xe3;o e conhecimento. Cont&#xe9;m 10 processos. [6] "/>
<node CREATED="1524404728476" FOLDED="true" ID="ID_1721347571" MODIFIED="1585597971390" TEXT="10 processos">
<node CREATED="1524422122999" FOLDED="true" ID="ID_1692321040" MODIFIED="1585597971129" TEXT="BAI01 Gerenciar Programas e Projetos">
<icon BUILTIN="full-1"/>
<node CREATED="1524422128996" ID="ID_17250168" MODIFIED="1524422129373" TEXT="Gerencia todos os programas e projetos do portfo&#x301;lio de investimentos em alinhamento com a estrate&#x301;gia da organizac&#x327;a&#x303;o e de forma coordenada"/>
<node CREATED="1524422134305" ID="ID_907771767" MODIFIED="1524422135249" TEXT="Inicia, planeja, controla e executa programas e projetos, e finaliza com uma revisa&#x303;o po&#x301;s-implementac&#x327;a&#x303;o"/>
<node CREATED="1524422147005" FOLDED="true" ID="ID_1487076916" MODIFIED="1524422220960" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422147007" ID="ID_908179435" MODIFIED="1524422153269" TEXT="&#xf0a7; Manter abordagem padr&#xe3;o para gerenciamento de programas e projetos"/>
<node CREATED="1524422147015" ID="ID_1352781042" MODIFIED="1524422147015" TEXT="&#xf0a7; Iniciar programas"/>
<node CREATED="1524422147018" ID="ID_154725143" MODIFIED="1524422147018" TEXT="&#xf0a7; Gerenciar o envolvimento das partes interessadas"/>
<node CREATED="1524422147020" ID="ID_102950042" MODIFIED="1524422147020" TEXT="&#xf0a7; Desenvolver e manter o plano do programa"/>
<node CREATED="1524422147022" ID="ID_1347516143" MODIFIED="1524422147022" TEXT="&#xf0a7; Lan&#xe7;ar e executar o programa"/>
<node CREATED="1524422164158" ID="ID_1351372042" MODIFIED="1524422183127" TEXT="&#xf0a7; Monitorar, controlar e reportar sobre os resultados do programa"/>
<node CREATED="1524422174862" ID="ID_706589285" MODIFIED="1524422174862" TEXT="&#xf0a7; Iniciar projetos dentro de um programa"/>
<node CREATED="1524422174864" MODIFIED="1524422174864" TEXT="&#xf0a7; Planejar projetos"/>
<node CREATED="1524422174866" MODIFIED="1524422174866" TEXT="&#xf0a7; Gerenciar qualidade de programas e projetos"/>
<node CREATED="1524422174868" MODIFIED="1524422174868" TEXT="&#xf0a7; Gerenciar riscos de programas e projetos"/>
<node CREATED="1524422174870" MODIFIED="1524422174870" TEXT="&#xf0a7; Monitorar e controlar projetos"/>
<node CREATED="1524422174872" MODIFIED="1524422174872" TEXT="&#xf0a7; Gerenciar recursos e pacotes de trabalho de projetos"/>
<node CREATED="1524422174874" MODIFIED="1524422174874" TEXT="&#xf0a7; Encerrar um projeto ou itera&#xe7;&#xe3;o"/>
<node CREATED="1524422174876" MODIFIED="1524422174876" TEXT="&#xf0a7; Encerrar um programa"/>
</node>
<node COLOR="#cc6600" CREATED="1585597890877" ID="ID_1672260648" MODIFIED="1585597895119" TEXT="[cespe] O COBIT 5 &#xe9; compat&#xed;vel com o gerenciamento &#xe1;gil de processos na &#xe1;rea de TI e, por isso, n&#xe3;o agrega gerenciamento de programas, tendo enfoque espec&#xed;fico em projetos que devem ser gerenciados de forma adaptativa e iterativa.  ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1585597904148" ID="ID_1978537387" MODIFIED="1585597926546" TEXT="agrega gerenciamento de programas sim, por isso existe esse processo"/>
</node>
</node>
<node CREATED="1524422221553" FOLDED="true" ID="ID_317747644" MODIFIED="1578967266978" TEXT="BAI02 Gerenciar a Definic&#x327;a&#x303;o de Requisitos">
<icon BUILTIN="full-1"/>
<node CREATED="1524422226419" ID="ID_1260426265" MODIFIED="1524422226664" TEXT="Identifica soluc&#x327;o&#x303;es e analisa os requisitos antes da aquisic&#x327;a&#x303;o ou criac&#x327;a&#x303;o para assegurar que eles esta&#x303;o em conformidade com os requisitos estrate&#x301;gicos corporativos que cobrem os processos de nego&#x301;cio, aplicac&#x327;o&#x303;es, informac&#x327;o&#x303;es/ dados, infra-estrutura e servic&#x327;os"/>
<node CREATED="1524422231169" ID="ID_675959784" MODIFIED="1524422231545" TEXT="Coordena com as partes interessadas afetadas a revisa&#x303;o de opc&#x327;o&#x303;es via&#x301;veis, incluindo custos e benefi&#x301;cios, ana&#x301;lise de risco e aprovac&#x327;a&#x303;o de requisitos e soluc&#x327;o&#x303;es propostas"/>
<node CREATED="1524422238863" FOLDED="true" ID="ID_1357367673" MODIFIED="1585597357674" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422238865" ID="ID_1210249632" MODIFIED="1524422238865" TEXT="&#xf0a7; Definir e manter requisitos de neg&#xf3;cio funcionais e t&#xe9;cnicos"/>
<node CREATED="1524422238867" ID="ID_258497160" MODIFIED="1524422238867" TEXT="&#xf0a7; Realizar estudo de viabilidade e formular solu&#xe7;&#xf5;es alternativas"/>
<node CREATED="1524422238869" ID="ID_1740773647" MODIFIED="1524422238869" TEXT="&#xf0a7; Gerenciar riscos dos requisitos"/>
<node CREATED="1524422238872" ID="ID_1451704056" MODIFIED="1524422238872" TEXT="&#xf0a7; Obter aprova&#xe7;&#xe3;o de requisitos e solu&#xe7;&#xf5;es"/>
</node>
<node CREATED="1578967256736" ID="ID_316310778" MODIFIED="1578967265301" TEXT="identifica requisitos e obtem o aceite das partes interessadas"/>
</node>
<node CREATED="1524422248789" FOLDED="true" ID="ID_564891416" MODIFIED="1578967358475" TEXT="BAI03 Gerenciar a Identificac&#x327;a&#x303;o e Construc&#x327;a&#x303;o de Soluc&#x327;o&#x303;es">
<node CREATED="1524422258865" ID="ID_591604306" MODIFIED="1524422259243" TEXT="Estabelece e mante&#x301;m soluc&#x327;o&#x303;es identificadas em conformidade com os requisitos da organizac&#x327;a&#x303;o abrangendo design, desenvolvimento, aquisic&#x327;a&#x303;o/terceirizac&#x327;a&#x303;o e parcerias com fornecedores"/>
<node CREATED="1524422264857" ID="ID_412900271" MODIFIED="1524422265176" TEXT="Gerencia configurac&#x327;a&#x303;o, teste de preparac&#x327;a&#x303;o, testes, requisitos de gesta&#x303;o e manutenc&#x327;a&#x303;o dos processos de nego&#x301;cio, aplicac&#x327;o&#x303;es, informac&#x327;o&#x303;es/dados, infra-estrutura e servic&#x327;os"/>
<node CREATED="1524422270446" FOLDED="true" ID="ID_1318097235" MODIFIED="1549318031451" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422270448" ID="ID_405219934" MODIFIED="1524422270448" TEXT="&#xf0a7; Desenhar solu&#xe7;&#xf5;es de alto n&#xed;vel"/>
<node CREATED="1524422270450" ID="ID_1459641276" MODIFIED="1524422270450" TEXT="&#xf0a7; Desenhar detalhes dos componentes da solu&#xe7;&#xe3;o"/>
<node CREATED="1524422270454" ID="ID_1657411336" MODIFIED="1524422270454" TEXT="&#xf0a7; Desenvolver componentes da solu&#xe7;&#xe3;o"/>
<node CREATED="1524422270456" ID="ID_123999514" MODIFIED="1524422270456" TEXT="&#xf0a7; Adquirir componentes da solu&#xe7;&#xe3;o"/>
<node CREATED="1524422270458" ID="ID_1720502719" MODIFIED="1524422270458" TEXT="&#xf0a7; Construir solu&#xe7;&#xf5;es"/>
<node CREATED="1524422270459" ID="ID_560105161" MODIFIED="1524422270459" TEXT="&#xf0a7; Realizar garantia de qualidade"/>
<node CREATED="1524422270461" ID="ID_66095052" MODIFIED="1524422270461" TEXT="&#xf0a7; Preparar para teste da solu&#xe7;&#xe3;o"/>
<node CREATED="1524422270462" ID="ID_1832367659" MODIFIED="1524422270462" TEXT="&#xf0a7; Executar teste da solu&#xe7;&#xe3;o"/>
<node CREATED="1524422270464" ID="ID_958136699" MODIFIED="1524422270464" TEXT="&#xf0a7; Gerenciar mudan&#xe7;as nos requisitos"/>
<node CREATED="1524422270466" ID="ID_1370927509" MODIFIED="1524422270466" TEXT="&#xf0a7; Manter solu&#xe7;&#xf5;es"/>
<node CREATED="1524422270469" ID="ID_1811794752" MODIFIED="1524422270469" TEXT="&#xf0a7; Definir servi&#xe7;os de TI e manter o portfolio de servi&#xe7;os"/>
</node>
<node CREATED="1578967354368" ID="ID_1537291376" MODIFIED="1578967357829" TEXT="entrega o negocio funcionando"/>
</node>
<node CREATED="1524422298361" FOLDED="true" ID="ID_1090076536" MODIFIED="1578967453842" TEXT="BAI04 Gerenciar a Disponibilidade e Capacidade">
<icon BUILTIN="full-1"/>
<node CREATED="1524422304953" ID="ID_1177801133" MODIFIED="1524422305224" TEXT="Equilibra as necessidades atuais e futuras de disponibilidade, desempenho e capacidade de prestac&#x327;a&#x303;o de servic&#x327;os de baixo custo"/>
<node CREATED="1524422314154" ID="ID_647142209" MODIFIED="1524422315200" TEXT="Inclui a avaliac&#x327;a&#x303;o de capacidades atuais, a previsa&#x303;o das necessidades futuras com base em requisitos de nego&#x301;cios, ana&#x301;lise de impactos nos nego&#x301;cios e avaliac&#x327;a&#x303;o de risco para planejar e implementar ac&#x327;o&#x303;es para atender as necessidades identificadas"/>
<node CREATED="1524422317959" FOLDED="true" ID="ID_70240775" MODIFIED="1585597357674" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422323043" ID="ID_325048973" MODIFIED="1524422323358" TEXT="&#xf0a7; Avaliar disponibilidade, desempenho e capacidade atuais e criar uma linha de base"/>
<node CREATED="1524422328119" ID="ID_1525616620" MODIFIED="1524422328119" TEXT="&#xf0a7; Avaliar impacto sobre o neg&#xf3;cio"/>
<node CREATED="1524422328121" ID="ID_51334189" MODIFIED="1524422328121" TEXT="&#xf0a7; Planejar para requisitos de servi&#xe7;o novos ou alterados"/>
<node CREATED="1524422328123" ID="ID_1032595557" MODIFIED="1524422328123" TEXT="&#xf0a7; Monitorar e revisar disponibilidade e capacidade"/>
<node CREATED="1524422332976" ID="ID_566954235" MODIFIED="1524422333306" TEXT="&#xf0a7; Investigar e endere&#xe7;ar quest&#xf5;es de disponibilidade, desempenho e capacidade"/>
</node>
<node CREATED="1578967423458" ID="ID_194399200" MODIFIED="1578967453126" TEXT="todos os processos do ITL 3 s&#xe3;o mapeados dentro do COBIT, por isso esse processo est&#xe1; junto com identificar e construir as solu&#xe7;&#xf5;es"/>
<node COLOR="#cc6600" CREATED="1535914473975" FOLDED="true" ID="ID_1038849686" MODIFIED="1542135603097" TEXT="[cespe] 1 &#x2013; estabelecer processo para obten&#xe7;&#xe3;o de dados, de maneira a fornecer informa&#xe7;&#xf5;es acerca de disponibilidade, desempenho e capacidade de todos os recursos relativos &#xe0; informa&#xe7;&#xe3;o;">
<node COLOR="#cc6600" CREATED="1535914501534" ID="ID_286226017" MODIFIED="1535914508700" TEXT="A atividade 1 &#xe9; um dos objetivos do processo gerenciar disponibilidade e capacidade &#x2014; do COBIT &#x2014; e est&#xe1; relacionada aos processos gerenciamento da disponibilidade e gerenciamento da capacidade do est&#xe1;gio de desenho &#x2014; do ITIL."/>
</node>
</node>
<node COLOR="#338800" CREATED="1524422355094" ID="ID_725438813" MODIFIED="1524422371581" TEXT="Depois da Constru&#xe7;&#xe3;o entra na Transi&#xe7;&#xe3;o"/>
<node CREATED="1524422339336" FOLDED="true" ID="ID_1105423165" MODIFIED="1585597357674" TEXT="BAI05 Gerenciar a Implementac&#x327;a&#x303;o de Mudanc&#x327;a Organizacional">
<node CREATED="1524422353590" ID="ID_285805506" MODIFIED="1524422353950" TEXT="Maximiza a probabilidade de implementar com sucesso a mudanc&#x327;a organizacional sustenta&#x301;vel em toda a organizac&#x327;a&#x303;o de forma ra&#x301;pida e com risco reduzido, cobrindo o ciclo de vida completo da mudanc&#x327;a e todas as partes interessadas afetadas no nego&#x301;cio e TI"/>
<node CREATED="1578967498209" ID="ID_1663528056" MODIFIED="1578967504989" TEXT="n&#xe3;o trata dos aspectos t&#xe9;cnicos da mudan&#xe7;a"/>
<node CREATED="1578967505186" ID="ID_1746659682" MODIFIED="1578967518174" TEXT="trata da mudan&#xe7;a referente a pegar a solu&#xe7;&#xe3;o q acabei de construi e colocar em opera&#xe7;&#xe3;o"/>
<node CREATED="1578967519097" ID="ID_1936579723" MODIFIED="1578967533389" TEXT="isso gera uma mudan&#xe7;a organizacional (procedimentos, responsabilidades, comunica&#xe7;&#xe3;o, capacita&#xe7;a&#xf5; das pessoas etc..)"/>
<node CREATED="1524422377315" FOLDED="true" ID="ID_424723589" MODIFIED="1549318034386" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422377320" ID="ID_1911441920" MODIFIED="1524422377320" TEXT="&#xf0a7; Estabelecer o desejo de mudan&#xe7;a"/>
<node CREATED="1524422377320" ID="ID_301445945" MODIFIED="1524422377320" TEXT="&#xf0a7; Formar um time de implementa&#xe7;&#xe3;o efetivo"/>
<node CREATED="1524422377320" ID="ID_145830310" MODIFIED="1524422377320" TEXT="&#xf0a7; Comunicar a vis&#xe3;o desejada"/>
<node CREATED="1524422377325" ID="ID_1773068811" MODIFIED="1524422377325" TEXT="&#xf0a7; Empoderar pap&#xe9;is e identificar ganhos de curto prazo"/>
<node CREATED="1524422377330" ID="ID_253679492" MODIFIED="1524422377330" TEXT="&#xf0a7; Habilitar opera&#xe7;&#xe3;o e uso"/>
<node CREATED="1524422377335" ID="ID_1496401063" MODIFIED="1524422377335" TEXT="&#xf0a7; Embutir novas abordagens"/>
<node CREATED="1524422377335" ID="ID_229686973" MODIFIED="1524422377335" TEXT="&#xf0a7; Sustentar mudan&#xe7;as"/>
</node>
</node>
<node CREATED="1524422402955" FOLDED="true" ID="ID_1850881288" MODIFIED="1578967987979" TEXT="BAI06 Gerenciar Mudanc&#x327;as">
<icon BUILTIN="full-1"/>
<node CREATED="1524422407899" ID="ID_548455043" MODIFIED="1524422408334" TEXT="Gerencia todas as mudanc&#x327;as de uma maneira controlada, incluindo mudanc&#x327;as de padra&#x303;o e de manutenc&#x327;a&#x303;o de emerge&#x302;ncia relacionadas com os processos de nego&#x301;cio, aplicac&#x327;o&#x303;es e infraestrutura"/>
<node CREATED="1524422412211" ID="ID_1252302834" MODIFIED="1524422412576" TEXT="Isto inclui os padro&#x303;es de mudanc&#x327;a e procedimentos, avaliac&#x327;a&#x303;o de impacto, priorizac&#x327;a&#x303;o e autorizac&#x327;a&#x303;o, mudanc&#x327;as emergenciais, acompanhamento, elaborac&#x327;a&#x303;o de relato&#x301;rios, encerramento e documentac&#x327;a&#x303;o"/>
<node CREATED="1578967550154" ID="ID_1438453534" MODIFIED="1578967566374" TEXT="se refere &#xe0;s mudan&#xe7;as t&#xe9;cnicas. As mudan&#xe7;as na TI"/>
<node CREATED="1578967588754" ID="ID_24243379" MODIFIED="1578967613734" TEXT="ex. a mudan&#xe7;a no BD pode impactar outros sistemas, logo, deve-se cuidar de todos os aspectos tecnicos da mudan&#xe7;a"/>
<node CREATED="1524422423334" FOLDED="true" ID="ID_1154583852" MODIFIED="1550317175685" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422423334" ID="ID_755225331" MODIFIED="1524422423334" TEXT="&#xf0a7; Avaliar, priorizar e autorizar solicita&#xe7;&#xf5;es de mudan&#xe7;a"/>
<node CREATED="1524422423339" ID="ID_1291277471" MODIFIED="1524422423339" TEXT="&#xf0a7; Gerenciar mudan&#xe7;as emergenciais"/>
<node CREATED="1524422423344" ID="ID_110320212" MODIFIED="1524422423344" TEXT="&#xf0a7; Rastrear e reportar status da mudan&#xe7;a"/>
<node CREATED="1524422423344" ID="ID_221261188" MODIFIED="1524422423344" TEXT="&#xf0a7; Encerrar e documentar mudan&#xe7;as"/>
</node>
<node COLOR="#cc6600" CREATED="1549318046686" FOLDED="true" ID="ID_17367517" MODIFIED="1585597357675" TEXT="[cespe] O processo de gerenciamento de mudan&#xe7;as tem como objetivo de controle estabelecer procedimentos formais a fim de padronizar toda e qualquer mudan&#xe7;a efetuada nas aplica&#xe7;&#xf5;es. ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1578967936457" ID="ID_1689547918" MODIFIED="1578967943421" TEXT="a gerencia de mudan&#xe7;as n&#xe3;o padroniza"/>
<node CREATED="1578967945865" ID="ID_174437277" MODIFIED="1578967949869" TEXT="cada mudan&#xe7;a tem o seu jeito"/>
<node CREATED="1578967950080" ID="ID_871219725" MODIFIED="1578967964909" TEXT="ela avalia, autorizar, acompanha e olhar o resultado final"/>
</node>
</node>
<node CREATED="1524422440585" FOLDED="true" ID="ID_1866959659" MODIFIED="1578967681711" TEXT="BAI07 Gerenciar Aceita&#xe7;&#xe3;o e Transic&#x327;a&#x303;o de Mudanc&#x327;a">
<node CREATED="1524422446619" ID="ID_562045846" MODIFIED="1524422447124" TEXT="Aceita e produz formalmente novas soluc&#x327;o&#x303;es operacionais, incluindo planejamento de implementac&#x327;a&#x303;o do sistema, conversa&#x303;o de dados, testes de aceitac&#x327;a&#x303;o, comunicac&#x327;a&#x303;o, preparac&#x327;a&#x303;o de liberac&#x327;a&#x303;o, promoc&#x327;a&#x303;o para produc&#x327;a&#x303;o de processos de nego&#x301;cios e servic&#x327;os de TI novos ou alterados, suporte de produc&#x327;a&#x303;o e uma revisa&#x303;o po&#x301;s-implementac&#x327;a&#x303;o"/>
<node CREATED="1524422452830" FOLDED="true" ID="ID_1210098212" MODIFIED="1534894903251" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422452835" ID="ID_1358588385" MODIFIED="1524422452835" TEXT="&#xf0a7; Estabelecer um plano de implementa&#xe7;&#xe3;o"/>
<node CREATED="1524422452835" ID="ID_105463055" MODIFIED="1524422452835" TEXT="&#xf0a7; Planejar processos de neg&#xf3;cio, sistemas e convers&#xe3;o de dados"/>
<node CREATED="1524422452835" ID="ID_1361835544" MODIFIED="1524422452835" TEXT="&#xf0a7; Planejar testes de aceita&#xe7;&#xe3;o"/>
<node CREATED="1524422452835" ID="ID_117504982" MODIFIED="1524422452835" TEXT="&#xf0a7; Estabelecer ambiente de testes"/>
<node CREATED="1524422452840" ID="ID_979718005" MODIFIED="1524422452840" TEXT="&#xf0a7; Realizar testes de aceita&#xe7;&#xe3;o"/>
<node CREATED="1524422452840" ID="ID_196475583" MODIFIED="1524422452840" TEXT="&#xf0a7; Promover para a produ&#xe7;&#xe3;o e gerenciar releases"/>
<node CREATED="1524422452845" ID="ID_1295592870" MODIFIED="1524422452845" TEXT="&#xf0a7; Prover suporte inicial para produ&#xe7;&#xe3;o"/>
<node CREATED="1524422452845" ID="ID_403821817" MODIFIED="1524422452845" TEXT="&#xf0a7; Realizar revis&#xf5;es p&#xf3;s-implementa&#xe7;&#xe3;o"/>
</node>
<node CREATED="1524422527696" ID="ID_987173830" MODIFIED="1524422556033" TEXT="Tem como sa&#xed;da o produto/servi&#xe7;o em opera&#xe7;&#xe3;o"/>
<node CREATED="1578967640664" ID="ID_576229924" MODIFIED="1578967656485" TEXT="faz um aceite antes (do teste, do piloto) e um aceite p colocar em produ&#xe7;&#xe3;o"/>
</node>
<node COLOR="#338800" CREATED="1524422631367" ID="ID_107831940" MODIFIED="1524422650919" TEXT="Depois de colocado o produto/servi&#xe7;o em opera&#xe7;&#xe3;o, tem-se os processos para sustenta&#xe7;&#xe3;o em produ&#xe7;&#xe3;o"/>
<node CREATED="1524422462577" FOLDED="true" ID="ID_1203023094" MODIFIED="1578967706236" TEXT="BAI08 Gerenciar o Conhecimento">
<node CREATED="1524422496260" ID="ID_651577153" MODIFIED="1524422496701" TEXT="Mante&#x301;m a disponibilidade de conhecimento relevante, atual, validado e confia&#x301;vel para suportar todas as atividades do processo e facilitar a tomada de decisa&#x303;o"/>
<node CREATED="1524422500437" ID="ID_527064615" MODIFIED="1524422500774" TEXT="Plano para a identificac&#x327;a&#x303;o, coleta, organizac&#x327;a&#x303;o, manutenc&#x327;a&#x303;o, utilizac&#x327;a&#x303;o e retirada de conhecimento"/>
<node CREATED="1524422504619" FOLDED="true" ID="ID_167843571" MODIFIED="1578967705530" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422511025" ID="ID_834893059" MODIFIED="1524422511535" TEXT="&#xf0a7; Cultivar e facilitar uma cultura de compartilhamento de conhecimentos"/>
<node CREATED="1524422516401" MODIFIED="1524422516401" TEXT="&#xf0a7; Identificar e classificar fontes de informa&#xe7;&#xf5;es"/>
<node CREATED="1524422516406" MODIFIED="1524422516406" TEXT="&#xf0a7; Organizar e contextualizar informa&#xe7;&#xe3;o em conhecimento"/>
<node CREATED="1524422516406" MODIFIED="1524422516406" TEXT="&#xf0a7; Usar e compartilhar conhecimentos"/>
<node CREATED="1524422516411" MODIFIED="1524422516411" TEXT="&#xf0a7; Avaliar e descontinuar informa&#xe7;&#xf5;es"/>
</node>
</node>
<node CREATED="1524422522386" FOLDED="true" ID="ID_885549806" MODIFIED="1585597357675" TEXT=" BAI09 Gerenciar os Ativos">
<node CREATED="1524422565030" ID="ID_970039393" MODIFIED="1524422565425" TEXT="Gerencia os ativos de TI atrave&#x301;s de seu ciclo de vida para assegurar que seu uso agrega valor a um custo ideal"/>
<node CREATED="1524422569552" ID="ID_780471778" MODIFIED="1524422570007" TEXT="Os ativos permanecem operacionais e fisicamente protegidos e aqueles que sa&#x303;o fundamentais para apoiar a capacidade de servic&#x327;o sa&#x303;o confia&#x301;veis e disponi&#x301;veis"/>
<node CREATED="1578967766409" ID="ID_1578798827" MODIFIED="1578967786293" TEXT="ativo &#xe9; algo q tem valor patrimonial p minha organiza&#xe7;&#xe3;o (equipamento, licen&#xe7;a de software etc..)"/>
<node CREATED="1524422574860" FOLDED="true" ID="ID_506066149" MODIFIED="1534894903253" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422574860" ID="ID_1974292326" MODIFIED="1524422574860" TEXT="&#xf0a7; Identificar e registrar ativos correntes"/>
<node CREATED="1524422574865" ID="ID_1278372164" MODIFIED="1524422574865" TEXT="&#xf0a7; Gerenciar ativos cr&#xed;ticos"/>
<node CREATED="1524422574865" ID="ID_1098646573" MODIFIED="1524422574865" TEXT="&#xf0a7; Gerenciar o ciclo de vida de ativos"/>
<node CREATED="1524422574865" ID="ID_719246607" MODIFIED="1524422574865" TEXT="&#xf0a7; Otimizar custos de ativos"/>
<node CREATED="1524422574870" ID="ID_1362397398" MODIFIED="1524422574870" TEXT="&#xf0a7; Gerenciar licen&#xe7;as"/>
</node>
</node>
<node CREATED="1524422588641" FOLDED="true" ID="ID_1076607891" MODIFIED="1578967899985" TEXT="BAI10 Gerenciar a Configurac&#x327;a&#x303;o">
<node CREATED="1524422594001" ID="ID_1323882703" MODIFIED="1524422594481" TEXT="Define e mante&#x301;m as descric&#x327;o&#x303;es e as relac&#x327;o&#x303;es entre os principais recursos e as capacidades necessa&#x301;rias para prestar servic&#x327;os de TI, incluindo a coleta de informac&#x327;o&#x303;es de configurac&#x327;a&#x303;o, o estabelecimento de linhas de base, verificac&#x327;a&#x303;o e auditoria de informac&#x327;o&#x303;es de configurac&#x327;a&#x303;o e atualizar o reposito&#x301;rio de configurac&#x327;a&#x303;o"/>
<node CREATED="1578967810113" ID="ID_731200883" MODIFIED="1578967831325" TEXT="se preocupa em saber quais as configura&#xe7;&#xf5;es dos itens de configura&#xe7;&#xe3;o e os relacionamentos entre eles"/>
<node CREATED="1524422601386" FOLDED="true" ID="ID_1700554590" MODIFIED="1534894903253" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422601391" ID="ID_1830505232" MODIFIED="1524422601391" TEXT="&#xf0a7; Estabelecer e manter um modelo de configura&#xe7;&#xe3;o"/>
<node CREATED="1524422601396" ID="ID_1671990697" MODIFIED="1524422607758" TEXT="&#xf0a7; Estabelecer e manter um reposit&#xf3;rio e linha de base de configura&#xe7;&#xe3;o"/>
<node CREATED="1524422601396" ID="ID_219957549" MODIFIED="1524422601396" TEXT="&#xf0a7; Manter e controlar itens de configura&#xe7;&#xe3;o"/>
<node CREATED="1524422601401" ID="ID_1640584705" MODIFIED="1524422601401" TEXT="&#xf0a7; Produzir relat&#xf3;rios de status sobre a configura&#xe7;&#xe3;o"/>
<node CREATED="1524422601401" ID="ID_957653134" MODIFIED="1524422601401" TEXT="&#xf0a7; Verificar e revisar a integridade do reposit&#xf3;rio de configura&#xe7;&#xe3;o"/>
</node>
</node>
<node COLOR="#338800" CREATED="1578967749377" ID="ID_1897872668" MODIFIED="1578967763819" TEXT="no ITIL temos um unico processo: gerencia de configura&#xe7;&#xe3;o e ativos"/>
<node CREATED="1578967989913" FOLDED="true" ID="ID_1420324210" MODIFIED="1579037010315" TEXT="resumo">
<node CREATED="1578968011514" ID="ID_303769768" MODIFIED="1578968022845" TEXT="come&#xe7;a o BAI com programa e projeto para gerenciar o que foi decidido fazer"/>
<node CREATED="1578968023042" ID="ID_137158625" MODIFIED="1578968030293" TEXT="p gerenciar projetos, &#xe9; necessario ter requisitos"/>
<node CREATED="1578968030505" ID="ID_1570637762" MODIFIED="1578968042709" TEXT="junto aos requisitos, deve saber como resolve-los (solu&#xe7;&#xf5;es alternativas)"/>
<node CREATED="1578968042920" ID="ID_583028235" MODIFIED="1578968051085" TEXT="uma vez definido os requisitos, identifica e constroi a solu&#xe7;&#xe3;o"/>
<node CREATED="1578968051705" ID="ID_164264548" MODIFIED="1578968123917" TEXT="dando suporte a constru&#xe7;&#xe3;o da solu&#xe7;&#xe3;o, tem-se a disponibilidade e capacidade (fatores essenciais na constru&#xe7;&#xe3;o do software)"/>
<node CREATED="1578968198232" FOLDED="true" ID="ID_621011317" MODIFIED="1585597357675" TEXT="uma vez construida a solu&#xe7;&#xe3;o, entra no processo de mudan&#xe7;a, que &#xe9;">
<node CREATED="1578968210186" ID="ID_1334277821" MODIFIED="1578968212717" TEXT="organizacional"/>
<node CREATED="1578968214506" ID="ID_1220121647" MODIFIED="1578968227797" TEXT="t&#xe9;cnica (mas n&#xe3;o trata apenas da tecnologia em si)"/>
<node CREATED="1578968228009" ID="ID_1653173846" MODIFIED="1578968234749" TEXT="mudan&#xe7;a q tem q ser aceita"/>
</node>
<node CREATED="1578968294618" FOLDED="true" ID="ID_1858424264" MODIFIED="1585597357675" TEXT="todas essas informa&#xe7;&#xf5;es geradas pela implanta&#xe7;&#xe3;o da solu&#xe7;&#xe3;o, ha questoes q precisam ser documentadas:">
<node CREATED="1578968313761" ID="ID_1824760827" MODIFIED="1578968315549" TEXT="documentos"/>
<node CREATED="1578968315777" ID="ID_265228064" MODIFIED="1578968321630" TEXT="aspectos patrimoniais dos ativos"/>
<node CREATED="1578968321857" ID="ID_236292133" MODIFIED="1578968324282" TEXT="configura&#xe7;&#xe3;o"/>
</node>
<node CREATED="1578968330479" MODIFIED="1578968330479">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_4002469022690763764.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node CREATED="1524404690545" ID="ID_1098070533" MODIFIED="1585597982597" TEXT="Entregar, Servir e Suportar (DSS)">
<icon BUILTIN="full-1"/>
<node CREATED="1524404695386" ID="ID_880607955" MODIFIED="1524404695646" TEXT="Entrega dos servi&#xe7;os de TI necess&#xe1;rios para atender aos planos t&#xe1;ticos e estrat&#xe9;gicos"/>
<node CREATED="1579037056941" ID="ID_328934087" MODIFIED="1579037065242" TEXT="deve garantir q as coisas continuem funcionando"/>
<node CREATED="1579037077949" ID="ID_600300017" MODIFIED="1579037090185" TEXT="deve fazer funcionar do jeito certo (gerencia de opera&#xe7;&#xf5;es) e corrigir os problemas"/>
<node CREATED="1524404733046" FOLDED="true" ID="ID_576990758" MODIFIED="1585598000283" TEXT="6 processos">
<node COLOR="#338800" CREATED="1524422851434" ID="ID_1928960560" MODIFIED="1524422935384" TEXT="Uma parte dessas fun&#xe7;&#xf5;es mantem as coisas funcionando"/>
<node CREATED="1524422761324" FOLDED="true" ID="ID_516480518" MODIFIED="1579037669248" TEXT="DSS01 Gerenciar as Operac&#x327;o&#x303;es">
<node CREATED="1524422757320" ID="ID_1003319522" MODIFIED="1524422757734" TEXT="Coordena e executa as atividades e procedimentos operacionais necessa&#x301;rios para entregar servic&#x327;os de TI internos e terceirizados, incluindo a execuc&#x327;a&#x303;o de procedimentos operacionais, padro&#x303;es pre&#x301;- definidos e as atividades exigidas"/>
<node CREATED="1524422774349" FOLDED="true" ID="ID_1892674795" MODIFIED="1549317364592" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422774354" ID="ID_52774466" MODIFIED="1524422774354" TEXT="&#xf0a7; Realizar procedimentos operacionais"/>
<node CREATED="1524422774354" ID="ID_1315710759" MODIFIED="1524422774354" TEXT="&#xf0a7; Gerenciar servi&#xe7;os de TI terceirizados"/>
<node CREATED="1524422774359" ID="ID_691173323" MODIFIED="1524422774359" TEXT="&#xf0a7; Monitorar a infraesturutra de TI"/>
<node CREATED="1524422774359" ID="ID_91443292" MODIFIED="1524422774359" TEXT="&#xf0a7; Gerenciar o ambiente"/>
<node CREATED="1524422774359" ID="ID_844615805" MODIFIED="1524422774359" TEXT="&#xf0a7; Gerenciar instala&#xe7;&#xf5;es f&#xed;sicas"/>
</node>
</node>
<node COLOR="#338800" CREATED="1524422894661" ID="ID_1254464625" MODIFIED="1524422928515" TEXT="os outros processos resolve os problemas"/>
<node CREATED="1524422783452" FOLDED="true" ID="ID_269974536" MODIFIED="1585597357675" TEXT="DSS02 Gerenciar Requisic&#x327;o&#x303;es de Servic&#x327;o e Incidentes">
<icon BUILTIN="full-1"/>
<node CREATED="1524422788060" ID="ID_12191117" MODIFIED="1524422788500" TEXT="Fornece uma resposta ra&#x301;pida e eficaz a&#x300;s solicitac&#x327;o&#x303;es dos usua&#x301;rios e resoluc&#x327;a&#x303;o de todos os tipos de incidentes"/>
<node CREATED="1524422792425" ID="ID_1913704645" MODIFIED="1548967083251" TEXT="Restaura o servic&#x327;o normal; atender a&#x300;s solicitac&#x327;o&#x303;es dos usua&#x301;rios e registrar, investigar, diagnosticar, escalar e solucionar incidentes"/>
<node CREATED="1579037171102" ID="ID_895996333" MODIFIED="1579037182809" TEXT="obs.: isso n&#xe3;o corresponde ao Service Desk do itil"/>
<node CREATED="1579037194821" ID="ID_1717478455" MODIFIED="1579037216009" TEXT="incidente &#xe9; todo evento q ocorre q faz algo parar de funcionar ou n&#xe3;o funcionar normalmente"/>
<node CREATED="1579037266549" ID="ID_979961049" MODIFIED="1579037288089" TEXT="requisi&#xe7;&#xe3;o de servi&#xe7;o &#xe9; tudo q o usuario pode solicitar q n&#xe3;o &#xe9; incidente (ex. quero trocar de impressora)"/>
<node CREATED="1524422797810" FOLDED="true" ID="ID_1680351793" MODIFIED="1548966989007" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422797810" ID="ID_1633891733" MODIFIED="1524422797810" TEXT="&#xf0a7; Definir esquemas de classifica&#xe7;&#xe3;o de requisi&#xe7;&#xf5;es de servi&#xe7;o e incidentes"/>
<node CREATED="1524422797810" ID="ID_371329827" MODIFIED="1524422797810" TEXT="&#xf0a7; Registrar, classificar e priorizar incidentes e requisi&#xe7;&#xf5;es"/>
<node CREATED="1524422797815" ID="ID_1170135832" MODIFIED="1524422797815" TEXT="&#xf0a7; Verificar, aprovar e atender a requisi&#xe7;&#xf5;es de servi&#xe7;os"/>
<node CREATED="1524422797815" ID="ID_1629904995" MODIFIED="1524422797815" TEXT="&#xf0a7; Investigar, diagnosticar e alocar incidentes"/>
<node CREATED="1524422797815" ID="ID_509449274" MODIFIED="1524422797815" TEXT="&#xf0a7; Resolver e se recuperar de incidentes"/>
<node CREATED="1524422797820" ID="ID_472718130" MODIFIED="1524422797820" TEXT="&#xf0a7; Encerrar requisi&#xe7;&#xf5;es de servi&#xe7;os e incidentes"/>
<node CREATED="1524422797820" ID="ID_728146896" MODIFIED="1524422797820" TEXT="&#xf0a7; Rastrear status e produzir relat&#xf3;rios"/>
</node>
<node COLOR="#cc6600" CREATED="1548966999463" ID="ID_605286382" MODIFIED="1548967003439" TEXT="[cespe] A fim de agilizar a investiga&#xe7;&#xe3;o e o diagn&#xf3;stico dos incidentes, &#xe9; correto implantar o processo gerenciar requisi&#xe7;&#xf5;es de servi&#xe7;os e incidentes do COBIT 5, que trata desses aspectos do tratamento de incidentes, al&#xe9;m de registrar as solicita&#xe7;&#xf5;es dos usu&#xe1;rios.  "/>
</node>
<node CREATED="1524422806414" FOLDED="true" ID="ID_1116636332" MODIFIED="1579037348617" TEXT="DSS03 Gerenciar Problemas">
<node CREATED="1579037305397" ID="ID_630350312" MODIFIED="1579037324217" TEXT="p gerenciar incidentes, precisa do gerenciamento de problemas"/>
<node CREATED="1524422812175" ID="ID_1453899593" MODIFIED="1524422812575" TEXT="Identifica e classifica os problemas e suas causas-rai&#x301;zes e fornece resoluc&#x327;a&#x303;o para prevenir incidentes recorrentes"/>
<node CREATED="1524422816139" ID="ID_1156068608" MODIFIED="1524422816524" TEXT="Fornece recomendac&#x327;o&#x303;es de melhorias"/>
<node CREATED="1524422821195" FOLDED="true" ID="ID_1878085019" MODIFIED="1534894903257" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422821200" ID="ID_292316693" MODIFIED="1524422821200" TEXT="&#xf0a7; Identificar e classificar problemas"/>
<node CREATED="1524422821200" ID="ID_1431118453" MODIFIED="1524422821200" TEXT="&#xf0a7; Investigar e diagnosticar problemas"/>
<node CREATED="1524422821205" ID="ID_941652095" MODIFIED="1524422821205" TEXT="&#xf0a7; Registrar erros conhecidos"/>
<node CREATED="1524422821205" ID="ID_1258546089" MODIFIED="1524422821205" TEXT="&#xf0a7; Resolver e encerrar problemas"/>
<node CREATED="1524422821205" ID="ID_219269659" MODIFIED="1524422821205" TEXT="&#xf0a7; Realizar gerenciamento proativo de problemas"/>
</node>
</node>
<node CREATED="1524422830372" FOLDED="true" ID="ID_1703302118" MODIFIED="1579037460081" TEXT="DSS04 Gerenciar a Continuidade">
<node CREATED="1524422835050" ID="ID_106664751" MODIFIED="1524422835585" TEXT="Estabelece e mante&#x301;m um plano para permitir o nego&#x301;cio e TI responder a incidentes e interrupc&#x327;o&#x303;es, a fim de continuar a operac&#x327;a&#x303;o de processos cri&#x301;ticos de nego&#x301;cios e servic&#x327;os de TI necessa&#x301;rios e mante&#x301;m a disponibilidade de informac&#x327;o&#x303;es em um ni&#x301;vel aceita&#x301;vel para a organizac&#x327;a&#x303;o"/>
<node CREATED="1579037355182" ID="ID_445683093" MODIFIED="1579037371066" TEXT="no Itil tem 1 p&#xe9; na constru&#xe7;&#xe3;o e outro na opera&#xe7;&#xe3;o. O Cobit deixou ele na opera&#xe7;&#xe3;o"/>
<node CREATED="1524422913855" FOLDED="true" ID="ID_1714317763" MODIFIED="1534894903258" TEXT="Pr&#xe1;ticas">
<node CREATED="1524422913855" ID="ID_95983476" MODIFIED="1524422913855" TEXT="&#xf0a7; Definir pol&#xed;tica, objetivos e escopo da continuidade de neg&#xf3;cios"/>
<node CREATED="1524422913855" ID="ID_20438004" MODIFIED="1524422913855" TEXT="&#xf0a7; Manter uma estrat&#xe9;gia de continuidade"/>
<node CREATED="1524422913860" ID="ID_610135906" MODIFIED="1524422913860" TEXT="&#xf0a7; Desenvolver e implementar uma resposta de continuidade de neg&#xf3;cios"/>
<node CREATED="1524422913860" ID="ID_1333125182" MODIFIED="1524422913860" TEXT="&#xf0a7; Exercitar, testar e revisar o PCN"/>
<node CREATED="1524422913865" ID="ID_1235760195" MODIFIED="1524422913865" TEXT="&#xf0a7; Revisart, manter e aprimorar o plano de continuidade"/>
<node CREATED="1524422913865" ID="ID_1544459890" MODIFIED="1524422913865" TEXT="&#xf0a7; Conduzir treinamentos do plano de continuidade"/>
<node CREATED="1524422913865" FOLDED="true" ID="ID_1958690748" MODIFIED="1534894903257" TEXT="&#xf0a7; Gerenciar preparativos de backup">
<node CREATED="1524423005664" ID="ID_1374431069" MODIFIED="1524423015766" TEXT="Respons&#xe1;vel por assegurar que se tenha rotinas de backup"/>
</node>
<node CREATED="1524422913870" ID="ID_245538885" MODIFIED="1524422913870" TEXT="&#xf0a7; Conduzir revis&#xe3;o p&#xf3;s-recupera&#xe7;&#xe3;o"/>
</node>
</node>
<node CREATED="1524422977022" FOLDED="true" ID="ID_1358957889" MODIFIED="1579037506405" TEXT="DSS05 Gerenciar Servic&#x327;os de Seguranc&#x327;a">
<node CREATED="1524422983056" ID="ID_1706864911" MODIFIED="1524422983396" TEXT="Protege informac&#x327;o&#x303;es da organizac&#x327;a&#x303;o para manter o ni&#x301;vel de risco aceita&#x301;vel para a seguranc&#x327;a da informac&#x327;a&#x303;o da organizac&#x327;a&#x303;o, de acordo com a poli&#x301;tica de seguranc&#x327;a"/>
<node CREATED="1524423043535" ID="ID_1178588705" MODIFIED="1524423043960" TEXT="Estabelece e mante&#x301;m as func&#x327;o&#x303;es de seguranc&#x327;a da informac&#x327;a&#x303;o e privile&#x301;gios de acesso e realiza o monitoramento de seguranc&#x327;a"/>
<node CREATED="1579037465725" ID="ID_1949525446" MODIFIED="1579037496898" TEXT="gerenciar servi&#xe7;os de seguran&#xe7;a envolve o trabalho preventivo e o monitoramento da infra"/>
<node CREATED="1524423051590" FOLDED="true" ID="ID_466005343" MODIFIED="1534894903258" TEXT="Pr&#xe1;ticas">
<node CREATED="1524423051590" ID="ID_1635553860" MODIFIED="1524423051590" TEXT="&#xf0a7; Proteger contra malware"/>
<node CREATED="1524423051590" ID="ID_483969518" MODIFIED="1524423051590" TEXT="&#xf0a7; Gerenciar seguran&#xe7;a de rede e conectividade"/>
<node CREATED="1524423051590" ID="ID_1442508157" MODIFIED="1524423051590" TEXT="&#xf0a7; Gerenciar seguran&#xe7;a de endpoints"/>
<node CREATED="1524423051595" ID="ID_262018491" MODIFIED="1524423051595" TEXT="&#xf0a7; Gerenciar identidade e acesso l&#xf3;gico de usu&#xe1;rios"/>
<node CREATED="1524423051595" ID="ID_1287082768" MODIFIED="1524423051595" TEXT="&#xf0a7; Gerenciar acesso f&#xed;sico a ativos de TI"/>
<node CREATED="1524423051595" ID="ID_1302459484" MODIFIED="1524423051595" TEXT="&#xf0a7; Gerenciar documentos e dispositivos de sa&#xed;da sens&#xed;veis"/>
<node CREATED="1524423051600" ID="ID_74061581" MODIFIED="1524423051600" TEXT="&#xf0a7; Monitorar a infraestrutura quanto a eventos relacionados a seguran&#xe7;a"/>
</node>
</node>
<node CREATED="1524423073036" FOLDED="true" ID="ID_496256206" MODIFIED="1579037566958" TEXT="DSS06 Gerenciar os Controles de Processos de Nego&#x301;cio">
<icon BUILTIN="full-1"/>
<node CREATED="1524423084059" ID="ID_1779314158" MODIFIED="1524423084474" TEXT="Define e mante&#x301;m controles de processo de nego&#x301;cio apropriados para assegurar que as informac&#x327;o&#x303;es relacionadas e processadas satisfaz todos os requisitos de controle de informac&#x327;o&#x303;es relevantes"/>
<node CREATED="1524423089424" FOLDED="true" ID="ID_990257464" MODIFIED="1549317297852" TEXT="Pr&#xe1;ticas">
<node CREATED="1524423096009" ID="ID_1746202931" MODIFIED="1524423117046" TEXT="&#xf0a7; Alinhar atividades de controle embutidas nos processos de neg&#xf3;cio com os objetivos corporativos"/>
<node CREATED="1524423102575" ID="ID_1916602540" MODIFIED="1524423102575" TEXT="&#xf0a7; Controlar o processamento da informa&#xe7;&#xe3;o"/>
<node CREATED="1524423102575" ID="ID_703940628" MODIFIED="1524423106165" TEXT="&#xf0a7; Gerenciar pap&#xe9;is, resonsabilidades, privil&#xe9;gios de acesso e n&#xed;veis de autoridade"/>
<node CREATED="1524423102580" ID="ID_543861897" MODIFIED="1524423102580" TEXT="&#xf0a7; Gerenciar erros e exce&#xe7;&#xf5;es"/>
<node CREATED="1524423102585" ID="ID_156475334" MODIFIED="1524423111022" TEXT="&#xf0a7; Assegurar rastreabilidade de eventos e responsabilidade sobre informa&#xe7;&#xf5;es"/>
<node CREATED="1524423102585" ID="ID_1696808222" MODIFIED="1524423102585" TEXT="&#xf0a7; Manter seguros os ativos de informa&#xe7;&#xe3;o"/>
</node>
<node COLOR="#cc6600" CREATED="1549317125895" FOLDED="true" ID="ID_851745427" MODIFIED="1549317331343" TEXT="[cespe] Gerenciar controles do processo de neg&#xf3;cio &#x2014; do dom&#xed;nio chamado de monitorar, avaliar e medir &#x2014; &#xe9; um processo de gest&#xe3;o que tem como pr&#xe1;tica monitorar e avaliar o ambiente tecnol&#xf3;gico alinhado ao direcionamento hol&#xed;stico da gest&#xe3;o da organiza&#xe7;&#xe3;o. ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1549317139278" ID="ID_1341032901" MODIFIED="1549317141267" TEXT="dominio DSS"/>
<node CREATED="1549317299791" ID="ID_1714567009" MODIFIED="1549317301875" TEXT="e tem outro objetivo"/>
</node>
</node>
<node COLOR="#cc6600" CREATED="1579037567405" FOLDED="true" ID="ID_231004864" MODIFIED="1585597357676" TEXT="[cespe] Gerenciar mudan&#xe7;as e gerenciar problemas s&#xe3;o processos do dom&#xed;nio deliver, service and support, que abrange aspectos de entrega de tecnologia da informa&#xe7;&#xe3;o, bem como da execu&#xe7;&#xe3;o de aplica&#xe7;&#xf5;es dentro do sistema de TI e seus resultados.">
<node CREATED="1579037574390" ID="ID_1396815719" MODIFIED="1579037580065" TEXT="gerenciar mudan&#xe7;as &#xe9; BAI"/>
<node CREATED="1579037586453" ID="ID_280970131" MODIFIED="1579037594849" TEXT="s&#xf3; gerenciar problemas q &#xe9; DSS"/>
</node>
<node CREATED="1579037639381" FOLDED="true" ID="ID_1423245431" MODIFIED="1579037782603" TEXT="resumo">
<node CREATED="1579037641218" ID="ID_200941547" MODIFIED="1579037652553" TEXT="o Gerenciamento de Opera&#xe7;&#xf5;es mantem tudo funcionando"/>
<node CREATED="1579037652782" ID="ID_892709164" MODIFIED="1579037692146" TEXT="qdo h&#xe1; algum problema, os processos de gerenciar Requisi&#xe7;&#xf5;es de Servi&#xe7;o e Incidente agem"/>
<node CREATED="1579037702429" ID="ID_919602528" MODIFIED="1579037708681" TEXT="a gerencia de incidentes precisa da gerencia de problemas"/>
<node CREATED="1579037720533" ID="ID_142621794" MODIFIED="1579037735437" TEXT="na retaguarda tem os processos que cuidam da Continuidade e Seguran&#xe7;a"/>
<node CREATED="1579037743391" ID="ID_1572901259" MODIFIED="1579037772178" TEXT="Gerenciar os Controles possui os controles do processo de negocio"/>
<node CREATED="1579037763912" MODIFIED="1579037763912">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_2908080694740478603.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#cc6600" CREATED="1585597974828" ID="ID_1279895320" MODIFIED="1585597980173" TEXT="[cespe] O dom&#xed;nio entregar, reparar e suportar visa entregar, de fato, os servi&#xe7;os requeridos, al&#xe9;m de processos que gerenciam incidentes, problemas e seguran&#xe7;a.  ">
<node CREATED="1585598022476" ID="ID_427043923" MODIFIED="1585598031145" TEXT="apesar da tradu&#xe7;&#xe3;o ser REPARAR, a questao foi dada como correta"/>
<node CREATED="1585598042165" ID="ID_1614299286" MODIFIED="1585598042668" TEXT="Este dom&#xed;nio cobre a entrega propriamente dita dos servi&#xe7;os requeridos, incluindo gerenciamento de seguran&#xe7;a e continuidade, reparo de equipamentos e demais itens relacionados, suporte aos servi&#xe7;os para os usu&#xe1;rios, gest&#xe3;o dos dados e da infraestrutura operacional."/>
</node>
</node>
<node CREATED="1524404700229" FOLDED="true" ID="ID_531574765" MODIFIED="1579118095091" TEXT="Monitorar, Avaliar e Medir (MEA)">
<icon BUILTIN="full-1"/>
<node CREATED="1524404705100" ID="ID_1687954371" MODIFIED="1524404705295" TEXT="Monitora o desempenho dos processos de TI, avaliando a conformidade com os objetivos e com os requisitos externos"/>
<node CREATED="1579037814245" ID="ID_1762372620" MODIFIED="1579037817866" TEXT="gest&#xe3;o verificando tudo q acontece"/>
<node CREATED="1579037827317" ID="ID_23557923" MODIFIED="1579037878754" TEXT="desempenho: o resultado esta conforme solicitado?"/>
<node CREATED="1579037863677" ID="ID_974287149" MODIFIED="1579037872209" TEXT="conformidade: estou seguindo as normas q se aplicam?"/>
<node CREATED="1579037883366" ID="ID_669042140" MODIFIED="1579037913178" TEXT="medir: monitora toda a gest&#xe3;o APO, BAI e DSS"/>
<node CREATED="1524404737521" FOLDED="true" ID="ID_1302250912" MODIFIED="1585597357676" TEXT="3 processos">
<node CREATED="1524423189185" FOLDED="true" ID="ID_1784990524" MODIFIED="1585597357676" TEXT="MEA01 Monitorar, Avaliar e Medir o Desempenho e Conformidade">
<node CREATED="1524423216672" ID="ID_845509507" MODIFIED="1524423226598" TEXT="A gest&#xe3;o monitora o seu pr&#xf3;prio desempenho"/>
<node CREATED="1524423316165" ID="ID_1654320081" MODIFIED="1524423326714" TEXT="Monitoramento sobre a Opera&#xe7;ao"/>
<node CREATED="1524423198110" ID="ID_608039464" MODIFIED="1524423198385" TEXT="Coleta, valida e avalia os objetivos e me&#x301;tricas do processo de nego&#x301;cios e de TI"/>
<node CREATED="1524423201618" ID="ID_334542537" MODIFIED="1524423201960" TEXT="Monitora se os processos esta&#x303;o realizando conforme metas e me&#x301;tricas de desempenho e conformidade acordadas e fornece informac&#x327;a&#x303;o que e&#x301; sistema&#x301;tica e oportuna"/>
<node CREATED="1579117799773" ID="ID_504325599" MODIFIED="1579117803729" TEXT="trata da conformidade interna"/>
<node CREATED="1524423206777" FOLDED="true" ID="ID_1831650103" MODIFIED="1534894903260" TEXT="Pr&#xe1;ticas">
<node CREATED="1524423206782" ID="ID_121975906" MODIFIED="1524423206782" TEXT="&#xf0a7; Estabelecer uma abordagem de monitoramento"/>
<node CREATED="1524423206782" ID="ID_982912721" MODIFIED="1524423206782" TEXT="&#xf0a7; Definir metas de desempenho e conformidade"/>
<node CREATED="1524423206782" ID="ID_488015470" MODIFIED="1524423206782" TEXT="&#xf0a7; Coletar e processor dados de desempenho e conformidade"/>
<node CREATED="1524423206787" ID="ID_1588008040" MODIFIED="1524423206787" TEXT="&#xf0a7; Analisar e reportar desempenho"/>
<node CREATED="1524423206787" ID="ID_736306271" MODIFIED="1524423206787" TEXT="&#xf0a7; Assegurar a implementa&#xe7;&#xe3;o de a&#xe7;&#xf5;es corretivas"/>
</node>
</node>
<node CREATED="1524423235314" FOLDED="true" ID="ID_179646492" MODIFIED="1579117805310" TEXT="MEA02 Monitorar, Avaliar e Medir o Sistema de Controle Interno">
<node CREATED="1524423308844" ID="ID_751915508" MODIFIED="1524423329780" TEXT="Monitoramento sobre a Gest&#xe3;o"/>
<node CREATED="1524423242573" ID="ID_1873800715" MODIFIED="1524423242885" TEXT="Monitora e avalia continuamente o ambiente de controle, incluindo autoavaliac&#x327;o&#x303;es e ana&#x301;lises de avaliac&#x327;o&#x303;es independentes"/>
<node CREATED="1524423246059" ID="ID_246970261" MODIFIED="1524423246424" TEXT="Permite a gesta&#x303;o de identificar deficie&#x302;ncias de controle e ineficie&#x302;ncias e iniciar ac&#x327;o&#x303;es de melhoria"/>
<node CREATED="1579037938046" ID="ID_138863517" MODIFIED="1579037984162" TEXT="controle interno &#xe9; qualquer mecanismo q eu coloco sobre um processo, p minimizar o risco desse processo n&#xe3;o trazer resultado e n&#xe3;o cumprir a lei"/>
<node CREATED="1524423251410" FOLDED="true" ID="ID_741919631" MODIFIED="1534894903262" TEXT="Pr&#xe1;ticas">
<node CREATED="1524423251415" ID="ID_448852132" MODIFIED="1524423251415" TEXT="&#xf0a7; Monitorar controles internos"/>
<node CREATED="1524423251415" ID="ID_344817877" MODIFIED="1524423251415" TEXT="&#xf0a7; Revisar efetividade de controles de processos de neg&#xf3;cio"/>
<node CREATED="1524423251420" ID="ID_592588660" MODIFIED="1524423251420" TEXT="&#xf0a7; Realizar auto-avalia&#xe7;&#xf5;es de controles"/>
<node CREATED="1524423251420" ID="ID_1325409863" MODIFIED="1524423251420" TEXT="&#xf0a7; Identificar e reporter defici&#xea;ncias de controles"/>
<node CREATED="1524423251420" ID="ID_671938397" MODIFIED="1524423255350" TEXT="&#xf0a7; Assegurar que provedores de garantia (auditoria) sejam independents e qualificados"/>
<node CREATED="1524423251425" ID="ID_372609651" MODIFIED="1524423251425" TEXT="&#xf0a7; Planejar iniciativas de garantia (auditoria)"/>
<node CREATED="1524423251425" ID="ID_1708767226" MODIFIED="1524423251425" TEXT="&#xf0a7; Definir escopo de iniciativas de garantia (auditoria)"/>
<node CREATED="1524423251430" ID="ID_55213239" MODIFIED="1524423251430" TEXT="&#xf0a7; Executar iniciativas de garantia (auditoria)"/>
</node>
</node>
<node CREATED="1524423285495" FOLDED="true" ID="ID_28615561" MODIFIED="1585597357676" TEXT="MEA03 Monitorar, Avaliar e Medir a Conformidade com Requisitos Externos">
<node CREATED="1524423290832" ID="ID_946871652" MODIFIED="1524423291165" TEXT="Avalia se processos de TI e processos de nego&#x301;cios suportados pela TI esta&#x303;o em conformidade com as leis, regulamentos e exige&#x302;ncias contratuais"/>
<node CREATED="1524423294318" ID="ID_494106248" MODIFIED="1524423294727" TEXT="Obte&#x301;m a garantia de que os requisitos foram identificados e respeitados, e integra-los a&#x300; conformidade com o cumprimento global da organizac&#x327;a&#x303;o"/>
<node CREATED="1524423343753" FOLDED="true" ID="ID_1791965177" MODIFIED="1534894903263" TEXT="Pr&#xe1;ticas">
<node CREATED="1524423343755" ID="ID_1406446699" MODIFIED="1524423343755" TEXT="&#xf0a7; Identificar requisitos de conformidade externos"/>
<node CREATED="1524423343757" ID="ID_1789373909" MODIFIED="1524423343757" TEXT="&#xf0a7; Otimizar resposta a requisitos externos"/>
<node CREATED="1524423343759" ID="ID_834740818" MODIFIED="1524423343759" TEXT="&#xf0a7; Confirmar conformidade externa"/>
<node CREATED="1524423343762" ID="ID_1364813114" MODIFIED="1524423343762" TEXT="&#xf0a7; Obter garantia de conformidade externa"/>
</node>
</node>
<node COLOR="#ff0000" CREATED="1579117823869" ID="ID_1474039717" MODIFIED="1579117919600" TEXT="n&#xe3;o existe auditoria no cobit 5, somente auditoria externa"/>
<node COLOR="#cc6600" CREATED="1579117905380" ID="ID_995148227" MODIFIED="1579117922377" TEXT="[cespe] O COBIT 5 prov&#xea; um modelo de auditoria organizado no processo gest&#xe3;o, o qual visa garantir que as necessidades e condi&#xe7;&#xf5;es observadas na auditoria sejam avaliadas a fim de determinar objetivos corporativos acordados e equilibrados.">
<icon BUILTIN="button_cancel"/>
</node>
<node CREATED="1579117957220" ID="ID_357077365" MODIFIED="1579117987433" TEXT="o resultado desses 3 processo realimentam meu planejamento como d&#xe1; feedback p governan&#xe7;a"/>
</node>
<node COLOR="#cc6600" CREATED="1535915060520" ID="ID_797419630" MODIFIED="1535915065782" TEXT="[cespe] A monitora&#xe7;&#xe3;o cont&#xed;nua prov&#xea; m&#xe9;tricas que podem provocar mudan&#xe7;as nos planos de neg&#xf3;cio necess&#xe1;rios &#xe0; entrega de servi&#xe7;os de TI. "/>
</node>
</node>
<node COLOR="#cc6600" CREATED="1585598158661" FOLDED="true" ID="ID_636354731" MODIFIED="1585598234446" TEXT="[cespe] Os riscos no COBIT 5 s&#xe3;o abordados tanto no n&#xed;vel de governan&#xe7;a quanto no de gest&#xe3;o; neste &#xfa;ltimo, pelo processo gerenciar riscos, e naquele, pelo processo assegurar a otimiza&#xe7;&#xe3;o dos riscos.  ">
<node CREATED="1585598194894" ID="ID_555903463" MODIFIED="1585598202066" TEXT="Governan&#xe7;a: AVALIAR, DIRIGIR E MONITORAR (EDM03) - Garantir a Otimiza&#xe7;&#xe3;o de Riscos: "/>
<node CREATED="1585598194896" ID="ID_1688502469" MODIFIED="1585598206609" TEXT="Gest&#xe3;o: ALINHAR, PLANEJAR E ORGANIZAR (APO12) - Gerenciar Riscos: "/>
</node>
</node>
<node COLOR="#800000" CREATED="1524432922823" FOLDED="true" ID="ID_594409182" MODIFIED="1585598435968" POSITION="right" TEXT="Modelo de Capacidade">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1524432931879" ID="ID_400021730" MODIFIED="1524521189039" TEXT="usa a mesma base do MPS.Br para avaliar a capacidade de processo: a ISO 15504"/>
<node CREATED="1524521246106" ID="ID_1624018100" MODIFIED="1549317526115" TEXT="n&#xe3;o existe n&#xed;vel de MATURIDADE no COBIT 5">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1579118189253" ID="ID_732757021" MODIFIED="1579118195481" TEXT="avalia a capacidade de processos individiuais"/>
<node CREATED="1579118195685" ID="ID_438814512" MODIFIED="1579118200793" TEXT="no cobit 5 n&#xe3;o se avalia a organiza&#xe7;&#xe3;o"/>
<node CREATED="1524432964151" FOLDED="true" ID="ID_1564182818" MODIFIED="1579118485036" TEXT="modelo">
<node CREATED="1524432966137" ID="ID_227121291" MODIFIED="1524432966137">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_4445774369762080144.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1579118353940" ID="ID_546543276" MODIFIED="1579118376313" TEXT="o nome do nivel 0 &#xe9; processo incompleto (essa figura do cobit veio errado)"/>
<node CREATED="1579118426429" ID="ID_1723754584" MODIFIED="1579118438609" TEXT="s&#xe3;o cumulativos, p chegar no nivel 5 j&#xe1; atingiu os niveis anteriores"/>
<node CREATED="1524432990930" ID="ID_997814147" MODIFIED="1524433016266" TEXT="se os Atributos de Capacidade estiverem presentes, ent&#xe3;o o n&#xed;vel de capacidade foi atendido"/>
<node CREATED="1524521435834" ID="ID_903107783" MODIFIED="1524521446107" TEXT="para o 1.1 exijo pelo menos 86% dos resultados "/>
<node CREATED="1524521448282" ID="ID_824156874" MODIFIED="1524521464340" TEXT="para n&#xed;vel 2, os atributos 2.1 e 2.2 devem ser pelo menos Largamente Implementados"/>
<node CREATED="1524521467823" ID="ID_1371544768" MODIFIED="1524521478579" TEXT="para o n&#xed;vel 3, deve ter um processo definido e implementado conforme o padr&#xe3;o"/>
<node CREATED="1524521485297" ID="ID_83810207" MODIFIED="1524521493033" TEXT="se tiver definido e implementado, pode alcan&#xe7;ar o n&#xed;vel 4"/>
<node CREATED="1524521499971" ID="ID_458263113" MODIFIED="1524521509792" TEXT="se &#xe9; medido e controlado, pode chegar no n&#xed;vel 5"/>
</node>
<node CREATED="1524433029881" FOLDED="true" ID="ID_1482396301" MODIFIED="1579118333429" TEXT="Atributos de processo">
<node CREATED="1524433034869" FOLDED="true" ID="ID_552303368" MODIFIED="1585597357676" TEXT="AP 1.1 O processo &#xe9; executado">
<node CREATED="1524433034872" ID="ID_1327972781" MODIFIED="1524521531218" TEXT="O processo atinge o seu prop&#xf3;sito"/>
</node>
<node CREATED="1524433034874" FOLDED="true" ID="ID_203116973" MODIFIED="1585597357677" TEXT="AP 2.1 O processo &#xe9; gerenciado">
<node CREATED="1524433034876" ID="ID_1375616717" MODIFIED="1524521532753" TEXT="A execu&#xe7;&#xe3;o do processo &#xe9; gerenciada"/>
</node>
<node CREATED="1524433034878" FOLDED="true" ID="ID_856348290" MODIFIED="1585597357677" TEXT="AP 2.2 Os produtos de trabalho s&#xe3;o gerenciados">
<node CREATED="1524433041816" ID="ID_1446455057" MODIFIED="1524433042232" TEXT="Os produtos de trabalho produzidos pelo processo s&#xe3;o gerenciados apropriadamente"/>
</node>
<node CREATED="1524433046431" FOLDED="true" ID="ID_1572276506" MODIFIED="1585597357677" TEXT="AP 3.1. O processo &#xe9; definido">
<node CREATED="1524433046433" ID="ID_1703238962" MODIFIED="1524521534322" TEXT="Um padr&#xe3;o &#xe9; mantido para apoiar a implementa&#xe7;&#xe3;o do processo"/>
</node>
<node CREATED="1524433046436" FOLDED="true" ID="ID_1482937376" MODIFIED="1585597357677" TEXT="AP 3.2 O processo est&#xe1; implementado">
<node CREATED="1524433050648" ID="ID_475081231" MODIFIED="1524433050930" TEXT="O processo padr&#xe3;o &#xe9; efetivamente implementado para atingir seus resultados"/>
</node>
<node CREATED="1524433266601" FOLDED="true" ID="ID_21767054" MODIFIED="1585597357678" TEXT="AP 4.1 O processo &#xe9; medido">
<node CREATED="1524433271759" ID="ID_749415800" MODIFIED="1524433272055" TEXT="Medi&#xe7;&#xf5;es s&#xe3;o usadas para assegurar que o desempenho do processo ap&#xf3;ia o alcance dos objetivos de neg&#xf3;cio definidos"/>
</node>
<node CREATED="1524433275592" FOLDED="true" ID="ID_1285975839" MODIFIED="1585597357678" TEXT="AP 4.2 O processo &#xe9; controlado">
<node CREATED="1524433279411" ID="ID_1320929655" MODIFIED="1524433279680" TEXT="O processo &#xe9; controlado estatisticamente para produzir um processo est&#xe1;vel, capaz e previs&#xed;vel"/>
</node>
<node CREATED="1524433283613" FOLDED="true" ID="ID_1683257386" MODIFIED="1585597357678" TEXT=" AP 5.1 O processo &#xe9; objeto de inova&#xe7;&#xf5;es">
<node CREATED="1524433287413" ID="ID_1711273370" MODIFIED="1524433287658" TEXT="As mudan&#xe7;as no processo s&#xe3;o identificadas a partir da an&#xe1;lise de causas comuns de varia&#xe7;&#xe3;o e da investiga&#xe7;&#xe3;o de inova&#xe7;&#xf5;es"/>
</node>
<node CREATED="1524433292791" FOLDED="true" ID="ID_917916168" MODIFIED="1585597357678" TEXT="AP 5.2 O processo &#xe9; otimizado continuamente">
<node CREATED="1524433297091" ID="ID_1849022068" MODIFIED="1524433297315" TEXT="As mudan&#xe7;as no processo t&#xea;m impacto efetivo para o alcance dos objetivos relevantes de melhoria"/>
</node>
</node>
<node CREATED="1524521614005" FOLDED="true" ID="ID_1827214712" MODIFIED="1585598433740" TEXT="N&#xed;veis de capacidade">
<icon BUILTIN="full-2"/>
<node CREATED="1524521618872" FOLDED="true" ID="ID_850020589" MODIFIED="1585597357679" TEXT="N&#xed;vel 0 - Processo Incompleto">
<node CREATED="1524521618876" ID="ID_256390057" MODIFIED="1524521712766" TEXT="O processo n&#xe3;o est&#xe1; implementado ou n&#xe3;o atinge seu objetivo"/>
<node CREATED="1524521623939" ID="ID_1928734906" MODIFIED="1524521624306" TEXT="H&#xe1; pouca ou nenhuma evid&#xea;ncia de realiza&#xe7;&#xe3;o sistem&#xe1;tica da finalidade do processo"/>
</node>
<node CREATED="1524521629105" FOLDED="true" ID="ID_1483917835" MODIFIED="1579118633898" TEXT="N&#xed;vel 1 - Processo Realizado">
<node CREATED="1524521629108" ID="ID_1827962650" MODIFIED="1524521711009" TEXT="Atributo PA1.1 &#x2013; Process Performance"/>
<node CREATED="1524521629110" ID="ID_342893226" MODIFIED="1524521709131" TEXT="O processo est&#xe1; implementado e atinge seu objetivo"/>
</node>
<node CREATED="1524521636299" ID="ID_579306791" MODIFIED="1585598320651" TEXT="N&#xed;vel 2 - Processo Gerenciado">
<node CREATED="1524521641352" ID="ID_1440926324" MODIFIED="1524521641630" TEXT="Atributos PA2.1 &#x2013; Performance Management e PA2.2 &#x2013; Work Product Management"/>
<node CREATED="1524521646132" ID="ID_427103460" MODIFIED="1524521646451" TEXT=" O processo realizado (n&#xed;vel 1) &#xe9; implementado de forma gerenciada (planejado, monitorado e ajustado) e seus produtos de trabalho est&#xe3;o devidamente estabelecidos, controlados e mantidos"/>
</node>
<node CREATED="1524521652556" ID="ID_538340086" MODIFIED="1585598334709" TEXT="N&#xed;vel 3 - Processo Estabelecido">
<node CREATED="1524521652558" ID="ID_1118950062" MODIFIED="1524521706177" TEXT="Atributos PA3.1 &#x2013; Process Definition e PA3.2 &#x2013; Process Deployment"/>
<node CREATED="1524521657969" ID="ID_612947127" MODIFIED="1524521658353" TEXT="O processo gerenciado (n&#xed;vel 2) &#xe9; implementado usando um processo definido que &#xe9; capaz de alcan&#xe7;ar os seus resultados de processo"/>
<node COLOR="#cc6600" CREATED="1549315625666" ID="ID_1427917661" MODIFIED="1549315633597" TEXT="[cespe] Quando um processo atinge o n&#xed;vel 3 &#x2015; denominado processo estabelecido, que possui dois atributos de execu&#xe7;&#xe3;o &#x2015;, ele &#xe9; implementado com a utiliza&#xe7;&#xe3;o de um processo definido capaz de atingir seus resultados."/>
<node CREATED="1549315748180" ID="ID_411370426" MODIFIED="1549315748180" TEXT="Atributo de processo 3.1 - defini&#xe7;&#xe3;o do processo"/>
<node CREATED="1549315748195" ID="ID_264317248" MODIFIED="1549315748195" TEXT="Atributo de processo 3.2 - implementa&#xe7;&#xe3;o do processo"/>
</node>
<node CREATED="1524521666545" FOLDED="true" ID="ID_1351549915" MODIFIED="1550317572514" TEXT="N&#xed;vel 4 - Processo Previs&#xed;vel">
<node CREATED="1524521666547" ID="ID_758993843" MODIFIED="1524521704202" TEXT="Atributos PA4.1 &#x2013; Process Management e PA4.2 &#x2013; Process Control"/>
<node CREATED="1524521671704" ID="ID_903094345" MODIFIED="1524521671958" TEXT="O processo estabelecido (n&#xed;vel 3) opera dentro de limites definidos para alcan&#xe7;ar seus resultados de processo"/>
<node COLOR="#cc6600" CREATED="1549315822226" FOLDED="true" ID="ID_638212362" MODIFIED="1566339364576" TEXT="[cespe] O n&#xed;vel de capacidade 3 &#x2014; processo estabelecido &#x2014; abrange os processos que operam dentro de limites definidos para atingir os resultados esperados. ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1549315834328" ID="ID_95279403" MODIFIED="1549315838116" TEXT="processo previsivel"/>
</node>
<node CREATED="1549315893921" MODIFIED="1549315893921" TEXT="Opera  = Processo  Previsivel"/>
<node CREATED="1549315893926" MODIFIED="1549315893926" TEXT="Implementado  = Processo Estabelecido"/>
</node>
<node CREATED="1524521676412" FOLDED="true" ID="ID_142293929" MODIFIED="1579118631726" TEXT="N&#xed;vel 5 - Processo Em Otimiza&#xe7;&#xe3;o">
<node CREATED="1524521680861" ID="ID_632473575" MODIFIED="1524521681115" TEXT=" Atributos PA5.1 &#x2013; Process Innovation e PA5.2 &#x2013; Process Optimization"/>
<node CREATED="1524521687470" ID="ID_229013694" MODIFIED="1524521687764" TEXT=" O processo previs&#xed;vel (n&#xed;vel 4) &#xe9; continuamente melhorado para atender aos objetivos de neg&#xf3;cio"/>
</node>
<node COLOR="#cc6600" CREATED="1585598355701" ID="ID_1408394386" MODIFIED="1585598361358" TEXT="[cespe] No COBIT 5, &#xe9; de n&#xed;vel 2 o processo que, ap&#xf3;s uma avalia&#xe7;&#xe3;o de seus atributos de capacidade, seja classificado como implementado utilizando um processo definido capaz de atingir os seus resultados esperados, ou seja, o processo &#xe9; gerenciado.  ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1585598367402" MODIFIED="1585598367402" TEXT="No COBIT 5, o N&#xcd;VEL 2 de capacidade de processo &#xe9; o processo gerenciado, mas na quest&#xe3;o, um processo definido capaz de atingir os seus resultados, representa o N&#xcd;VEL 3 de capacidade do processo, ou seja processo estabelecido, portanto a quest&#xe3;o est&#xe1; errada."/>
</node>
</node>
<node CREATED="1524433071194" FOLDED="true" ID="ID_964352835" MODIFIED="1579118953424" TEXT="Avalia&#xe7;&#xe3;o dos atributos de processo">
<node CREATED="1524433308626" ID="ID_1498624575" MODIFIED="1524433308626">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_4093893276632876628.jpeg"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1579118228124" ID="ID_1627725307" MODIFIED="1579118254081" TEXT="verifica se o atributo est&#xe1; presente no processo q est&#xe1; sendo avaliado"/>
<node CREATED="1579118258727" ID="ID_1579039456" MODIFIED="1579118265785" TEXT="s&#xe3;o 9 atributos de processo"/>
<node CREATED="1524521284166" ID="ID_713961996" MODIFIED="1579118617153" TEXT="se o Atributo do Processo est&#xe1; presente ele deve estar pelo menos LARGAMENTE IMPLEMENTADO, nesse caso ele est&#xe1; presente na maioria das vezes"/>
<node CREATED="1524521343401" ID="ID_824094114" MODIFIED="1524521365814" TEXT="se n&#xe3;o atinjo o n&#xed;vel de pelo menos 50%, o processo &#xe9; INCOMPLETO (inexistente)"/>
<node CREATED="1524521570325" FOLDED="true" ID="ID_242393417" MODIFIED="1585597357679" TEXT="Os requisitos espec&#xed;ficos de um n&#xed;vel de capacidade podem ser totalmente ou largamente implementados">
<node CREATED="1524521576164" ID="ID_160321407" MODIFIED="1524521576484" TEXT="Por&#xe9;m, cada n&#xed;vel de capacidade s&#xf3; pode ser alcan&#xe7;ado quando os requisitos do n&#xed;vel inferior tiverem sido totalmente implementados"/>
</node>
<node CREATED="1524521583186" FOLDED="true" ID="ID_1587733753" MODIFIED="1585597357679" TEXT="Por exemplo, para uma capacidade de processo n&#xed;vel 3 (Processo Estabelecido)">
<node CREATED="1524521589170" ID="ID_1051835335" MODIFIED="1524521589431" TEXT="Atributos Defini&#xe7;&#xe3;o de Processos (PA 3.1) e Implementa&#xe7;&#xe3;o do Processo (PA 3.2) podem ser largamente implementados"/>
<node CREATED="1524521596212" ID="ID_323274050" MODIFIED="1524521596545" TEXT="Atributos do n&#xed;vel de capacidade 2 (PA 2.1 e PA 2.2) e 1 (PA 1.1) devem ser totalmente implementados"/>
</node>
</node>
<node CREATED="1524521764063" FOLDED="true" ID="ID_228506681" MODIFIED="1579118946489" TEXT="resumo">
<node CREATED="1524521777246" ID="ID_678408694" MODIFIED="1524521777246">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_4296723556049763860.jpeg"/>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#cc6600" CREATED="1535915135430" FOLDED="true" ID="ID_655551983" MODIFIED="1585597357679" TEXT="[cespe] A aplica&#xe7;&#xe3;o do modelo de avalia&#xe7;&#xe3;o de capacidades de processos do COBIT 5 &#xe9; insuficiente para fornecer um quadro completo a respeito da governan&#xe7;a de uma organiza&#xe7;&#xe3;o. ">
<icon BUILTIN="button_cancel"/>
<node CREATED="1535915179318" ID="ID_1587417809" MODIFIED="1535915191849" TEXT="Embora esta abordagem (de modelo de capacidade) forne&#xe7;a informa&#xe7;&#xf5;es valiosas sobre o estado dos processos, os processos s&#xe3;o apenas um dos 7 habilitadores de governan&#xe7;a e gest&#xe3;o. Consequentemente, as avalia&#xe7;&#xf5;es de processos N&#xc3;O apresenta&#xe7;&#xe3;o o quadro completo do estado de governan&#xe7;a de uma organiza&#xe7;&#xe3;o.  Para tanto, os demais habilitadores tamb&#xe9;m  devem ser avaliados.&quot; "/>
</node>
<node COLOR="#cc6600" CREATED="1579118840397" FOLDED="true" ID="ID_1363145267" MODIFIED="1585597357679" TEXT="[cespe] O COBIT 5 prov&#xea; um modelo de maturidade gen&#xe9;rico que demonstra como o gerenciamento do controle interno e a necessidade do estabelecimento de melhores controles tipicamente se desenvolvem de um n&#xed;vel ad hoc para um n&#xed;vel otimizado.">
<icon BUILTIN="button_cancel"/>
<node CREATED="1579118867413" ID="ID_990153582" MODIFIED="1579118871658" TEXT="esse era o modelo do cobit 4.1"/>
<node CREATED="1579118871853" ID="ID_1071049505" MODIFIED="1579118876953" TEXT="n tem nada a ver com o cobit 5"/>
</node>
<node COLOR="#cc6600" CREATED="1579118848926" ID="ID_1042827586" MODIFIED="1579118852325" TEXT="[cespe] Quando um processo atinge o n&#xed;vel 3 &#x2015; denominado processo estabelecido, que possui dois atributos de execu&#xe7;&#xe3;o &#x2015;, ele &#xe9; implementado com a utiliza&#xe7;&#xe3;o de um processo definido capaz de atingir seus resultados."/>
</node>
<node CREATED="1578433345737" FOLDED="true" ID="ID_828559253" MODIFIED="1579118963371" POSITION="right" TEXT="Publica&#xe7;&#xf5;es Cobit 5 x Cobit 2019">
<node CREATED="1578433370928" FOLDED="true" ID="ID_1841556759" MODIFIED="1585597357680" TEXT="ha um reorganiza&#xe7;&#xe3;o das publica&#xe7;&#xf5;es">
<node CREATED="1578433378433" ID="ID_1929358838" MODIFIED="1578433378433">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_5879426836265684501.jpeg" />
  </body>
</html></richcontent>
</node>
<node CREATED="1578433391626" ID="ID_1342338628" MODIFIED="1578433439589" TEXT="o guia do habilitador processos se transforma num guia novo: objetivo de gest&#xe3;o e governan&#xe7;a"/>
<node CREATED="1578433440368" ID="ID_1685515593" MODIFIED="1578433517404" TEXT="tem-se um guia de desenho e um guia de implementa&#xe7;&#xe3;o"/>
</node>
<node CREATED="1578433527626" FOLDED="true" ID="ID_295333245" MODIFIED="1585597357680" TEXT="Princ&#xed;pios Cobit 2019">
<node CREATED="1578433541568" ID="ID_1692198522" MODIFIED="1578433560597" TEXT="s&#xe3;o divididos entre principios do sistema de governan&#xe7;a e principios do framework de governan&#xe7;a"/>
<node CREATED="1578433527627" FOLDED="true" ID="ID_1323470389" MODIFIED="1585597357680" TEXT="&#xf0a7; 6 Princ&#xed;pios do Sistema de Governan&#xe7;a">
<node CREATED="1578433527628" ID="ID_1241689368" MODIFIED="1578433527628" TEXT="&#xf0a7; Valor para as partes interessadas"/>
<node CREATED="1578433527628" ID="ID_1850384170" MODIFIED="1578433527628" TEXT="&#xf0a7; Abordagem hol&#xed;stica"/>
<node CREATED="1578433527629" ID="ID_1426763487" MODIFIED="1578433630090" TEXT="&#xf0a7; Sistema din&#xe2;mico de governan&#xe7;a"/>
<node CREATED="1578433527630" ID="ID_1736022287" MODIFIED="1578433527630" TEXT="&#xf0a7; Distin&#xe7;&#xe3;o entre governan&#xe7;a e gest&#xe3;o"/>
<node CREATED="1578433527631" ID="ID_1878400438" MODIFIED="1578433629661" TEXT="&#xf0a7; Adapt&#xe1;vel &#xe0;s necessidades corporativas"/>
<node CREATED="1578433527631" ID="ID_65908391" MODIFIED="1578433527631" TEXT="&#xf0a7; Sistema de governan&#xe7;a ponta-a-ponta"/>
</node>
<node CREATED="1578433527632" FOLDED="true" ID="ID_164320994" MODIFIED="1585597357680" TEXT="&#xf0a7; 3 princ&#xed;pios do Framework de Governan&#xe7;a">
<node CREATED="1578433527633" ID="ID_160542633" MODIFIED="1578433527633" TEXT="&#xf0a7; Baseado em modelo conceitual"/>
<node CREATED="1578433527634" ID="ID_750570228" MODIFIED="1578433527634" TEXT="&#xf0a7; Aberto e flex&#xed;vel"/>
<node CREATED="1578433527634" ID="ID_175247792" MODIFIED="1578433527634" TEXT="&#xf0a7; Alinhado aos principais padr&#xf5;es"/>
</node>
</node>
<node CREATED="1578433676294" FOLDED="true" ID="ID_818145707" MODIFIED="1585597357681" TEXT="Outras altera&#xe7;&#xf5;es">
<node CREATED="1578433678473" ID="ID_521309102" MODIFIED="1578433707316" TEXT="n&#xe3;o se usa mais o termo habilitador -&gt;  chama-se agora de componentes do sistema de governan&#xe7;a"/>
<node CREATED="1578433720120" ID="ID_239853306" MODIFIED="1578433782309" TEXT="no cascateamento, passa-se a ter objetivos corporativos, objetivos de alinhamento e objetivos dos componentes"/>
<node CREATED="1578433783736" ID="ID_679556819" MODIFIED="1578433803820" TEXT="modelo de processos passa a ser chamado de modelo essencial de objetivos de governan&#xe7;a e gest&#xe3;o"/>
<node CREATED="1578433805263" ID="ID_1085868941" MODIFIED="1578433820381" TEXT="h&#xe1; inclus&#xe3;o das &#xe1;reas de foco e fatores de desenho"/>
<node CREATED="1578433832127" FOLDED="true" ID="ID_1384515766" MODIFIED="1585597357680" TEXT="3 novos processos">
<node CREATED="1578433880394" ID="ID_1948535007" MODIFIED="1578433880394">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Cobit_7301755021660007548.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1578433842524" FOLDED="true" ID="ID_967893600" MODIFIED="1585597357681" TEXT="Substitui&#xe7;&#xe3;o do modelo de avalia&#xe7;&#xe3;o">
<node CREATED="1578433842525" ID="ID_1379364329" MODIFIED="1578433842525" TEXT="&#xf0a7; ISO 15504/33000 &#xf0e0; CMMI 2.0"/>
</node>
</node>
</node>
<node COLOR="#800000" CREATED="1548966429339" FOLDED="true" ID="ID_935228487" MODIFIED="1566339779087" POSITION="right" TEXT="COBIT x ISO 38500">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="full-2"/>
<node COLOR="#cc6600" CREATED="1548967762497" ID="ID_1025436707" MODIFIED="1548967783431" TEXT="[cespe] Para o COBIT 5 o planejamento, gerenciamento e aplica&#xe7;&#xe3;o da TI para atender &#xe0;s necessidades do neg&#xf3;cio inclui tanto a demanda como o fornecimento de servi&#xe7;os de TI pelas unidades internas como por fornecedores externos. &#xc9; o mesmo entendimento que a ISO 38500, com exce&#xe7;&#xe3;o, nesta &#xfa;ltima, na qual ficam exclusos do &#xe2;mbito do uso da TI servi&#xe7;os tais como o fornecimento de software como servi&#xe7;o">
<icon BUILTIN="button_cancel"/>
</node>
<node CREATED="1548967776984" ID="ID_1596786289" MODIFIED="1548967776984" TEXT="A NBR ISO/IEC 38500:2009 est&#xe1; alinhada &#xe0; &#xe1;rea chave de governan&#xe7;a do COBIT 5, pois preconiza a prepara&#xe7;&#xe3;o e a implementa&#xe7;&#xe3;o de planos e pol&#xed;ticas para assegurar que o uso da TI atenda &#xe0;s necessidades atuais e cont&#xed;nuas da estrat&#xe9;gia de neg&#xf3;cio da organiza&#xe7;&#xe3;o."/>
<node COLOR="#cc6600" CREATED="1548968177733" ID="ID_491492214" MODIFIED="1548968181702" TEXT="[cespe] A NBR ISO/IEC 38500:2009 est&#xe1; alinhada &#xe0; &#xe1;rea chave de governan&#xe7;a do COBIT 5, pois preconiza a prepara&#xe7;&#xe3;o e a implementa&#xe7;&#xe3;o de planos e pol&#xed;ticas para assegurar que o uso da TI atenda &#xe0;s necessidades atuais e cont&#xed;nuas da estrat&#xe9;gia de neg&#xf3;cio da organiza&#xe7;&#xe3;o. "/>
</node>
<node CREATED="1524178572036" ID="ID_1366623878" MODIFIED="1524178591740" POSITION="left" TEXT="Baseado no Preparat&#xf3;rio do DTI para o TST - 2017"/>
<node COLOR="#808000" CREATED="1534895161683" ID="ID_586249129" MODIFIED="1534895175446" POSITION="left" TEXT="conteudo complementar"/>
<node COLOR="#cc6600" CREATED="1534895165152" ID="ID_134260479" MODIFIED="1534895171575" POSITION="left" TEXT="conteudo de questoes"/>
<node COLOR="#006699" CREATED="1548968106214" ID="ID_622193111" MODIFIED="1548968109005" POSITION="left" TEXT="conteudo complementar"/>
<node COLOR="#800000" CREATED="1548968299094" ID="ID_1239679205" MODIFIED="1548968605499" POSITION="left" TEXT="negrito: Questoes complexas. Assuntos mais dif&#xed;ceis pra mim">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</map>
